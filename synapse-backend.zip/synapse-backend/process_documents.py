"""
Document processing module for Synapse RAG system.
This file handles PDF document processing using pypdf for text extraction
and PostgreSQL with PGVector for storage and vector search.
"""

import os
import hashlib
import uuid
from typing import Dict, List, Any, Optional
from datetime import datetime
import tiktoken
from io import BytesIO

# Document processing
import pypdf

# Database and vector operations
from sqlalchemy import text
from openai import OpenAI
from fastapi import UploadFile, HTTPException
from dotenv import load_dotenv

# Local imports
from database.db import db_manager
from Utils.LoggingService import LoggingService

# Load environment variables
load_dotenv()

class DocumentProcessor:
    """
    Document processing class using pypdf for text extraction
    and PostgreSQL with PGVector for storage and vector search.
    """
    
    def __init__(self, version: str = "2024.3.3"):
        """
        Initialize the document processor with PostgreSQL + PGVector backend.
        
        Args:
            version (str): Schema version for document storage
        """
        self.logger = LoggingService()
        self.logger.info("DocumentProcessor", "__init__", "Starting DocumentProcessor initialization")
        
        try:
            # Set version and ensure schema exists
            self.version = version
            self.schema_name = db_manager.ensure_version_schema(version)
            self.logger.info("DocumentProcessor", "__init__", f"Using schema: {self.schema_name}")
            
            # Initialize OpenAI client
            openai_api_key = os.getenv("OPENAI_API_KEY")
            if not openai_api_key:
                raise ValueError("OPENAI_API_KEY environment variable not found")
            
            self.openai_client = OpenAI(api_key=openai_api_key)
            self.logger.info("DocumentProcessor", "__init__", "OpenAI connection established")
            
            # Initialize tokenizer for text chunking
            self.tokenizer = tiktoken.get_encoding("cl100k_base")
            self.logger.info("DocumentProcessor", "__init__", "Tokenizer initialized")
            
            self.logger.info("DocumentProcessor", "__init__", "DocumentProcessor initialization completed successfully")
            
        except Exception as e:
            self.logger.error("DocumentProcessor", "__init__", f"Failed to initialize DocumentProcessor: {str(e)}")
            raise
    
    
    def test_database_connection(self):
        """Test PostgreSQL database connection"""
        try:
            count = db_manager.get_document_count(self.schema_name)
            self.logger.info("DocumentProcessor", "test_database_connection", f"PostgreSQL connected successfully. Current documents: {count}")
            return count
        except Exception as e:
            self.logger.error("DocumentProcessor", "test_database_connection", f"Database connection error: {str(e)}")
            raise ConnectionError(f"Failed to connect to PostgreSQL: {str(e)}")
    
    def clear_all_documents(self):
        """Delete all documents from current schema"""
        self.logger.warning("DocumentProcessor", "clear_all_documents", f"Starting to clear all documents from schema: {self.schema_name}")
        
        try:
            with db_manager.engine.connect() as conn:
                # Delete all chunks first (due to foreign key constraint)
                result_chunks = conn.execute(text(f'DELETE FROM "{self.schema_name}".chunks'))
                chunks_deleted = result_chunks.rowcount
                
                # Delete all document files
                result_files = conn.execute(text(f'DELETE FROM "{self.schema_name}".document_files'))
                files_deleted = result_files.rowcount
                
                # Delete all documents
                result_docs = conn.execute(text(f'DELETE FROM "{self.schema_name}".documents'))
                docs_deleted = result_docs.rowcount
                
                conn.commit()
                
                self.logger.info("DocumentProcessor", "clear_all_documents", 
                               f"Cleared {docs_deleted} documents, {chunks_deleted} chunks, {files_deleted} files from schema: {self.schema_name}")
                return docs_deleted
                
        except Exception as e:
            self.logger.error("DocumentProcessor", "clear_all_documents", f"Error clearing documents: {str(e)}")
            return 0
    
    def calculate_file_hash(self, file_content: bytes) -> str:
        """
        Create a unique fingerprint for a file to detect duplicates.
        
        Think of this like creating a unique ID card for each document.
        If two files have the same fingerprint, they're identical copies.
        
        Args:
            file_content (bytes): The raw file data
            
        Returns:
            str: A unique fingerprint (hash) for this file
        """
        self.logger.debug("DocumentProcessor", "calculate_file_hash", f"Calculating hash for file of size {len(file_content)} bytes")
        
        try:
            # Use SHA-256 algorithm to create a unique fingerprint
            # Like creating a unique barcode for each document
            file_hash = hashlib.sha256(file_content).hexdigest()
            self.logger.debug("DocumentProcessor", "calculate_file_hash", f"File hash calculated: {file_hash[:10]}...")
            return file_hash
            
        except Exception as e:
            self.logger.error("DocumentProcessor", "calculate_file_hash", f"Error calculating file hash: {str(e)}")
            raise ValueError(f"Failed to calculate file hash: {str(e)}")
    
    def extract_text_from_pdf(self, file_content: bytes, filename: str = "document.pdf") -> str:
        """
        Extract text from PDF using pypdf.
        
        Args:
            file_content (bytes): The raw PDF file data
            filename (str): Original filename for better processing
            
        Returns:
            str: All the text found in the PDF, combined into one string
        """
        self.logger.debug("DocumentProcessor", "extract_text_from_pdf", f"Starting text extraction from PDF: {filename}")
        
        try:
            pdf_stream = BytesIO(file_content)
            pdf_reader = pypdf.PdfReader(pdf_stream)
            
            if len(pdf_reader.pages) == 0:
                raise ValueError("PDF file contains no pages")
            
            self.logger.debug("DocumentProcessor", "extract_text_from_pdf", f"PDF has {len(pdf_reader.pages)} pages")
            full_text = ""
            
            for page_num, page in enumerate(pdf_reader.pages, 1):
                try:
                    page_text = page.extract_text()
                    full_text += page_text + "\n"
                    self.logger.debug("DocumentProcessor", "extract_text_from_pdf", f"Extracted text from page {page_num}")
                except Exception as page_error:
                    self.logger.warning("DocumentProcessor", "extract_text_from_pdf", 
                                      f"Failed to extract text from page {page_num}: {str(page_error)}")
                    continue
            
            extracted_text = full_text.strip()
            if not extracted_text:
                raise ValueError("No text could be extracted from PDF")
                
            self.logger.info("DocumentProcessor", "extract_text_from_pdf", 
                           f"Successfully extracted {len(extracted_text)} characters from PDF")
            return extracted_text
            
        except Exception as e:
            self.logger.error("DocumentProcessor", "extract_text_from_pdf", f"Error extracting text from PDF: {str(e)}")
            raise HTTPException(status_code=400, detail=f"Error extracting text from PDF: {str(e)}")
    
    def count_words(self, text: str) -> int:
        """
        Count how many words are in a piece of text.
        
        Think of this like counting the words in an essay to see how long it is.
        We split the text by spaces and count the resulting pieces.
        
        Args:
            text (str): The text to count words in
            
        Returns:
            int: The number of words found
        """
        self.logger.debug("DocumentProcessor", "count_words", "Counting words in text")
        
        try:
            if not text or not text.strip():
                self.logger.warning("DocumentProcessor", "count_words", "Empty or whitespace-only text provided")
                return 0
            
            # Split the text by spaces and count the pieces
            # Like counting words in a sentence by separating them at each space
            word_count = len(text.split())
            self.logger.debug("DocumentProcessor", "count_words", f"Word count: {word_count}")
            return word_count
            
        except Exception as e:
            self.logger.error("DocumentProcessor", "count_words", f"Error counting words: {str(e)}")
            return 0
    
    def count_pages(self, file_content: bytes) -> int:
        """
        Count how many pages are in a PDF file.
        
        Think of this like flipping through a book to count how many pages it has.
        
        Args:
            file_content (bytes): The raw PDF file data
            
        Returns:
            int: The number of pages in the PDF
        """
        self.logger.debug("DocumentProcessor", "count_pages", "Counting pages in PDF")
        
        try:
            # Create a BytesIO object from the file content for pypdf
            from io import BytesIO
            pdf_stream = BytesIO(file_content)
            
            # Open the PDF file to examine it
            # Like opening a book to check its length
            pdf_reader = pypdf.PdfReader(pdf_stream)
            page_count = len(pdf_reader.pages)  # Get the total number of pages
            
            self.logger.debug("DocumentProcessor", "count_pages", f"PDF has {page_count} pages")
            return page_count
            
        except Exception as e:
            # If we can't count pages, log and raise appropriate error
            self.logger.error("DocumentProcessor", "count_pages", f"Error counting pages: {str(e)}")
            raise HTTPException(status_code=400, detail=f"Error counting pages: {str(e)}")
    
    def extract_metadata(self, file: UploadFile, file_content: bytes, text: str) -> Dict[str, Any]:
        """
        Gather important information about an uploaded file.
        
        Think of this like creating a detailed catalog card for a library book,
        recording all the important details like title, size, number of pages, etc.
        
        Args:
            file (UploadFile): The uploaded file object
            file_content (bytes): The raw file data
            text (str): The extracted text from the file
            
        Returns:
            Dict[str, Any]: A dictionary containing all the file information
        """
        self.logger.debug("DocumentProcessor", "extract_metadata", f"Extracting metadata for file: {file.filename}")
        
        try:
            metadata = {
                "filename": file.filename,  # The name of the file (like the book title)
                "file_size": len(file_content),  # How big the file is in bytes
                "page_count": self.count_pages(file_content),  # How many pages it has
                "word_count": self.count_words(text),  # How many words are in it
                "file_hash": self.calculate_file_hash(file_content),  # Unique fingerprint
                "content_type": file.content_type  # What type of file it is (PDF, etc.)
            }
            
            self.logger.info("DocumentProcessor", "extract_metadata", f"Metadata extracted - Size: {metadata['file_size']} bytes, Pages: {metadata['page_count']}, Words: {metadata['word_count']}")
            return metadata
            
        except Exception as e:
            self.logger.error("DocumentProcessor", "extract_metadata", f"Error extracting metadata: {str(e)}")
            raise ValueError(f"Failed to extract metadata: {str(e)}")
    
    def check_duplicate(self, file_hash: str, schema_name: Optional[str] = None) -> bool:
        """Check if we've already processed this exact file before."""
        schema = schema_name or self.schema_name
        self.logger.debug("DocumentProcessor", "check_duplicate", f"Checking for duplicate with hash: {file_hash[:10]}...")
        
        try:
            existing_doc = db_manager.check_duplicate_document(schema, file_hash)
            
            if existing_doc:
                filename = existing_doc.get('filename', 'Unknown')
                self.logger.info("DocumentProcessor", "check_duplicate", f"Duplicate found: {filename}")
                return True
            else:
                self.logger.debug("DocumentProcessor", "check_duplicate", "No duplicate found")
                return False
            
        except Exception as e:
            self.logger.error("DocumentProcessor", "check_duplicate", f"Error checking duplicates: {str(e)}")
            return False  # If error, allow upload to proceed

    
    def chunk_text(self, text: str, max_tokens: int = 800) -> List[str]:
        """
        Break long text into smaller, manageable pieces for processing.
        
        Think of this like cutting a very long book into chapters so it's easier
        to read and search through. Each piece continues exactly where the 
        previous one ended, so no information is lost.
        
        Args:
            text (str): The long text to break into pieces
            max_tokens (int): Maximum size of each piece (default 800 words/tokens)
            
        Returns:
            List[str]: A list of text pieces, each small enough to process
        """
        self.logger.debug("DocumentProcessor", "chunk_text", f"Chunking text of {len(text)} characters with max_tokens={max_tokens}")
        
        try:
            if not text or not text.strip():
                self.logger.warning("DocumentProcessor", "chunk_text", "Empty text provided for chunking")
                return []
            
            # Convert the text into tokens (computer-readable units)
            # Like breaking text into individual words and punctuation marks
            tokens = self.tokenizer.encode(text)
            self.logger.debug("DocumentProcessor", "chunk_text", f"Text encoded to {len(tokens)} tokens")
            
            chunks = []
            
            # Split the tokens into chunks of the specified size
            # Like cutting a long rope into equal-length pieces
            for i in range(0, len(tokens), max_tokens):
                chunk_tokens = tokens[i:i + max_tokens]  # Get a chunk of tokens
                chunk_text = self.tokenizer.decode(chunk_tokens)  # Convert back to readable text
                chunks.append(chunk_text)  # Add this chunk to our list
            
            self.logger.info("DocumentProcessor", "chunk_text", f"Text split into {len(chunks)} chunks")
            return chunks
            
        except Exception as e:
            self.logger.error("DocumentProcessor", "chunk_text", f"Error chunking text: {str(e)}")
            raise ValueError(f"Failed to chunk text: {str(e)}")
    
    def create_embeddings(self, text: str) -> List[float]:
        """
        Convert text into numbers that computers can understand and compare.
        
        Args:
            text (str): The text to convert into numbers
            
        Returns:
            List[float]: A list of numbers representing the text's meaning
        """
        self.logger.debug("DocumentProcessor", "create_embeddings", f"Creating embeddings for text of {len(text)} characters")
        
        try:
            if not text or not text.strip():
                self.logger.warning("DocumentProcessor", "create_embeddings", "Empty text provided for embedding")
                raise ValueError("Cannot create embeddings for empty text")
            
            # Use text-embedding-3-small for 1536 dimensions (matches our database schema)
            response = self.openai_client.embeddings.create(
                model="text-embedding-3-small",  # 1536 dimensions
                input=text
            )
            
            embedding = response.data[0].embedding
            self.logger.debug("DocumentProcessor", "create_embeddings", f"Successfully created embedding with {len(embedding)} dimensions")
            return embedding
            
        except Exception as e:
            self.logger.error("DocumentProcessor", "create_embeddings", f"Error creating embeddings: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Error creating embeddings: {str(e)}")
    
    def store_in_postgresql(self, metadata: Dict[str, Any], full_text: str, file_content: bytes, schema_name: Optional[str] = None) -> str:
        """
        Save the document and its information in PostgreSQL database.
        
        Args:
            metadata (Dict[str, Any]): All the information about the file
            full_text (str): The full text content extracted from the file
            file_content (bytes): The original PDF binary data
            schema_name (Optional[str]): Schema to use; defaults to self.schema_name
            
        Returns:
            str: A unique ID for this stored document
        """
        schema = schema_name or self.schema_name
        self.logger.debug("DocumentProcessor", "store_in_postgresql", f"Attempting to store document: {metadata.get('filename', 'Unknown')}")
        
        try:
            with db_manager.engine.connect() as conn:
                # Generate UUID for document
                document_id = str(uuid.uuid4())
                
                # Insert document record
                conn.execute(text(f"""
                    INSERT INTO "{schema}".documents 
                    (id, filename, file_hash, file_size, page_count, word_count, content_type, full_text, status)
                    VALUES (:id, :filename, :file_hash, :file_size, :page_count, :word_count, :content_type, :full_text, :status)
                """), {
                    "id": document_id,
                    "filename": metadata["filename"],
                    "file_hash": metadata["file_hash"],
                    "file_size": metadata["file_size"],
                    "page_count": metadata["page_count"],
                    "word_count": metadata["word_count"],
                    "content_type": metadata["content_type"],
                    "full_text": full_text,
                    "status": "processed"
                })
                
                # Store PDF binary data
                conn.execute(text(f"""
                    INSERT INTO "{schema}".document_files (document_id, file_content)
                    VALUES (:document_id, :file_content)
                """), {
                    "document_id": document_id,
                    "file_content": file_content
                })
                
                conn.commit()
                
                self.logger.info("DocumentProcessor", "store_in_postgresql", f"Successfully stored document with ID: {document_id}")
                return document_id
                
        except Exception as e:
            self.logger.error("DocumentProcessor", "store_in_postgresql", f"PostgreSQL storage error: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Error storing in PostgreSQL: {str(e)}")
    
    def store_chunks_in_postgresql(self, chunks: List[str], metadata: Dict[str, Any], document_id: str, schema_name: Optional[str] = None):
        """
        Store all the text pieces with their vector embeddings in PostgreSQL.
        
        Args:
            chunks (List[str]): List of text pieces from the document
            metadata (Dict[str, Any]): Information about the original document
            document_id (str): Unique ID of the stored document
            schema_name (Optional[str]): Schema to use; defaults to self.schema_name
        """
        schema = schema_name or self.schema_name
        self.logger.debug("DocumentProcessor", "store_chunks_in_postgresql", f"Storing {len(chunks)} chunks in PostgreSQL for document: {metadata.get('filename', 'Unknown')}")
        
        try:
            with db_manager.engine.connect() as conn:
                # Process each text chunk and store with embedding
                for i, chunk in enumerate(chunks):
                    self.logger.debug("DocumentProcessor", "store_chunks_in_postgresql", f"Processing chunk {i+1}/{len(chunks)}")
                    
                    # Convert text chunk into vector embedding
                    embedding = self.create_embeddings(chunk)
                    
                    # Convert embedding to string format for pgvector
                    embedding_str = str(embedding)
                    
                    # Generate UUID for chunk
                    chunk_id = str(uuid.uuid4())
                    
                    # Insert chunk with embedding
                    conn.execute(text(f"""
                        INSERT INTO "{schema}".chunks 
                        (id, document_id, chunk_index, text, embedding)
                        VALUES (:id, :document_id, :chunk_index, :text, :embedding)
                    """), {
                        "id": chunk_id,
                        "document_id": document_id,
                        "chunk_index": i,
                        "text": chunk,
                        "embedding": embedding_str
                    })
                
                conn.commit()
                
                self.logger.info("DocumentProcessor", "store_chunks_in_postgresql", f"Successfully stored {len(chunks)} chunks in PostgreSQL")
                
        except Exception as e:
            self.logger.error("DocumentProcessor", "store_chunks_in_postgresql", f"Error storing chunks in PostgreSQL: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Error storing chunks in PostgreSQL: {str(e)}")
    
    async def upload_file(self, file: UploadFile, version: Optional[str] = None) -> Dict[str, str]:
        """
        This is the main function that orchestrates the entire document processing workflow.
        
        Think of this like the manager of a document processing factory who coordinates
        all the different steps to turn a raw PDF into a searchable, organized document.
        
        Args:
            file (UploadFile): The PDF file uploaded by the user
            version (Optional[str]): Schema version for this upload (e.g. 2024.3.1); uses default if not provided
            
        Returns:
            Dict[str, str]: A report on what happened (success/failure with details)
        """
        schema_for_upload = db_manager.ensure_version_schema(version) if version else self.schema_name
        self.logger.info("DocumentProcessor", "upload_file", f"Starting file upload process for: {file.filename}" + (f" (version: {version})" if version else ""))
        
        try:
            # Step 1: Check if the file is a PDF
            # Like checking if someone brought the right type of document to process
            if not file.content_type == "application/pdf":
                self.logger.warning("DocumentProcessor", "upload_file", f"Invalid file type: {file.content_type}")
                raise HTTPException(status_code=400, detail="Only PDF files are supported")
            
            # Step 2: Read the file data
            # Like opening the document to start working with it
            self.logger.debug("DocumentProcessor", "upload_file", "Reading file content")
            file_content = await file.read()
            
            if len(file_content) == 0:
                self.logger.warning("DocumentProcessor", "upload_file", "Empty file provided")
                raise HTTPException(status_code=400, detail="File is empty")
            
            # Step 3: Extract all text from the PDF using Docling with pypdf fallback
            text = self.extract_text_from_pdf(file_content, file.filename)
            
            # Check if we actually found any text
            if not text.strip():
                self.logger.warning("DocumentProcessor", "upload_file", "No text extracted from PDF")
                raise HTTPException(status_code=400, detail="No text could be extracted from PDF")
            
            # Step 4: Gather information about the file
            metadata = self.extract_metadata(file, file_content, text)
            
            # Step 5: Check if we've already processed this exact file (in the chosen schema)
            if self.check_duplicate(metadata["file_hash"], schema_name=schema_for_upload):
                self.logger.info("DocumentProcessor", "upload_file", f"Duplicate file detected: {file.filename}")
                return {"message": "File skipped: already exists", "status": "skipped"}
            
            # Step 6: Store the complete document in PostgreSQL database
            self.logger.info("DocumentProcessor", "upload_file", f"Processing file: {file.filename} - Text length: {len(text)} characters")
            document_id = self.store_in_postgresql(metadata, text, file_content, schema_name=schema_for_upload)
            
            # Step 7: Break the text into smaller, searchable pieces
            chunks = self.chunk_text(text)
            
            # Step 8: Store all pieces with embeddings in PostgreSQL
            self.store_chunks_in_postgresql(chunks, metadata, document_id, schema_name=schema_for_upload)
            
            # Return a success report with all the details
            # Like giving a completion report to the person who submitted the document
            result = {
                "message": f"File '{file.filename}' processed successfully",
                "status": "success",
                "document_id": document_id,
                "chunks_created": len(chunks),
                "word_count": metadata["word_count"],
                "page_count": metadata["page_count"]
            }
            
            self.logger.info("DocumentProcessor", "upload_file", f"File processing completed successfully: {file.filename} - Document ID: {document_id}")
            return result
            
        except HTTPException:
            # If it's a known error (like wrong file type), just pass it along
            raise
        except Exception as e:
            # If something unexpected went wrong, log and explain what happened
            # Like if the entire processing factory broke down, we explain the problem
            self.logger.error("DocumentProcessor", "upload_file", f"Unexpected error processing file {file.filename}: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")

# Create a global instance of our document processor that the main application can use
# Think of this like setting up a permanent document processing station for our system
document_processor = DocumentProcessor()
