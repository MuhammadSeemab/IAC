"""
RAG agent module for Synapse system.
This file is like a smart librarian that can answer questions about your documents.
It searches through stored document pieces and uses AI to create intelligent answers.
"""

# Import necessary tools (like importing ingredients for cooking)
import os  # Tool to read environment variables (secret keys)
import random  # Tool to introduce light, controlled variety in non-RAG replies
import re  # Tool for response post-processing and formatting cleanup
from datetime import datetime  # Tool to derive time-of-day hints for greetings
from typing import List, Dict, Any, Optional  # Tool to specify what type of data we expect
from sqlalchemy import text  # Tool for raw SQL queries
from openai import OpenAI  # Tool to use AI for understanding and generating text
from fastapi import HTTPException  # Tool to handle errors in web requests
from dotenv import load_dotenv  # Tool to load secret keys from .env file
from Utils.LoggingService import LoggingService  # Tool for structured logging
from database.db import db, db_manager  # Database managers

# Load environment variables (read the secret keys from .env file)
# Think of this like opening your wallet to get your credit cards
load_dotenv()

class RAGAgent:
    """
    This is the main class that acts like a smart research assistant.
    It can take your questions, search through documents, and give you intelligent answers.
    Think of it like a librarian who knows every book in the library by heart.
    """
    
    def __init__(self):
        """
        This function runs when we create a new RAGAgent.
        It's like setting up the librarian's workspace - connecting to all the tools they need.
        """
        
        # Initialize logging service
        self.logger = LoggingService()
        self.logger.info("RAGAgent", "__init__", "Starting RAGAgent initialization")
        
        try:
            # Connect to OpenAI (our AI brain for understanding and generating text)
            # Think of this like hiring a genius assistant who can read and write perfectly
            self.logger.debug("RAGAgent", "__init__", "Connecting to OpenAI")
            openai_api_key = os.getenv("OPENAI_API_KEY")
            if not openai_api_key:
                raise ValueError("OPENAI_API_KEY environment variable not found")
            
            self.openai_client = OpenAI(api_key=openai_api_key)
            self.logger.info("RAGAgent", "__init__", "OpenAI connection established")
            
            # Note: PostgreSQL connection will be tested when first used
            # Think of this like having the filing system ready but not opening it until needed
            self.logger.info("RAGAgent", "__init__", "PostgreSQL connection will be established when needed")
            
            # Keep minimal conversational state to avoid repetitive non-RAG greetings
            self.last_direct_response: str = ""
            self._style_index: int = 0  # rotate suggestion styles for variety

            self.logger.info("RAGAgent", "__init__", "RAGAgent initialization completed successfully")
            
        except Exception as e:
            self.logger.error("RAGAgent", "__init__", f"Failed to initialize RAGAgent: {str(e)}")
            raise
    
    
 
    def _normalize_text(self, text: str) -> str:
        """
        Normalize input for lightweight pattern checks (no regex).
        Lowercase, trim, replace punctuation with spaces, and collapse spaces.
        """
        try:
            norm = (text or "").lower().strip()
            for ch in ["\n", "\r", "\t", ",", ".", "!", "?", ":", ";"]:
                norm = norm.replace(ch, " ")
            norm = " ".join(norm.split())
            return norm
        except Exception:
            return (text or "").lower().strip()

    def _small_talk_reply(self, query: str) -> str | None:
        """
        Return a varied, friendly reply for common small-talk. Uses rotation
        to avoid repetition. Returns None if not recognized as small-talk.
        """
        norm = self._normalize_text(query)
        variants = []

        def choose(lines):
            if not lines:
                return None
            # rotate deterministically to avoid repeating the same line
            idx = self._style_index % len(lines)
            self._style_index += 1
            return lines[idx]

        # Greetings
        if any(w in norm for w in ["hi", "hello", "hey", "good morning", "good evening", "good afternoon"]):
            variants = [
                "Hello! I’m here to help with your company documentation. What topic would you like to look up?",
                "Hi there! Tell me which document, product module, or process you want to explore.",
                "Hey! What part of the docs should we check—installation, configuration, or a specific portal?",
            ]
            return choose(variants)

        # How-are-you / sentiment check-ins
        if any(phrase in norm for phrase in ["how are you", "how's your day", "how was your day", "are you upset", "are you angry", "are you ok", "how are u"]):
            variants = [
                "I’m all set to help with your docs today! Which product area or task should we focus on?",
                "Doing great—ready to search your documentation. What process or page should we check?",
                "Thanks for asking! Point me to a feature, portal, or topic and I’ll pull the relevant info.",
            ]
            return choose(variants)

        # Who are you / what can you do
        if any(phrase in norm for phrase in ["who are you", "what can you do", "help", "what do you do", "what are you doing"]):
            variants = [
                "I’m your documentation assistant. Ask me about procedures, roles, portals, or configuration steps.",
                "I help you find answers in your company docs—installation, access requests, invitations, badges, and more.",
                "I search your uploaded documentation and summarize the steps you need. What should we look up?",
            ]
            return choose(variants)

        # Thanks / goodbye
        if any(phrase in norm for phrase in ["thanks", "thank you", "bye", "goodbye", "see you"]):
            variants = [
                "You’re welcome! If you need more from the docs, just ask.",
                "Happy to help! Ping me anytime you want to search the documentation.",
                "Anytime! I’m here when you need more info from the docs.",
            ]
            return choose(variants)

        return None

    def classify_query_type(self, query: str) -> str:
        """
        Deprecated heuristic. Kept for backward compatibility only and used as a
        last-resort fallback by classify_query_type_smart(). Always defaults to
        'document_question' to avoid any hardcoded phrase rules.
        """
        return "document_question"

    def classify_query_type_smart(self, query: str) -> str:
        """
        LLM-based lightweight classifier. Returns 'document_question' when the user
        is asking about uploaded company documents, procedures, policies, product
        features, installation, troubleshooting, APIs, or anything that should use
        the RAG index. Returns 'non_document' for greetings, chit-chat, general
        knowledge, or questions that do not require searching the uploaded docs.

        Falls back to the heuristic classify_query_type() on any error.
        """
        try:
            # Domain-aware classification: access management, roles, invitations, portals, badges
            system = (
                "You are a classifier for an enterprise Access Management documentation assistant. "
                "Output exactly one token: 'document_question' or 'non_document'. "
                "Return 'document_question' for queries about company-uploaded docs, procedures, user roles, "
                "product features, configuration steps, troubleshooting, invitations, badges, portals, access requests, "
                "permissions, rule engine, APIs, or anything likely covered by internal docs. "
                "Return 'non_document' ONLY for clear chit-chat, greetings, jokes, or general world knowledge completely unrelated to the product. "
                "Be STRONGLY biased towards 'document_question' - when in doubt, always return 'document_question'. "
                "For short or ambiguous queries, always return 'document_question' unless it's clearly just a greeting or joke. "
                "Do not add explanations."
            )
            user = f"Query: {query}\nLabel:"

            resp = self.openai_client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": user}
                ],
                temperature=0.0,
                max_tokens=3
            )
            label = (resp.choices[0].message.content or "").strip().lower()
            if "document_question" in label:
                return "document_question"
            if "non_document" in label:
                # Lightweight heuristic override: if domain cues are present, treat as document question
                norm = self._normalize_text(query)
                domain_cues = [
                    "invite", "visitor", "visitors", "request access", "access request", "badge", "print badge",
                    "host", "employee", "reception", "portal", "vm", "am", "rule engine", "permission", "grant", "revoke"
                ]
                if any(term in norm for term in domain_cues):
                    return "document_question"
                return "non_document"

            # If the LLM returned something unexpected, default to document_question to be safe
            return "document_question"
        except Exception as e:
            # Log and fallback to document_question by default (safer to try RAG than refuse)
            self.logger.warning("RAGAgent", "classify_query_type_smart", f"LLM classification failed, defaulting to document_question: {str(e)}")
            return "document_question"

    def handle_small_talk(self, query: str) -> Dict[str, Any]:
        """
        Deprecated. Non-document queries are answered via generate_direct_response().
        Kept for compatibility if any external code still calls this.
        """
        direct = self.generate_direct_response(query)
        return {"response": direct, "sources": [], "query": query, "chunks_used": 0}
    def create_query_embedding(self, query: str) -> List[float]:
        """
        Convert a user's question into numbers that computers can understand.
        
        Think of this like translating your question from English into a special 
        computer language made of numbers. This allows the computer to compare 
        your question with stored document pieces to find matches.
        
        Args:
            query (str): The user's question in plain English
            
        Returns:
            List[float]: A list of numbers representing the question's meaning
        """
        self.logger.debug("RAGAgent", "create_query_embedding", f"Creating embedding for query: {query[:50]}...")
        
        try:
            if not query or not query.strip():
                self.logger.warning("RAGAgent", "create_query_embedding", "Empty query provided")
                raise ValueError("Query cannot be empty")
            
            # Ask OpenAI to convert the question into numbers (embedding)
            # This is like asking a translator to convert English to computer language
            response = self.openai_client.embeddings.create(
                model="text-embedding-3-small",  # Use OpenAI's small embedding model (1536 dimensions)
                input=query  # The user's question we want to convert
            )
            
            # Extract the numbers from OpenAI's response
            # Think of this like getting the translated version back from the translator
            embedding = response.data[0].embedding
            self.logger.debug("RAGAgent", "create_query_embedding", f"Successfully created embedding with {len(embedding)} dimensions")
            return embedding
            
        except Exception as e:
            # If something goes wrong, log and tell the user what happened
            # Like if the translator is unavailable, we explain the problem
            self.logger.error("RAGAgent", "create_query_embedding", f"Error creating query embedding: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Error creating query embedding: {str(e)}")
    
    def search_relevant_chunks(self, query_embedding: List[float], top_k: int = 5, version: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Search through all stored document pieces to find the most relevant ones for the user's question using PostgreSQL with pgvector.
        
        Think of this like a librarian searching through all the index cards in their filing system
        to find the books that best match what you're looking for.
        
        Args:
            query_embedding (List[float]): The user's question converted to numbers
            top_k (int): How many relevant pieces to find (default is 5)
            version (Optional[str]): Specific version to search in, "All Versions" for cross-version search, or None for latest
            
        Returns:
            List[Dict[str, Any]]: A list of the most relevant document pieces with their information
        """
        self.logger.debug("RAGAgent", "search_relevant_chunks", f"Searching for top {top_k} relevant chunks")
        
        try:
            # Get list of available version schemas to search
            # Think of this like getting a list of all the different filing cabinets we have
            all_schemas = db_manager.list_version_schemas()
            
            # Check for "All Versions" request (null, empty string, or explicit keywords)
            if version is None or (isinstance(version, str) and (version.strip() == "" or version.strip().lower() in ["all versions", "all", "*"])):
                # Search across ALL version schemas for comparative analysis
                schemas_to_search = all_schemas
                search_mode = "all_versions"
                self.logger.info("RAGAgent", "search_relevant_chunks", f"ALL VERSIONS search mode: searching across {len(schemas_to_search)} schemas: {schemas_to_search}")
            elif version and isinstance(version, str) and version.strip():
                # Search only in the specified version schema
                version_clean = version.strip()
                schema_name = db_manager.sanitize_schema_name(version_clean)
                schemas_to_search = [schema_name]
                search_mode = "specific_version"
                self.logger.info("RAGAgent", "search_relevant_chunks", f"Searching in specific version schema: '{schema_name}' (from version: '{version}')")
                self.logger.info("RAGAgent", "search_relevant_chunks", f"Available schemas: {all_schemas}")
            else:
                # Fallback: search in all available version schemas
                schemas_to_search = all_schemas
                search_mode = "all_versions"
                self.logger.info("RAGAgent", "search_relevant_chunks", f"Fallback to ALL VERSIONS: searching in all {len(schemas_to_search)} version schemas: {schemas_to_search}")
            
            # Create an empty list to store all the search results
            all_results = []
            
            # For "All Versions" mode, we want to get more results per schema to enable comparison
            per_schema_limit = top_k if search_mode != "all_versions" else max(3, top_k // len(schemas_to_search) + 1)
            
            # Search through each version schema one by one
            for schema_name in schemas_to_search:
                try:
                    with db_manager.engine.connect() as conn:
                        # Format embedding as PostgreSQL array string
                        query_embedding_str = '[' + ','.join(str(float(x)) for x in query_embedding) + ']'
                        
                        # Execute vector search query - use direct string substitution for vector
                        # pgvector requires proper vector format
                        result = conn.execute(text(f"""
                            SELECT 
                                c.id,
                                c.document_id,
                                c.chunk_index,
                                c.text,
                                d.filename,
                                d.file_hash,
                                1 - (c.embedding <=> '{query_embedding_str}'::vector) as similarity_score
                            FROM "{schema_name}".chunks c
                            JOIN "{schema_name}".documents d ON c.document_id = d.id
                            WHERE c.embedding IS NOT NULL
                            ORDER BY c.embedding <=> '{query_embedding_str}'::vector
                            LIMIT :per_schema_limit
                        """), {
                            "per_schema_limit": per_schema_limit
                        })
                        
                        rows = result.fetchall()
                        if rows:
                            for row in rows:
                                # Convert schema name to readable version (e.g., "2024.3.1" from schema name)
                                # Handle both "v_2024_3_1" format and "2024.3.1" format
                                if schema_name.startswith("v_"):
                                    readable_version = schema_name.replace("v_", "").replace("_", ".")
                                else:
                                    # For schemas like "2024.3.1", use as-is
                                    readable_version = schema_name
                                
                                match_data = {
                                    "id": str(row[0]),
                                    "document_id": str(row[1]),
                                    "chunk_index": row[2],
                                    "text": row[3],
                                    "filename": row[4],
                                    "file_hash": row[5],
                                    "score": float(row[6]),
                                    "schema": schema_name,
                                    "version": readable_version,
                                    "search_mode": search_mode
                                }
                                all_results.append(match_data)
                
                except Exception as e:
                    self.logger.warning("RAGAgent", "search_relevant_chunks", f"Error searching schema {schema_name}: {str(e)}")
                    continue
            
            # Sort all results by relevance score (best matches first)
            all_results.sort(key=lambda x: x["score"], reverse=True)
            
            # For "All Versions" mode, ensure we have representation from multiple versions if possible
            if search_mode == "all_versions" and len(schemas_to_search) > 1:
                # Group results by version to ensure diversity
                version_groups = {}
                for result in all_results:
                    version = result["version"]
                    if version not in version_groups:
                        version_groups[version] = []
                    version_groups[version].append(result)
                
                # Take top results from each version to ensure comparative context
                balanced_results = []
                max_per_version = max(1, top_k // len(version_groups))
                
                # First pass: take top results from each version
                for version, results in version_groups.items():
                    balanced_results.extend(results[:max_per_version])
                
                # Second pass: fill remaining slots with best overall results
                remaining_slots = top_k - len(balanced_results)
                if remaining_slots > 0:
                    used_ids = {r["id"] for r in balanced_results}
                    for result in all_results:
                        if result["id"] not in used_ids and remaining_slots > 0:
                            balanced_results.append(result)
                            remaining_slots -= 1
                
                # Sort final results by score
                final_results = sorted(balanced_results, key=lambda x: x["score"], reverse=True)[:top_k]
                self.logger.info("RAGAgent", "search_relevant_chunks", f"ALL VERSIONS mode: Returning {len(final_results)} chunks from {len(version_groups)} versions")
            else:
                # Return only the top results for single version or default search
                final_results = all_results[:top_k]
                self.logger.info("RAGAgent", "search_relevant_chunks", f"Returning {len(final_results)} chunks")
            
            return final_results
            
        except Exception as e:
            # If the entire search process fails, log and tell the user what went wrong
            self.logger.error("RAGAgent", "search_relevant_chunks", f"Error searching PostgreSQL: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Error searching PostgreSQL: {str(e)}")
    
    def format_context(self, relevant_chunks: List[Dict[str, Any]]) -> str:
        """
        Organize the found document pieces into a nice format for the AI to read.
        
        Think of this like a research assistant taking all the relevant book pages
        they found and organizing them into a neat stack with labels, so the 
        expert can easily read through them to write a comprehensive answer.
        
        Args:
            relevant_chunks (List[Dict[str, Any]]): List of relevant document pieces
            
        Returns:
            str: Nicely formatted text with all the relevant information
        """
        self.logger.debug("RAGAgent", "format_context", f"Formatting context from {len(relevant_chunks)} chunks")
        
        # If we didn't find any relevant information, say so
        if not relevant_chunks:
            self.logger.warning("RAGAgent", "format_context", "No relevant chunks provided for formatting")
            return "No relevant context found."
        
        try:
            # Check if we're in all_versions mode
            search_mode = relevant_chunks[0].get('search_mode', 'default') if relevant_chunks else 'default'
            
            if search_mode == "all_versions":
                # Group chunks by version for better comparative analysis
                version_groups = {}
                for chunk in relevant_chunks:
                    version = chunk.get('version', 'Unknown')
                    if version not in version_groups:
                        version_groups[version] = []
                    version_groups[version].append(chunk)
                
                # Format context grouped by version
                context_parts = []
                context_parts.append("=== CONTEXT FROM MULTIPLE VERSIONS ===\n")
                
                for version, chunks in sorted(version_groups.items()):
                    context_parts.append(f"\n--- VERSION {version} ---\n")
                    for i, chunk in enumerate(chunks, 1):
                        filename = chunk.get('filename', 'Unknown')
                        chunk_index = chunk.get('chunk_index', 0)
                        text = chunk.get('text', '')
                        score = chunk.get('score', 0)
                        
                        context_parts.append(
                            f"[Version {version} - {filename}, Chunk {chunk_index}, Relevance: {score:.3f}]\n"
                            f"{text}\n"
                        )
                
                formatted_context = "\n".join(context_parts)
            else:
                # Single version mode - use simpler formatting
                context_parts = []
                for i, chunk in enumerate(relevant_chunks, 1):
                    filename = chunk.get('filename', 'Unknown')
                    chunk_index = chunk.get('chunk_index', 0)
                    text = chunk.get('text', '')
                    
                    context_parts.append(
                        f"[Source {i}: {filename}, Chunk {chunk_index}]\n"
                        f"{text}\n"
                    )
                
                formatted_context = "\n---\n".join(context_parts)
            
            self.logger.debug("RAGAgent", "format_context", f"Successfully formatted context with {len(formatted_context)} characters (mode: {search_mode})")
            return formatted_context
            
        except Exception as e:
            self.logger.error("RAGAgent", "format_context", f"Error formatting context: {str(e)}")
            return "Error formatting context from retrieved documents."
    
    def generate_response(self, query: str, context: str, history: List[Dict[str, str]] | None = None, search_mode: str = "default") -> str:
        """
        Use AI to create a comprehensive answer based on the relevant document pieces we found.
        
        Think of this like giving all the relevant research materials to a brilliant 
        professor and asking them to write a detailed, well-organized answer to your question.
        
        Args:
            query (str): The user's original question
            context (str): All the relevant document pieces formatted nicely
            search_mode (str): Search mode used ("all_versions", "specific_version", or "default")
            
        Returns:
            str: A comprehensive, well-formatted answer to the user's question
        """
        self.logger.debug("RAGAgent", "generate_response", f"Generating response for query: {query[:50]}... (mode: {search_mode})")
        
        try:
            if not context or context.strip() == "No relevant context found.":
                self.logger.warning("RAGAgent", "generate_response", "No context provided for response generation")
                return "I couldn't find relevant information in the uploaded documents to answer your question."
            
            # Create instructions for the AI on how to behave
            # Different prompts for different search modes
            if search_mode == "all_versions":
                system_prompt = """You are a professional AI assistant specialized in explaining company technical documentation with EXCELLENT formatting and COMPARATIVE ANALYSIS across multiple document versions.

CRITICAL FORMATTING REQUIREMENTS:
- ALWAYS start with a clear main heading using ##
- Use proper spacing: Add blank lines between all sections
- Use ### for subsections with blank lines before and after
- Use proper indentation for sub-points under main steps
- Use numbered lists (1., 2., 3.) for main sequential steps
- Use bullet points (•) for sub-points, indented with spaces
- Bold important terms using **text**
- Add blank lines between paragraphs and sections
- Keep paragraphs short (2-3 sentences max)
- Headings (##, ###) must NEVER be part of numbered or bulleted lists—write them as plain headings with no leading numbers or bullets.
- Do NOT start the response with extra blank lines; begin immediately with the main heading.
- Use numbered lists ONLY for actual steps within sections like "Step-by-Step Process"—not for headings or section titles.

ALL VERSIONS ANALYSIS REQUIREMENTS (CRITICAL):
- The context provided contains information from MULTIPLE document versions (clearly labeled with version numbers)
- You MUST provide a MEANINGFUL COMPARATIVE ANALYSIS that:
  1. ACTUALLY COMPARES the content across versions - don't just list the same information repeatedly
  2. Identifies REAL differences in procedures, steps, requirements, or details between versions
  3. If content is truly identical, state it ONCE clearly and then present the unified information
  4. Avoid repetition - don't say the same thing three times for three versions
  5. Focus on what's DIFFERENT or what's the SAME, not on restating everything for each version

STRUCTURE TEMPLATE FOR ALL VERSIONS:
## Main Topic

Brief introduction mentioning that information spans multiple versions.

### Version Analysis Summary
• **Versions Analyzed**: List all versions found (e.g., 2024.3.1, 2024.3.2, 2024.3.3)
• **Consistency Status**: State if information is identical, mostly similar, or significantly different
• **Key Finding**: Main conclusion about version differences

### Detailed Comparison

**IF INFORMATION IS IDENTICAL ACROSS VERSIONS:**
1. **Consistent Information**:
   • Present the unified information clearly
   • State explicitly: "This information is identical across all versions"

**IF DIFFERENCES EXIST:**
1. **Common Elements Across All Versions**:
   • Shared features or processes that are consistent

2. **Key Differences by Version**:
   • **Version 2024.3.1**: 
     - Context: [Show actual text/content from this version]
     - Key points unique to this version
   • **Version 2024.3.2**: 
     - Context: [Show actual text/content from this version]
     - Changes or differences from 2024.3.1
   • **Version 2024.3.3**: 
     - Context: [Show actual text/content from this version]
     - Latest changes or new information

3. **Evolution Analysis**:
   • What changed between versions and why
   • Which version provides the most current guidance

### Recommendations
• **Most Current**: Which version to follow for latest practices
• **Important Notes**: Critical differences users should be aware of

### Step-by-Step Process (if applicable)
Present the process steps clearly. If steps differ by version, show the differences. If steps are the same, present them once.

### Important Notes
• Any version-specific requirements or considerations
• Which version to follow for current practices (if applicable)
• Any critical differences to be aware of

COMPARATIVE ANALYSIS RULES (MANDATORY):
- DO NOT repeat the same information multiple times - if it's identical, say it once
- DO NOT create fake differences - if versions are the same, acknowledge it and move on
- DO focus on actual differences when they exist
- DO make it immediately clear whether versions differ or are consistent
- DO present information efficiently - avoid redundancy
- When content is identical, present it as unified information, not as three separate identical sections
- After any heading, provide the explanatory paragraph or list directly; do not create empty blank paragraphs between a heading and its explanation.
"""
            else:
                system_prompt = """You are a professional AI assistant specialized in explaining company technical documentation with EXCELLENT formatting.

CRITICAL FORMATTING REQUIREMENTS:
- ALWAYS start with a clear main heading using ##
- Use proper spacing: Add blank lines between all sections
- Use ### for subsections with blank lines before and after
- Use proper indentation for sub-points under main steps
- Use numbered lists (1., 2., 3.) for main sequential steps
- Use bullet points (•) for sub-points, indented with spaces
- Bold important terms using **text**
- Add blank lines between paragraphs and sections
- Keep paragraphs short (2-3 sentences max)
- Headings (##, ###) must NEVER be combined with numbers or bullets—write them as plain headings only.
- Begin the response directly with the main heading; avoid leading blank lines.
- Numbered lists should be used only for actual steps, not for headings or explanatory paragraphs.

STRUCTURE TEMPLATE WITH PROPER INDENTATION:
## Main Topic

Brief introduction paragraph.

### Step-by-Step Process
1. **Main Step One**: Description
   • Sub-point with proper indentation
   • Another sub-point under this step
   • Additional details for this step

2. **Main Step Two**: Description
   • Sub-point for step two
   • Another detail with indentation
   • More specifics under this step

3. **Main Step Three**: Description
   • Properly indented sub-point
   • Additional sub-information

### Important Notes
• **Critical information** in bold
• Additional context or warnings

INDENTATION RULES:
- Main numbered steps start at the left margin
- Sub-points use 3 spaces + bullet (•) for proper indentation
- This creates clear visual hierarchy and readability

CONTENT RULES:
- Extract information from the provided context - it contains relevant answers
- Be comprehensive but well-organized
- Use the context to provide specific, accurate information
- Include relevant details from the documentation
- Make responses scannable with clear visual hierarchy
"""
            
            # Create the specific request for the AI
            # Like giving the research assistant the question and materials
            if search_mode == "all_versions":
                user_prompt = f"""Question: {query}

Context from knowledge base (MULTIPLE VERSIONS):
{context}

CRITICAL INSTRUCTIONS FOR ALL VERSIONS ANALYSIS:
1. The context above contains information from MULTIPLE document versions (clearly labeled with version numbers in the format "--- VERSION X ---")

2. COMPARISON PROCESS (MANDATORY):
   - CAREFULLY READ the actual text content from each version section
   - COMPARE word-by-word, sentence-by-sentence to identify REAL differences
   - Look for: different wording, added/removed steps, changed procedures, new information, removed information
   - If content is EXACTLY the same: state "The information is IDENTICAL across all versions"
   - If content has ANY differences: you MUST show the actual content from each version

3. RESPONSE STRUCTURE BASED ON FINDINGS:

   **IF CONTENT IS IDENTICAL:**
   - State clearly: "The information is IDENTICAL across all versions (2024.3.1, 2024.3.2, 2024.3.3)"
   - Present the unified information ONCE
   - Do NOT repeat for each version

   **IF CONTENT HAS DIFFERENCES:**
   - You MUST show the actual content from EACH version
   - Structure as:
     * **Common Elements**: What is the same across all versions
     * **Key Differences**: What differs between versions
     * **Version-Specific Content**: 
       - **Version 2024.3.1**: [Show actual text/content from this version]
       - **Version 2024.3.2**: [Show actual text/content from this version, highlight what's different]
       - **Version 2024.3.3**: [Show actual text/content from this version, highlight what's different]
   - Include actual quotes or paraphrased content from each version to show the differences
   - Explain what changed and why it matters

4. KEY REQUIREMENTS:
   - ALWAYS identify and state key similarities explicitly
   - ALWAYS identify and state key differences explicitly (if any exist)
   - If differences exist, you MUST display the context from different versions
   - If no differences exist, present one unified answer
   - Be specific - don't say "minor differences" without showing what they are

5. QUALITY CHECK:
   - Did you actually compare the content? Or did you assume it's the same?
   - If you found differences, did you show the actual content from each version?
   - If you found no differences, did you clearly state that and present unified information?

FORMATTING REQUIREMENTS - FOLLOW EXACTLY:
1. Start with ## heading for the main topic
2. Add blank lines between ALL sections
3. Use ### for subsections
4. Use • for bullet points (not - or *)
5. Use 1., 2., 3. for numbered steps
6. Bold important terms with **text**
7. Keep paragraphs short (2-3 sentences)
8. Add proper spacing throughout
9. Use version labels (e.g., **Version 2024.3.1**:) ONLY when showing actual differences

Analyze the context carefully. Compare the actual content from each version. If they're identical, say so once and present unified information. If they differ, show the differences clearly. Avoid unnecessary repetition."""
            else:
                user_prompt = f"""Question: {query}

Context from knowledge base:
{context}

FORMATTING REQUIREMENTS - FOLLOW EXACTLY:
1. Start with ## heading for the main topic
2. Add blank lines between ALL sections
3. Use ### for subsections 
4. Use • for bullet points (not - or *)
5. Use 1., 2., 3. for numbered steps
6. Bold important terms with **text**
7. Keep paragraphs short (2-3 sentences)
8. Add proper spacing throughout

Extract the relevant information from the context and present it in an excellently formatted, professional response that is easy to read and scan. The context contains the answers - use it to provide comprehensive, well-structured information."""

            # Send the request to OpenAI and get the response
            # Like submitting the research request and waiting for the completed report
            self.logger.debug("RAGAgent", "generate_response", f"Sending request to OpenAI for response generation (mode: {search_mode})")
            
            # Incorporate recent compact conversation history (role,user/assistant,content)
            history_msgs: List[Dict[str, str]] = []
            for m in (history or [])[-8:]:  # keep it small
                role = m.get("role", "user")
                content = m.get("content", "")
                if content:
                    history_msgs.append({"role": role, "content": content})

            response = self.openai_client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": system_prompt},
                    *history_msgs,
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.15,
                max_tokens=1500  # Increased for better formatted responses
            )
            
            # Extract the AI's written response
            # Like getting the completed research report back
            generated_response = response.choices[0].message.content
            self.logger.info("RAGAgent", "generate_response", f"Successfully generated response with {len(generated_response)} characters (mode: {search_mode})")
            return generated_response
            
        except Exception as e:
            # If the AI service is unavailable or fails, log and tell the user what happened
            self.logger.error("RAGAgent", "generate_response", f"Error generating response: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Error generating response: {str(e)}")

    def generate_direct_response(self, query: str) -> str:
        """
        Generate a direct answer without consulting the RAG index. Suitable for
        non-document queries. IMPORTANT: The assistant is scoped to company-uploaded
        documents only. It should not answer general knowledge or out-of-scope
        questions. For out-of-scope requests, clearly state the scope and invite the
        user to ask a document-related question so RAG can be used.
        """
        self.logger.debug("RAGAgent", "generate_direct_response", f"Generating direct response for query: {query[:50]}...")
        try:
            # First, try a lightweight small-talk template to avoid repetitive phrasing
            templated = self._small_talk_reply(query)
            if templated:
                return templated

            # Lightly vary tone to avoid repetitive phrasing while keeping scope strict
            tone_tag = random.choice([
                "friendly and concise",
                "warm and professional",
                "clear and to-the-point",
                "polite and efficient"
            ])

            # Time-of-day hint for more natural greetings
            now = datetime.now()
            hour = now.hour
            if 5 <= hour < 12:
                time_hint = "morning"
            elif 12 <= hour < 17:
                time_hint = "afternoon"
            elif 17 <= hour < 22:
                time_hint = "evening"
            else:
                time_hint = ""

            # Rotate subtle style suggestions (not phrases)
            styles = [
                "offer one clarifying question",
                "ask which document or repo the user has in mind",
                "ask what task they’re trying to complete",
                "ask what page/section or topic to search first"
            ]
            style_hint = styles[self._style_index % len(styles)]
            self._style_index += 1

            last_hint = (self.last_direct_response[:200] + "...") if self.last_direct_response else ""
            system_prompt = (
                "You are Synapse, a helpful AI assistant trained only on the company's documentation. "
                "Your scope is limited to what can be supported by those documents. "
                "Policies: "
                "1) Do NOT answer general knowledge or out-of-scope questions; instead, gently and politely state your scope. "
                "2) Be concise (1–2 sentences for greetings/casual prompts) and empathetic. "
                "3) Vary your phrasing naturally across turns (avoid repeating identical wording). "
                "4) Acknowledge greetings politely, mirror the user's tone lightly, and offer help with company docs. "
                "5) Include a short self-intro when appropriate: you're trained on the company's documentation to help users find answers quickly. "
                "6) Add a short, helpful follow-up tailored to document assistance (e.g., ask what topic, doc name, or task they’re working on). "
                "7) If the user asks for content that requires internal docs, invite them to ask a document-related question so you can search those docs. "
                "8) If asked about personal experiences (e.g., 'how was your day?'), respond kindly that you don't have personal experiences and pivot to helping with documentation. "
                f"Use a {tone_tag} tone. "
                + (f"Avoid repeating the exact phrasing used previously: '{last_hint}'. " if last_hint else "")
                + (f"If the user greets and it's {time_hint}, it's okay to subtly reflect the time of day. " if time_hint else "")
                + f"Also, {style_hint}. "
            )
            # Few-shot style examples (not hardcoded rules). These are for tone and variability only.
            examples = [
                {"role": "user", "content": "hi"},
                {"role": "assistant", "content": "Hi! I'm Synapse, trained on your company's documentation. What topic or document can I help you find?"},
                {"role": "user", "content": "how are you?"},
                {"role": "assistant", "content": "Thanks for asking! I’m here to help you quickly locate answers in your company's documentation—what are you working on?"},
                {"role": "user", "content": "who are you"},
                {"role": "assistant", "content": "I'm Synapse—an assistant trained on your company's documentation to save you time. Tell me a doc name or topic and I'll look it up."},
                {"role": "user", "content": "how was your day?"},
                {"role": "assistant", "content": "I don’t have personal experiences, but I’m here to help with your company's documentation. What document or topic should we look into?"}
            ]
            user_prompt = (
                "User query:\n" + query + "\n\n"
                "Respond under the policies above. If the request is out of scope (not about the company's uploaded documents), "
                "politely decline and restate your scope, then suggest how they can rephrase a document-related question."
            )

            response = self.openai_client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": system_prompt},
                    *examples,
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.75,
                top_p=0.9,
                presence_penalty=0.35,
                frequency_penalty=0.35,
                max_tokens=600
            )
            text = response.choices[0].message.content
            # Retry once with higher randomness if identical to last response
            if text and self.last_direct_response and text.strip() == self.last_direct_response.strip():
                self.logger.debug("RAGAgent", "generate_direct_response", "Direct response matched previous; retrying for variation")
                response = self.openai_client.chat.completions.create(
                    model="gpt-4o-mini",
                    messages=[
                        {"role": "system", "content": system_prompt},
                        *examples,
                        {"role": "user", "content": user_prompt}
                    ],
                    temperature=0.9,
                    top_p=0.95,
                    presence_penalty=0.5,
                    frequency_penalty=0.4,
                    max_tokens=600
                )
                text = response.choices[0].message.content
            # Save for next turn to reduce repetition
            self.last_direct_response = (text or "")
            self.logger.info("RAGAgent", "generate_direct_response", f"Direct response generated with {len(text)} characters")
            return text
        except Exception as e:
            self.logger.error("RAGAgent", "generate_direct_response", f"Error generating direct response: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Error generating direct response: {str(e)}")
    
    def query_agent(self, query: str, history: List[Dict[str, str]] | None = None, version: str | None = None, threshold: float = 0.3) -> Dict[str, Any]:
        """
        This is the main function that coordinates the entire question-answering process.
        
        Think of this like the head librarian who receives your question and coordinates
        all the staff to find the best answer for you. They manage the entire process
        from start to finish.
        
        Args:
            query (str): The user's question in plain English
            history (List[Dict[str, str]], optional): Conversation history for context
            version (str, optional): Specific document version to search in
            threshold (float, optional): Similarity threshold for document retrieval (0.0-1.0)
                - Lower values (0.2-0.3): More results, less precise matching
                - Higher values (0.4-0.6): Fewer results, more precise matching
            
        Returns:
            Dict[str, Any]: A complete response package with the answer, sources, and metadata
        """
        self.logger.info("RAGAgent", "query_agent", f"Processing query: {query[:100]}...")
        
        try:
            # First, check if the user actually asked a question
            # Like making sure someone didn't hand you a blank piece of paper
            if not query.strip():
                self.logger.warning("RAGAgent", "query_agent", "Empty query provided")
                raise HTTPException(status_code=400, detail="Query cannot be empty")
            
            # Step 1: Decide if this requires RAG (document-related) or not
            query_type = self.classify_query_type_smart(query)
            if query_type == "non_document":
                direct_response = self.generate_direct_response(query)
                return {
                    "response": direct_response,
                    "sources": [],
                    "query": query,
                    "chunks_used": 0,
                    "chunks_data": [],  # No chunks for non-document queries
                    "query_type": "non_document",
                    "low_confidence": False
                }

            # Step 2: Convert the user's question into computer-searchable format
            # Like translating the question into the library's filing system language
            query_embedding = self.create_query_embedding(query)
            
            # Step 2: Search through all documents to find relevant pieces
            # Like having staff search through all filing cabinets for relevant materials
            # Allow configuring top_k via environment (default 15 for better coverage)
            try:
                top_k = int(os.getenv("RAG_TOP_K", "15"))
            except ValueError:
                top_k = 15
            relevant_chunks = self.search_relevant_chunks(query_embedding, top_k=top_k, version=version)
            
            # Determine search mode for response generation
            # Get search_mode from chunks if available, otherwise determine from version parameter
            if relevant_chunks and len(relevant_chunks) > 0:
                search_mode = relevant_chunks[0].get('search_mode', 'default')
            elif version is None or (isinstance(version, str) and (version.strip() == "" or version.strip().lower() in ["all versions", "all", "*"])):
                search_mode = "all_versions"
            elif version and isinstance(version, str) and version.strip():
                search_mode = "specific_version"
            else:
                search_mode = "all_versions"
            
            self.logger.info("RAGAgent", "query_agent", f"Search mode determined: {search_mode} (version parameter: {version})")
            
            # Check if we found any relevant information
            if not relevant_chunks:
                self.logger.warning("RAGAgent", "query_agent", f"No relevant chunks found for query: '{query[:50]}...' (version={version})")
                return {
                    "response": "I couldn't find any relevant information in the uploaded documents to answer your question. Please make sure you have uploaded the relevant documentation.",
                    "sources": [],
                    "query": query,
                    "chunks_used": 0,
                    "chunks_data": [],  # No chunks found
                    "query_type": "document_question",
                    "low_confidence": True
                }
            
            # Step 3: Apply user-defined relevance threshold
            # Use the threshold provided by the user (manager can control this from frontend)
            min_score = threshold  # Use the threshold parameter passed from frontend
            filtered_chunks = [c for c in relevant_chunks if c.get("score", 0) >= min_score]
            
            # Log filtering results with threshold explanation
            self.logger.info("RAGAgent", "query_agent", f"After filtering (user_threshold={min_score}): {len(filtered_chunks)}/{len(relevant_chunks)} chunks passed")
            self.logger.info("RAGAgent", "query_agent", f"Threshold explanation: Lower values (0.2-0.3) = more results but less precise, Higher values (0.4-0.6) = fewer results but more precise")
            
            # If no chunks pass threshold, use top 5 instead of 3 (more lenient fallback)
            if not filtered_chunks:
                self.logger.warning("RAGAgent", "query_agent", f"All chunks below threshold {min_score}, using top 5 as fallback")
                filtered_chunks = relevant_chunks[:5]  # Use top 5 as fallback (more lenient)
                low_confidence = True
            else:
                low_confidence = False
            
            # Step 4: Organize all the found information nicely
            # Like arranging all the found materials in a neat stack for the expert to review
            context = self.format_context(filtered_chunks)
            
            # Step 5: Use AI to create a concise, well-structured answer
            # Like having an expert professor review all the materials and write a detailed response
            response = self.generate_response(query, context, history or [], search_mode)
            response = normalize_markdown_structure(response)
            
            # Step 5: Prepare information about where the answer came from
            # Like creating a bibliography showing which books were used
            # Deduplicate by filename and cap by RAG_MAX_SOURCES (default 5)
            try:
                max_sources = int(os.getenv("RAG_MAX_SOURCES", "5"))
            except ValueError:
                max_sources = 5
            # Build unique sources by filename+version (for all_versions mode) or just filename (for single version)
            def _norm_name(n: str) -> str:
                n = (n or "").strip()
                # If any path separators sneaked in metadata, drop to basename
                for sep in ["/", "\\"]:
                    if sep in n:
                        n = n.split(sep)[-1]
                return n

            # Check if we're in all_versions mode
            is_all_versions = search_mode == "all_versions"
            
            # Use filename+version as key for all_versions mode, just filename for single version
            by_key: Dict[str, Dict[str, Any]] = {}
            for chunk in filtered_chunks:
                fname = _norm_name(chunk.get("filename", ""))
                if not fname:
                    continue

                # Get document information directly from the chunk data
                doc_id = chunk.get("document_id")
                file_hash = chunk.get("file_hash")
                score = float(chunk.get("score", 0) or 0)
                version = chunk.get("version", "Unknown")
                
                # Normalize version to ensure consistent format
                if version and version != "Unknown":
                    if version.startswith("v_"):
                        version_normalized = version.replace("v_", "").replace("_", ".")
                    else:
                        version_normalized = version
                else:
                    version_normalized = version
                
                # Create unique key: filename+version for all_versions, just filename for single version
                if is_all_versions:
                    key = f"{fname}|||{version_normalized}"  # Use ||| as separator (unlikely to appear in filenames)
                else:
                    key = fname
                
                # Use key for deduplication
                if key not in by_key:
                    # First time seeing this key - create entry
                    download_url = f"/download/{doc_id}" if doc_id else None
                    by_key[key] = {
                        "filename": fname,
                        "version": version_normalized if is_all_versions else None,  # Store normalized version
                        "document_id": doc_id,
                        "download_url": download_url,
                        "best_relevance_score": score,
                        "chunk_count": 1,
                        "file_hash": file_hash,  # Keep for reference
                    }
                else:
                    # Already seen this key - update with best score and document_id
                    entry = by_key[key]
                    entry["chunk_count"] += 1
                    
                    # Update with best score
                    if score > entry.get("best_relevance_score", 0):
                        entry["best_relevance_score"] = score
                    
                    # Prefer document_id if we have one (some chunks might have it, others might not)
                    if doc_id and not entry.get("document_id"):
                        entry["document_id"] = doc_id
                        entry["download_url"] = f"/download/{doc_id}"
                    elif doc_id and entry.get("document_id") != doc_id:
                        # If we have multiple document_ids for same key, prefer the one with better score
                        if score > entry.get("best_relevance_score", 0):
                            entry["document_id"] = doc_id
                            entry["download_url"] = f"/download/{doc_id}"

            # Sort unique documents by their best score
            unique_docs = sorted(by_key.values(), key=lambda x: x.get("best_relevance_score", 0), reverse=True)
            
            # For all_versions mode, ensure we have representation from each version
            if is_all_versions:
                # Group sources by version
                sources_by_version = {}
                for doc in unique_docs:
                    version = doc.get("version", "Unknown")
                    if version not in sources_by_version:
                        sources_by_version[version] = []
                    sources_by_version[version].append(doc)
                
                # If we have multiple versions, ensure representation from each
                if len(sources_by_version) > 1:
                    # Take at least one source from each version, then fill remaining slots with best overall
                    balanced_sources = []
                    
                    # First pass: take top source from each version
                    for version, version_sources in sources_by_version.items():
                        if version_sources:
                            balanced_sources.append(version_sources[0])
                    
                    # Second pass: fill remaining slots with best overall sources
                    remaining_slots = max_sources - len(balanced_sources)
                    if remaining_slots > 0:
                        used_keys = {f"{d['filename']}|||{d.get('version', '')}" if is_all_versions and d.get('version') else d['filename'] for d in balanced_sources}
                        for doc in unique_docs:
                            doc_key = f"{doc['filename']}|||{doc.get('version', '')}" if is_all_versions and doc.get('version') else doc['filename']
                            if doc_key not in used_keys and remaining_slots > 0:
                                balanced_sources.append(doc)
                                remaining_slots -= 1
                    
                    # Sort by score again
                    unique_docs = sorted(balanced_sources, key=lambda x: x.get("best_relevance_score", 0), reverse=True)
                elif max_sources > 0:
                    # Single version, just cap
                    unique_docs = unique_docs[:max_sources]
            elif max_sources > 0:
                # For single version mode, just cap by max_sources
                unique_docs = unique_docs[:max_sources]

            # Build a map of chunks by source key (filename+version) for easy lookup
            chunks_by_source = {}
            for chunk in filtered_chunks:
                fname = _norm_name(chunk.get("filename", ""))
                if not fname:
                    continue
                version = chunk.get("version", "Unknown")
                
                # Normalize version to ensure consistent matching
                # Handle both "2024.3.1" format and "v_2024_3_1" format
                if version and version != "Unknown":
                    # If version looks like a schema name, convert it
                    if version.startswith("v_"):
                        version_normalized = version.replace("v_", "").replace("_", ".")
                    else:
                        version_normalized = version
                else:
                    version_normalized = version
                
                # For all_versions mode, use filename+version as key
                # For specific version mode, use just filename (all chunks are from same version)
                if is_all_versions:
                    source_key = f"{fname}|||{version_normalized}"
                else:
                    # In single version mode, use just filename since all chunks are from the same version
                    source_key = fname
                
                if source_key not in chunks_by_source:
                    chunks_by_source[source_key] = []
                
                chunks_by_source[source_key].append({
                    "chunk_index": chunk.get("chunk_index", 0),
                    "text": chunk.get("text", ""),
                    "relevance_score": round(chunk.get("score", 0), 4),
                    "chunk_id": chunk.get("id"),
                })
            
            # Format sources for client with chunk information
            sources = []
            for d in unique_docs:
                # Normalize filename to match the format used when building chunks_by_source
                normalized_filename = _norm_name(d['filename'])
                
                # Normalize version to match the format used when building chunks_by_source
                source_version = d.get('version', 'Unknown')
                if source_version and source_version != "Unknown":
                    # Normalize version format to match chunks
                    if source_version.startswith("v_"):
                        source_version_normalized = source_version.replace("v_", "").replace("_", ".")
                    else:
                        source_version_normalized = source_version
                else:
                    source_version_normalized = source_version
                
                # Match the same key format used when building chunks_by_source
                if is_all_versions and source_version_normalized:
                    source_key = f"{normalized_filename}|||{source_version_normalized}"
                else:
                    # For single version mode, use just normalized filename
                    source_key = normalized_filename
                
                source_chunks = chunks_by_source.get(source_key, [])
                
                # If no chunks found with exact key match, try to find chunks by filename and version
                # This handles edge cases where version format might not match exactly
                if not source_chunks:
                    # Try matching by filename and version (for all_versions mode)
                    if is_all_versions and source_version_normalized:
                        # Try different version formats
                        for key, chunks in chunks_by_source.items():
                            # Check if filename matches and version is in the key
                            if normalized_filename in key and (source_version_normalized in key or source_version in key or d.get('version', '') in key):
                                source_chunks = chunks
                                self.logger.debug("RAGAgent", "query_agent", f"Matched chunks for {d['filename']} version {source_version_normalized} using key: {key}")
                                break
                    else:
                        # For single version mode, try matching by filename only
                        for key, chunks in chunks_by_source.items():
                            # Check if key matches the normalized filename (might have version suffix)
                            if key == normalized_filename or key.startswith(normalized_filename + "|||"):
                                source_chunks = chunks
                                break
                
                # Log if chunks were found or not
                if not source_chunks:
                    self.logger.warning("RAGAgent", "query_agent", f"No chunks found for source: {d['filename']} version: {source_version_normalized} (key: {source_key})")
                else:
                    self.logger.debug("RAGAgent", "query_agent", f"Found {len(source_chunks)} chunks for source: {d['filename']} version: {source_version_normalized}")
                
                sources.append({
                    "filename": d["filename"],
                    "version": d.get("version"),  # Include version for all_versions mode
                    "relevance_score": round(d.get("best_relevance_score", 0), 4),
                    "document_id": d.get("document_id"),
                    "download_url": d.get("download_url"),
                    "_internal_chunk_count": d.get("chunk_count", 1),
                    "chunks": source_chunks,  # Include chunks for this source
                })
            
            # Return the complete response package
            # Like handing you a research report with the answer, sources, and summary
            # Identify a strongly matching primary source for a direct download CTA
            try:
                strong_score = float(os.getenv("RAG_STRONG_SCORE", "0.6"))
            except ValueError:
                strong_score = 0.6
            primary = None
            if filtered_chunks:
                top = filtered_chunks[0]
                if top.get("score", 0) >= strong_score:
                    fname = top.get("filename")
                    doc_id = top.get("document_id")
                    version = top.get("version") if is_all_versions else None
                    
                    # For PostgreSQL, we can create download URLs directly from document_id
                    download_url = f"/download/{doc_id}" if doc_id else None
                    
                    primary = {
                        "filename": fname,
                        "version": version,
                        "relevance_score": round(top.get("score", 0), 4),
                        "document_id": doc_id,
                        "download_url": download_url
                    }

            result = {
                "response": response,  # The actual answer to your question
                "sources": sources,  # List of documents that were used
                "query": query,  # Your original question (for reference)
                "chunks_used": len(filtered_chunks),  # How many document pieces were used
                "chunks_data": filtered_chunks,  # The actual chunks that were used (for storage)
                "query_type": "document_question",
                "low_confidence": low_confidence,
                "best_match": primary
            }
            
            self.logger.info("RAGAgent", "query_agent", f"Successfully processed query with {len(filtered_chunks)} filtered chunks used")
            return result
            
        except HTTPException:
            # If it's a known error (like empty query), just pass it along
            raise
        except Exception as e:
            # If something unexpected went wrong, log and explain what happened
            # Like if the entire library system crashed, we explain the problem
            self.logger.error("RAGAgent", "query_agent", f"Unexpected error in query processing: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Unexpected error in query processing: {str(e)}")

def normalize_markdown_structure(text: str) -> str:
    """
    Clean up LLM responses to ensure headings are not rendered as numbered lists and
    that explanatory text directly associated with headings is not turned into list items.
    """
    if not text:
        return text

    lines = text.splitlines()
    cleaned: List[str] = []
    in_step_section = False
    in_version_section = False
    skip_blank_after_heading = False

    def append_line(line: str):
        nonlocal skip_blank_after_heading
        if cleaned and cleaned[-1] == "" and line == "":
            return
        if line == "" and skip_blank_after_heading:
            return
        cleaned.append(line)
        if line.startswith("##") or line.startswith("###"):
            skip_blank_after_heading = True
        elif line != "":
            skip_blank_after_heading = False

    for line in lines:
        stripped = line.strip()
        candidate = re.sub(r"^[\-\*•]+\s*", "", stripped)
        candidate = candidate.strip()

        if not stripped:
            append_line("")
            continue

        heading_match = re.match(r"^\d+\.\s*(.+?:)\s*$", candidate)
        version_heading_match = re.match(r"^(?:\*\*)?(Version\s+[0-9\.]+\s*.*?)(?:\*\*)?:?\s*$", candidate, re.IGNORECASE)

        if heading_match:
            heading_text = heading_match.group(1).rstrip(":")
            append_line(f"### {heading_text}")
            in_step_section = heading_text.lower().startswith("step-by-step")
            in_version_section = False
            continue

        if version_heading_match and version_heading_match.group(1).lower().startswith("version"):
            heading_text = version_heading_match.group(1).strip("* ").rstrip(":")
            append_line(f"### {heading_text}")
            in_step_section = False
            in_version_section = True
            continue

        if candidate.startswith("## "):
            append_line(candidate)
            in_step_section = candidate.lower().startswith("## step-by-step")
            in_version_section = candidate.lower().startswith("## version")
            continue

        if candidate.startswith("### "):
            append_line(candidate)
            in_step_section = candidate.lower().startswith("### step-by-step")
            in_version_section = candidate.lower().startswith("### version")
            continue

        if not in_step_section:
            if in_version_section:
                text_line = re.sub(r'^\d+\.\s*', '', stripped).strip()
                text_line = re.sub(r'^[\-\*•]+\s*', '', text_line).strip()
                if not text_line:
                    continue

                context_match = re.match(r"^context:?\s*$", text_line, re.IGNORECASE)
                if context_match:
                    continue

                if re.match(r"^key points|^changes", text_line, re.IGNORECASE):
                    append_line(f"    • {text_line}")
                else:
                    append_line(f"    {text_line}")
                continue
            stripped_no_num = re.sub(r"^\d+\.\s*", "", stripped)
            if stripped_no_num.startswith('"') and stripped_no_num.endswith('"'):
                stripped_no_num = stripped_no_num[1:-1]

            append_line(stripped_no_num)
            continue

        append_line(stripped)

    while cleaned and cleaned[0] == "":
        cleaned.pop(0)

    return "\n".join(cleaned).strip()


# Create a global instance of our RAG agent that the main application can use
# Think of this like hiring a permanent head librarian for our document system
rag_agent = RAGAgent()
