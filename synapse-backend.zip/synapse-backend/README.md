# 🧠 Synapse RAG System

A modern document processing and querying system using RAG (Retrieval Augmented Generation) with FastAPI, PostgreSQL, and PGVector. Built for ID-Ware Group's document management needs.

## ✨ Features

- **🔍 Advanced Document Processing**: PDF text extraction using Docling with pypdf fallback
- **⚡ Fast Vector Search**: PostgreSQL with PGVector extension for lightning-fast similarity search
- **📚 Schema Versioning**: Multiple document versions with isolated PostgreSQL schemas
- **🎨 Modern UI**: ChatGPT-like interface with version selection and precision control
- **👍 Feedback System**: User feedback collection with thumbs up/down for continuous improvement
- **🎯 Precision Control**: Manager-controlled threshold settings for search precision
- **📊 Interaction Tracking**: Comprehensive user interaction analytics and monitoring

## 🏗️ Architecture

- **Backend**: FastAPI with PostgreSQL + PGVector
- **Document Processing**: Docling (preferred) with pypdf fallback
- **Embeddings**: OpenAI text-embedding-3-large (3072 dimensions)
- **Vector Database**: PostgreSQL with PGVector extension and HNSW indexes
- **Frontend**: Vanilla JavaScript with modern dark theme UI
- **Analytics**: Built-in interaction tracking and feedback system

## 📋 Prerequisites

1. **PostgreSQL 12+** with **PGVector extension**
2. **Python 3.8+**
3. **OpenAI API Key**

## 🚀 Quick Start

### 1. Database Setup

**Option A: Using Docker (Recommended)**
```bash
# Pull and run PostgreSQL with PGVector
docker run --name synapse-postgres \
  -e POSTGRES_PASSWORD=your_password \
  -p 5432:5432 \
  -d pgvector/pgvector:pg16
```

**Option B: Manual Installation**
```sql
-- Connect to PostgreSQL as superuser
CREATE DATABASE synapse_rag;
\c synapse_rag;
CREATE EXTENSION IF NOT EXISTS vector;
```

The backend automatically checks for the `vector` extension during startup and will attempt to create it if the configured database user has permission. No manual schema creation is required; see **Automatic Schema Bootstrapping** below.

### Automatic Schema Bootstrapping

Deployments can mirror your local schema names by setting the `PRESEED_SCHEMAS` environment variable (comma-separated). When the service starts, `database/db.py` calls `ensure_version_schema` for each entry—creating schemas such as `2024.3.1`, `2024.3.2`, `2024.3.3` plus their tables before any uploads run. This guarantees DevOps environments have the exact same structure you use today.

### 2. Application Setup

```bash
# Clone and setup
git clone <your-repo>
cd synapse-backend
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env with your settings (see Configuration section below)

# Start the server
python main.py
```

### 3. Access the Application

- **Web Interface**: http://localhost:8000
- **API Documentation**: http://localhost:8000/docs
- **Health Check**: http://localhost:8000/health

## ⚙️ Configuration

Edit your `.env` file with the following settings:

```env
# OpenAI API Configuration
OPENAI_API_KEY=your_openai_api_key_here

# PostgreSQL Database Configuration
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DB=synapse_rag
POSTGRES_USER=postgres
POSTGRES_PASSWORD=your_postgres_password_here
PRESEED_SCHEMAS=2024.3.1,2024.3.2,2024.3.3

# RAG Configuration (Optional)
RAG_TOP_K=5
RAG_MIN_SCORE=0.40
RAG_MAX_SOURCES=5
RAG_FALLBACK_TOP_N=3
```

## 📖 Usage Guide

### Uploading Documents

1. Go to http://localhost:8000/docs (Swagger UI)
2. Use the `/upload` endpoint
3. Select your PDF file
4. Optionally specify a version (e.g., "2024.3.1", "1.0")
5. Execute the upload

### Querying Documents

1. Open http://localhost:8000 in your browser
2. **Select Version**: Choose from the dropdown (or "All Versions")
3. **Set Precision**: Choose search precision level:
   - **Low (0.2)**: More results, less precise - good for exploration
   - **Medium (0.3)**: Balanced - default setting
   - **High (0.4)**: Fewer results, more precise - good for specific questions
   - **Strict (0.5)**: Only highly relevant results
4. **Ask Questions**: Type your question about the documents
5. **Provide Feedback**: Use thumbs up/down to improve the system

### Precision Control Feature

The **Precision** dropdown allows managers to control search behavior:

- **📈 Lower Threshold (0.2-0.3)**: 
  - More document chunks retrieved
  - Broader, more comprehensive answers
  - Better for research and exploration
  
- **📉 Higher Threshold (0.4-0.5)**:
  - Fewer, more relevant chunks
  - Focused, precise answers
  - Better for specific questions

## 🗂️ Schema Versioning

The system supports multiple document versions through PostgreSQL schemas:

- Each version gets its own schema (e.g., `2024.3.1`, `2024.3.2`)
- Tables are completely isolated between versions
- Frontend dropdown allows easy version selection
- API endpoints accept version parameters

### Version Examples

- `"2024.3.1"` → `2024.3.1` schema
- `"1.0"` → `1.0` schema  
- `"default"` → `default` schema
- Empty/null → Most recent schema

## 🔌 API Endpoints

### Public Endpoints

- `GET /` - Main web interface
- `POST /query` - Query documents with version and threshold
- `GET /versions` - List available document versions
- `POST /feedback` - Submit user feedback (thumbs up/down)
- `GET /health` - System health check
- `GET /analytics/interactions` - Interaction analytics (with filters)

### Admin Endpoints

- `POST /upload` - Upload PDF documents
- `GET /download/{document_id}` - Get document information

### Query API Example

```json
POST /query
{
  "question": "What are the system requirements?",
  "version": "2024.3.1",
  "threshold": 0.35,
  "history": []
}
```

### Feedback API Example

```json
POST /feedback
{
  "question": "What are the system requirements?",
  "response": { ... },
  "rating": "up",
  "comment": "Very helpful answer!"
}
```

## 🗃️ Database Schema

Each version schema contains these tables:

### Documents Table
```sql
CREATE TABLE documents (
    id UUID PRIMARY KEY,
    filename VARCHAR(255) NOT NULL,
    file_hash VARCHAR(64) UNIQUE NOT NULL,
    file_size BIGINT NOT NULL,
    page_count INTEGER NOT NULL,
    word_count INTEGER NOT NULL,
    content_type VARCHAR(100) NOT NULL,
    full_text TEXT NOT NULL,
    status VARCHAR(50) DEFAULT 'processed',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
```

### Chunks Table
```sql
CREATE TABLE chunks (
    id UUID PRIMARY KEY,
    document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    chunk_index INTEGER NOT NULL,
    text TEXT NOT NULL,
    embedding VECTOR(3072),  -- OpenAI text-embedding-3-large
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- HNSW index for fast vector similarity search
CREATE INDEX chunks_embedding_idx ON chunks 
USING hnsw (embedding vector_cosine_ops) 
WITH (m = 16, ef_construction = 64);
```

### QA Interactions Table
```sql
CREATE TABLE qa_interactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    question TEXT NOT NULL,
    response JSONB NOT NULL,
    rating VARCHAR(10) DEFAULT 'none',  -- 'none', 'up', 'down'
    comment TEXT DEFAULT '',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
```

## 📁 Project Structure

```
synapse-backend/
├── database/
│   ├── __init__.py
│   └── db.py                    # PostgreSQL + PGVector manager
├── Utils/
│   └── LoggingService.py        # Structured logging system
├── static/
│   ├── css/styles.css           # Modern dark theme UI
│   └── js/app.js                # Frontend JavaScript
├── logs/                        # Application logs
├── main.py                      # FastAPI application & API endpoints
├── agent.py                     # RAG query processing & vector search
├── process_documents.py         # Document processing with Docling
├── requirements.txt             # Python dependencies
├── .env.example                 # Environment configuration template
├── .env                         # Your environment configuration
├── index.html                   # Main web interface
├── THRESHOLD_FEATURE_GUIDE.md   # Precision control documentation
└── README.md                    # This file
```

## 🔧 Key Components

1. **DatabaseManager** (`database/db.py`): 
   - PostgreSQL connections and schema management
   - PGVector operations and HNSW indexing
   - Version-based schema isolation

2. **DocumentProcessor** (`process_documents.py`): 
   - PDF processing with Docling and pypdf fallback
   - Intelligent text chunking
   - OpenAI embedding creation

3. **RAGAgent** (`agent.py`): 
   - Query processing and embedding generation
   - Vector similarity search with user-defined thresholds
   - Response generation with context formatting

4. **Frontend** (`static/`, `index.html`): 
   - Modern ChatGPT-like interface
   - Version selection and precision control
   - Real-time feedback system

## 📊 Analytics & Monitoring

The system includes comprehensive interaction tracking:

- **User Interactions**: All queries and responses logged
- **Feedback System**: Thumbs up/down with comments
- **Performance Metrics**: Response times and chunk usage
- **Version Analytics**: Usage patterns across document versions
- **Threshold Analysis**: Impact of different precision settings

Access analytics via: `GET /analytics/interactions`

## 🛠️ Troubleshooting

### Database Connection Issues

1. **Check PostgreSQL is running**:
   ```bash
   # Check if PostgreSQL is running
   docker ps  # If using Docker
   # OR
   sudo systemctl status postgresql  # If installed locally
   ```

2. **Verify connection settings** in `.env` file

3. **Test PGVector extension**:
   ```sql
   \c synapse_rag;
   SELECT * FROM pg_extension WHERE extname = 'vector';
   ```

### Document Upload Issues

1. **Verify OpenAI API key** is valid and has credits
2. **Check PDF file** is not corrupted or password-protected
3. **Ensure sufficient disk space** for document processing
4. **Check logs** in `logs/synapse_logs.log` for detailed errors

### Query Issues

1. **Ensure documents are uploaded** and processed successfully
2. **Check embedding creation** completed without errors
3. **Verify PGVector indexes** are created properly
4. **Try different threshold values** if getting too few/many results
5. **Test with simple queries** first before complex ones

### Frontend Issues

1. **Clear browser cache** and refresh the page
2. **Check browser console** for JavaScript errors
3. **Verify server is running** on http://localhost:8000
4. **Test API endpoints** directly via Swagger UI

## 🔄 Migration from Legacy Systems

This system replaces MongoDB + Pinecone architecture:

| Component | Legacy | New |
|-----------|--------|-----|
| **Document Storage** | MongoDB | PostgreSQL |
| **Vector Storage** | Pinecone | PostgreSQL + PGVector |
| **Search** | Pinecone API | Native PostgreSQL vector ops |
| **Schemas** | MongoDB Collections | PostgreSQL Schemas |
| **Indexes** | Pinecone indexes | HNSW indexes |

### Migration Benefits

- ✅ **Simplified Architecture**: Single database instead of two services
- ✅ **Better Performance**: Native PostgreSQL vector operations
- ✅ **Cost Effective**: No external vector database fees
- ✅ **Easier Deployment**: One database to manage
- ✅ **ACID Compliance**: Full transactional support
- ✅ **Better Scaling**: PostgreSQL's proven scalability

## 🤝 Support

For issues or questions:

1. **Check logs**: `logs/synapse_logs.log`
2. **Test API**: Use Swagger UI at `/docs`
3. **Verify configuration**: Check `.env` settings
4. **Database health**: Use `/health` endpoint

## 📄 License

Internal use for ID-Ware Group projects.

---


