"""
Main FastAPI application for Synapse RAG system.
This file is like the front desk of a hotel - it greets visitors (web requests),
understands what they want, and directs them to the right services.
It provides two main services: uploading documents and answering questions about them.
"""

# Import necessary tools (like gathering staff and equipment for our hotel)
from fastapi import FastAPI, UploadFile, File, HTTPException, Form, Request  # Tools to create a web server
from fastapi.middleware.cors import CORSMiddleware  # Tool to allow websites to talk to our server
from fastapi.responses import FileResponse, StreamingResponse  # Tool to send files back to users
from pydantic import BaseModel  # Tool to define what data we expect from users
from datetime import datetime  # For timestamps
from typing import Dict, Any, List, Optional  # Tool to specify what type of data we work with
import uvicorn  # Tool to actually run our web server
import json  # Tool to work with JSON data format
import time  # For timing measurements
import uuid  # For generating unique IDs
from io import BytesIO  # Tool to handle binary data streams
from sqlalchemy import text  # Tool for raw SQL queries
from database.db import db_manager  # Database manager

# Import our custom modules (like hiring specialized staff)
from process_documents import document_processor  # Our document processing specialist
from agent import rag_agent  # Our question-answering specialist
from Utils.LoggingService import LoggingService  # Our logging service
from database.db import db, db_manager  # Database managers
from sqlalchemy import text  # Tool for raw SQL queries

# Initialize logging service
logger = LoggingService()
logger.info("MainApp", "startup", "Initializing Synapse RAG System")

# Initialize FastAPI app (like opening our hotel for business)
app = FastAPI(
    title="Synapse RAG System",  # The name of our service
    description="A document processing and querying system using RAG (Retrieval Augmented Generation)",  # What we do
    version="1.0.0"  # Current version of our system
)

logger.info("MainApp", "startup", "FastAPI application initialized")

# Add CORS middleware for frontend integration
# Like setting up rules that allow different websites to talk to our server safely
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow requests from any website (configure this properly for production)
    allow_credentials=True,  # Allow websites to send credentials
    allow_methods=["*"],  # Allow all types of requests (GET, POST, etc.)
    allow_headers=["*"],  # Allow all types of headers in requests
)

# Pydantic model for query requests
# This defines the format we expect when someone asks a question
# Like creating a form that visitors must fill out when asking questions
class QueryRequest(BaseModel):
    question: str  # The question must be a text string
    history: Optional[List[Dict[str, str]]] = None  # Optional compact conversation history [{role, content}]
    version: Optional[str] = None  # Optional document version constraint
    threshold: Optional[float] = 0.3  # Similarity threshold for document retrieval (0.0-1.0)

# Pydantic model for feedback submissions
class FeedbackRequest(BaseModel):
    question: str
    response: Dict[str, Any]  # Entire response object returned by the backend
    rating: str  # 'up' or 'down'
    comment: Optional[str] = None
    client_meta: Optional[Dict[str, Any]] = None

# Root endpoint - API information
@app.get("/", tags=["Public"], summary="API Information")
async def root():
    """
    API root endpoint. Returns API information.
    Frontend is served separately.
    """
    return {
        "name": "Synapse RAG System API",
        "version": "1.0.0",
        "docs": "/docs",
        "health": "/health"
    }

# Upload endpoint - Where people bring documents to process
@app.post("/upload", tags=["Admin"], summary="Upload Document (Admin Only)")
async def upload_document(file: UploadFile = File(...), version: Optional[str] = Form(None)) -> Dict[str, Any]:
    """
    Accept and process PDF documents from users.

    Think of this like a document processing counter at our hotel where guests
    can drop off documents to be scanned, organized, and filed for future reference.

    The complete workflow:
    1. Accept the PDF file from the user
    2. Extract all text and gather file information
    3. Check if we've already processed this exact file
    4. Store the document permanently in our database
    5. Break it into searchable pieces and index them

    Args:
        file (UploadFile): The PDF file uploaded by the user

    Returns:
        Dict[str, Any]: A report on what happened (success/failure with details)
    """
    logger.info("MainApp", "upload_document", f"Upload request received for file: {file.filename if file else 'None'}")
    
    try:
        # First, make sure the user actually sent us a file
        # Like checking if someone handed us something at the counter
        if not file:
            logger.warning("MainApp", "upload_document", "No file provided in upload request")
            raise HTTPException(status_code=400, detail="No file provided")

        # Send the file to our document processing specialist
        # Like handing the document to our filing clerk to process
        logger.debug("MainApp", "upload_document", f"Processing file: {file.filename}")
        result = await document_processor.upload_file(file=file, version=version)

        # Return the processing report to the user
        # Like giving a receipt showing what was done with their document
        logger.info("MainApp", "upload_document", f"Upload completed successfully: {file.filename} - Status: {result.get('status', 'unknown')}")
        return result

    except HTTPException:
        # If it's a known error (like wrong file type), just pass it along
        raise
    except Exception as e:
        # If something unexpected went wrong, log and explain what happened
        # Like if our filing system broke down, we explain the problem to the customer
        logger.error("MainApp", "upload_document", f"Upload failed for {file.filename if file else 'unknown'}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")

# Delete endpoint - Delete a document and all its related data
@app.delete("/documents/{document_id}", tags=["Admin"], summary="Delete Document by ID (Admin Only)")
async def delete_document(document_id: str, version: Optional[str] = None) -> Dict[str, Any]:
    """
    Delete a document and all its related data (chunks, PDF files) using CASCADE delete.
    
    When you delete a document from the documents table, PostgreSQL automatically deletes:
    - All chunks associated with that document (ON DELETE CASCADE)
    - All document_files (PDF binaries) associated with that document (ON DELETE CASCADE)
    
    This is a safe, atomic operation - either everything is deleted or nothing is deleted.
    
    Args:
        document_id (str): The UUID of the document to delete
        version (Optional[str]): The version schema to search in. If not provided, searches all schemas.
        
    Returns:
        Dict[str, Any]: Information about what was deleted
    """
    logger.info("MainApp", "delete_document", f"Delete request received for document ID: {document_id}")
    
    try:
        # Determine which schema to use
        if version:
            schema_name = db_manager.sanitize_schema_name(version)
            schemas_to_search = [schema_name]
        else:
            # Search all schemas
            schemas_to_search = db_manager.list_version_schemas()
        
        # Try to find and delete the document in each schema
        for schema_name in schemas_to_search:
            result = document_processor.delete_document(document_id, schema_name)
            
            if result["status"] == "success":
                logger.info("MainApp", "delete_document", f"Document {document_id} deleted successfully from {schema_name}")
                return result
            elif result["status"] == "not_found":
                # Continue searching other schemas
                continue
        
        # If we get here, document wasn't found in any schema
        return {
            "status": "not_found",
            "message": f"Document {document_id} not found in any schema",
            "document_id": document_id
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error("MainApp", "delete_document", f"Delete failed for {document_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Delete failed: {str(e)}")

# Download endpoint - Where people download the actual PDF files
@app.get("/download/{document_id}", tags=["Public"], summary="Download PDF document by document_id")
async def download_document(document_id: str):
    """
    Download the original PDF file by its document ID.
    
    This endpoint serves the actual PDF binary data stored in the document_files table,
    allowing users to download the original uploaded PDF file.

    Args:
        document_id (str): The ID of the document to download

    Returns:
        StreamingResponse: The PDF file as a downloadable stream
    """
    logger.info("MainApp", "download_document", f"PDF download request received for document ID: {document_id}")
    
    try:
        # Search across all version schemas for the document
        schemas = db_manager.list_version_schemas()
        
        for schema_name in schemas:
            try:
                with db_manager.engine.connect() as conn:
                    # Get document metadata and file content in one query using JOIN
                    result = conn.execute(text(f"""
                        SELECT 
                            d.filename, 
                            d.content_type,
                            df.file_content
                        FROM "{schema_name}".documents d
                        INNER JOIN "{schema_name}".document_files df ON d.id = df.document_id
                        WHERE d.id = :document_id
                    """), {"document_id": document_id})
                    
                    row = result.fetchone()
                    if row:
                        filename = row[0]
                        content_type = row[1] or "application/pdf"
                        pdf_content = row[2]
                        
                        # Validate PDF content
                        if pdf_content is None or len(pdf_content) == 0:
                            logger.warning("MainApp", "download_document", f"PDF content is empty for document {document_id} in schema {schema_name}")
                            continue
                        
                        logger.info("MainApp", "download_document", f"Found and serving PDF: {filename} (size: {len(pdf_content)} bytes) from schema {schema_name}")
                        
                        # Return the PDF file for download
                        return StreamingResponse(
                            BytesIO(pdf_content),
                            media_type=content_type,
                            headers={
                                "Content-Disposition": f'attachment; filename="{filename}"',
                                "Content-Length": str(len(pdf_content))
                            }
                        )
                        
            except Exception as e:
                # Log the error but continue searching other schemas
                error_msg = str(e)
                logger.warning("MainApp", "download_document", f"Error in schema {schema_name}: {error_msg}")
                continue
        
        # Document not found in any schema - provide helpful error message
        logger.warning("MainApp", "download_document", f"Document {document_id} not found in any of {len(schemas)} schemas")
        raise HTTPException(status_code=404, detail=f"Document not found: {document_id}")

    except HTTPException:
        # If it's a known error, just pass it along
        raise
    except Exception as e:
        # If something unexpected went wrong, log and explain what happened
        logger.error("MainApp", "download_document", f"PDF download failed for ID {document_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"PDF download failed: {str(e)}")

# Feedback endpoint - Store user feedback and interaction payload
@app.post("/feedback", tags=["Public"], summary="Submit feedback for a Q/A interaction")
async def submit_feedback(payload: FeedbackRequest) -> Dict[str, Any]:
    """
    Store question, response, sources, and user feedback (thumbs up/down and optional comment)
    into PostgreSQL qa_interactions table for analysis and model improvement.
    """
    logger.info("MainApp", "submit_feedback", f"Feedback received: rating={payload.rating}")
    try:
        # Basic validation
        if payload.rating not in ("up", "down"):
            raise HTTPException(status_code=400, detail="rating must be 'up' or 'down'")

        # Store feedback in the same schema where the original interaction was stored
        # Try to find the interaction first to determine the correct schema
        schemas = db_manager.list_version_schemas()
        schema_name = None
        
        # Search all schemas for the original interaction
        for schema in schemas:
            try:
                with db_manager.engine.connect() as conn:
                    existing = conn.execute(text(f"""
                        SELECT id FROM "{schema}".qa_interactions 
                        WHERE question = :question 
                        AND rating = 'none'
                        AND created_at > NOW() - INTERVAL '1 hour'
                        ORDER BY created_at DESC
                        LIMIT 1
                    """), {"question": payload.question})
                    
                    if existing.fetchone():
                        schema_name = schema
                        break
            except:
                continue
        
        # If no interaction found, use most recent schema as fallback
        if not schema_name:
            schema_name = sorted(schemas)[-1] if schemas else db_manager.ensure_version_schema("default")
        
        # Ensure the table has all the comprehensive tracking columns (migration handled by db.py)
        
        # Store the feedback record - update existing interaction or create new one
        with db_manager.engine.begin() as conn:
            # Try to find existing interaction by question and timestamp (within last hour)
            # If found, update it; otherwise create new
            existing = conn.execute(text(f"""
                SELECT id FROM "{schema_name}".qa_interactions 
                WHERE question = :question 
                AND rating = 'none'
                AND created_at > NOW() - INTERVAL '1 hour'
                ORDER BY created_at DESC
                LIMIT 1
            """), {"question": payload.question})
            
            existing_row = existing.fetchone()
            if existing_row:
                # Update existing interaction with feedback
                interaction_id = existing_row[0]
                conn.execute(text(f"""
                    UPDATE "{schema_name}".qa_interactions 
                    SET rating = :rating,
                        comment = :comment,
                        updated_at = :updated_at
                    WHERE id = :id
                """), {
                    "id": interaction_id,
                    "rating": payload.rating,
                    "comment": payload.comment or "",
                    "updated_at": datetime.utcnow()
                })
            else:
                # Create new interaction record with feedback
                conn.execute(text(f"""
                    INSERT INTO "{schema_name}".qa_interactions 
                    (question, response, rating, comment, created_at, updated_at)
                    VALUES (:question, :response, :rating, :comment, :created_at, :updated_at)
                """), {
                    "question": payload.question,
                    "response": json.dumps(payload.response) if isinstance(payload.response, dict) else payload.response,
                    "rating": payload.rating,
                    "comment": payload.comment or "",
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                })
        
        logger.info("MainApp", "submit_feedback", f"Feedback stored successfully in schema: {schema_name}")
        return {"status": "ok", "schema": schema_name}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error("MainApp", "submit_feedback", f"Error saving feedback: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to save feedback")

# Query endpoint - Where people ask questions about documents
@app.post("/query", tags=["Public"], summary="Ask a question about the documents")
async def query_documents(request: QueryRequest, http_request: Request) -> Dict[str, Any]:
    """
    Answer questions about the documents we've processed using AI.

    Think of this like an information desk at our hotel where guests can ask
    questions about anything in our document library, and we provide detailed,
    intelligent answers based on all the documents we've stored.

    The complete workflow:
    1. Accept the user's question
    2. Convert the question into a searchable format
    3. Search through all document pieces to find relevant information
    4. Use AI to generate a comprehensive answer based on what we found
    5. Return the answer along with sources showing where it came from

    Args:
        request (QueryRequest): Contains the user's question

    Returns:
        Dict[str, Any]: Complete answer package with response, sources, and metadata
    """
    # Initialize comprehensive interaction tracking
    interaction_start_time = time.time()
    request_id = str(uuid.uuid4())
    
    # Extract client information for tracking
    client_ip = http_request.client.host if http_request.client else "unknown"
    user_agent = http_request.headers.get("user-agent", "unknown")
    session_id = http_request.headers.get("x-session-id", str(uuid.uuid4()))
    user_id = http_request.headers.get("x-user-id", "anonymous")
    
    logger.info("MainApp", "query_documents", f"Query request received: {request.question[:100] if request.question else 'None'}... [Request ID: {request_id}]")
    
    # Initialize timing and error tracking
    embedding_time_ms = None
    search_time_ms = None
    llm_time_ms = None
    error_occurred = False
    error_type = None
    error_message = None
    result = {}
    
    try:
        # First, make sure the user actually asked a question
        # Like checking if someone said something at the information desk
        if not request.question or not request.question.strip():
            logger.warning("MainApp", "query_documents", "Empty question provided")
            error_occurred = True
            error_type = "validation_error"
            error_message = "Question cannot be empty"
            raise HTTPException(status_code=400, detail="Question cannot be empty")

        # Send the question to our research specialist (RAG agent)
        # Like asking our librarian to research the question and prepare a detailed answer
        logger.debug("MainApp", "query_documents", f"Processing query: {request.question}")
        
        # Time the RAG agent processing
        rag_start_time = time.time()
        result = rag_agent.query_agent(request.question, request.history or [], request.version, request.threshold)
        rag_end_time = time.time()
        
        # Extract timing information from result if available
        embedding_time_ms = result.get("embedding_time_ms")
        search_time_ms = result.get("search_time_ms") 
        llm_time_ms = result.get("llm_time_ms")
        
        # If not provided by agent, calculate total processing time
        if not llm_time_ms:
            llm_time_ms = int((rag_end_time - rag_start_time) * 1000)

        # Clean up the response to make sure it can be sent properly over the internet
        # Like making sure our written response is properly formatted before sending it
        if "response" in result:
            # Remove special characters that might cause problems
            # Like removing smudges or fixing formatting issues on a document
            clean_response = result["response"].replace('\r', '').replace('\t', '    ')

            # Test if the response can be properly sent as JSON data
            # Like checking if our document is properly formatted before mailing it
            try:
                json.dumps(clean_response)  # Test if it's JSON serializable
                result["response"] = clean_response
            except (TypeError, ValueError):
                # If there are still formatting issues, fix them
                # Like retyping a document if the original has formatting problems
                logger.warning("MainApp", "query_documents", "Response formatting issues detected, applying fallback")
                result["response"] = repr(clean_response)[1:-1]  # Remove quotes from repr

        # Return the complete answer package to the user
        # Like handing over a research report with the answer, sources, and bibliography
        logger.info("MainApp", "query_documents", f"Query processed successfully - Sources used: {result.get('chunks_used', 0)}")

        # Calculate total processing time
        total_processing_time = int((time.time() - interaction_start_time) * 1000)
        
        # Persist the comprehensive interaction data immediately
        try:
            # Store interaction in the same schema that was used for the query
            if request.version:
                # Use the specific version that was requested
                schema_name = db_manager.sanitize_schema_name(request.version)
                # Verify the schema exists
                schemas = db_manager.list_version_schemas()
                if schema_name not in schemas:
                    # Fallback to most recent if requested version doesn't exist
                    schema_name = sorted(schemas)[-1] if schemas else db_manager.ensure_version_schema("default")
            else:
                # No specific version requested, use the most recent schema
                schemas = db_manager.list_version_schemas()
                if not schemas:
                    # Create a default schema if none exist
                    schema_name = db_manager.ensure_version_schema("default")
                else:
                    # Use the most recent schema (last in alphabetical order)
                    schema_name = sorted(schemas)[-1]
            
            # Calculate response quality metrics
            response_text = result.get("response", "")
            response_length = len(response_text) if response_text else 0
            confidence_score = result.get("confidence_score", 0.8)  # Default confidence
            hallucination_risk = result.get("hallucination_risk", 0.1)  # Default low risk
            
            # Extract relevance scores from chunks
            chunks_data = result.get("chunks_data", [])
            relevance_scores = [chunk.get("relevance_score", 0.0) for chunk in chunks_data] if chunks_data else []
            
            # System configuration (you can make these configurable)
            model_used = "gpt-4o-mini"  # Update based on actual model
            temperature = 0.1
            max_tokens = 2000
            system_prompt_version = "v1.0"
            
            # Store essential interaction data only
            with db_manager.engine.begin() as conn:
                conn.execute(text(f"""
                    INSERT INTO "{schema_name}".qa_interactions 
                    (question, response, rating, comment, created_at, updated_at)
                    VALUES (:question, :response, :rating, :comment, :created_at, :updated_at)
                """), {
                    "question": request.question,
                    "response": json.dumps(result),  # Full response as JSON
                    "rating": "none",  # Will be updated when user gives feedback
                    "comment": "",
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                })
                logger.info("MainApp", "query_documents", f"Comprehensive interaction stored successfully in schema: {schema_name} [Request ID: {request_id}]")
        except Exception as e:
            logger.error("MainApp", "query_documents", f"Failed to persist interaction: {str(e)}")
            import traceback
            logger.error("MainApp", "query_documents", f"Traceback: {traceback.format_exc()}")

        return result

    except HTTPException as he:
        # If it's a known error (like empty question), still track it
        error_occurred = True
        error_type = "http_error"
        error_message = str(he.detail)
        
        # Try to store the error interaction
        try:
            total_processing_time = int((time.time() - interaction_start_time) * 1000)
            
            # Use the same schema selection logic as successful interactions
            if hasattr(request, 'version') and request.version:
                schema_name = db_manager.sanitize_schema_name(request.version)
                schemas = db_manager.list_version_schemas()
                if schema_name not in schemas:
                    schema_name = sorted(schemas)[-1] if schemas else db_manager.ensure_version_schema("default")
            else:
                schemas = db_manager.list_version_schemas()
                schema_name = sorted(schemas)[-1] if schemas else db_manager.ensure_version_schema("default")
            
            with db_manager.engine.begin() as conn:
                conn.execute(text(f"""
                    INSERT INTO "{schema_name}".qa_interactions 
                    (question, response, rating, comment, created_at, updated_at)
                    VALUES (:question, :response, :rating, :comment, :created_at, :updated_at)
                """), {
                    "question": request.question if hasattr(request, 'question') else "unknown",
                    "response": json.dumps({"error": str(he), "error_type": error_type}),
                    "rating": "none",
                    "comment": f"Error: {error_message}",
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                })
        except Exception as storage_error:
            logger.error("MainApp", "query_documents", f"Failed to store error interaction: {str(storage_error)}")
        
        raise
    except Exception as e:
        # If something unexpected went wrong, log and explain what happened
        error_occurred = True
        error_type = "system_error"
        error_message = str(e)
        
        # Try to store the error interaction
        try:
            total_processing_time = int((time.time() - interaction_start_time) * 1000)
            
            # Use the same schema selection logic as successful interactions
            if hasattr(request, 'version') and request.version:
                schema_name = db_manager.sanitize_schema_name(request.version)
                schemas = db_manager.list_version_schemas()
                if schema_name not in schemas:
                    schema_name = sorted(schemas)[-1] if schemas else db_manager.ensure_version_schema("default")
            else:
                schemas = db_manager.list_version_schemas()
                schema_name = sorted(schemas)[-1] if schemas else db_manager.ensure_version_schema("default")
            
            with db_manager.engine.begin() as conn:
                conn.execute(text(f"""
                    INSERT INTO "{schema_name}".qa_interactions 
                    (question, response, rating, comment, created_at, updated_at)
                    VALUES (:question, :response, :rating, :comment, :created_at, :updated_at)
                """), {
                    "question": request.question if hasattr(request, 'question') else "unknown",
                    "response": json.dumps({"error": str(e), "error_type": error_type}),
                    "rating": "none",
                    "comment": f"System Error: {error_message}",
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                })
        except Exception as storage_error:
            logger.error("MainApp", "query_documents", f"Failed to store error interaction: {str(storage_error)}")
        
        # Like if our research system broke down, we explain the problem to the customer
        logger.error("MainApp", "query_documents", f"Query failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Query failed: {str(e)}")

# Analytics endpoint - View comprehensive interaction data
@app.get("/analytics/interactions", tags=["Admin"], summary="Get comprehensive interaction analytics (Admin Only)")
async def get_interaction_analytics(
    version: Optional[str] = None,
    limit: int = 100,
    offset: int = 0,
    error_only: bool = False,
    user_id: Optional[str] = None,
    session_id: Optional[str] = None
) -> Dict[str, Any]:
    """
    Retrieve comprehensive user interaction analytics from the database.
    
    This endpoint provides detailed insights into user interactions including:
    - User identification and session tracking
    - Performance metrics (processing times)
    - Response quality metrics
    - Error tracking and analysis
    - System configuration used
    - Document retrieval effectiveness
    
    Args:
        version: Specific document version to analyze (optional)
        limit: Maximum number of interactions to return (default: 100)
        offset: Number of interactions to skip (for pagination)
        error_only: If True, only return interactions with errors
        user_id: Filter by specific user ID
        session_id: Filter by specific session ID
    
    Returns:
        Dict containing interaction data and analytics summary
    """
    logger.info("MainApp", "get_interaction_analytics", f"Analytics request - version: {version}, limit: {limit}, error_only: {error_only}")
    
    try:
        # Determine which schema to query
        if version:
            schema_name = db_manager.sanitize_schema_name(version)
        else:
            # Use the most recent schema
            schemas = db_manager.list_version_schemas()
            if not schemas:
                return {"interactions": [], "summary": {"total_count": 0, "error": "No schemas found"}}
            schema_name = sorted(schemas)[-1]
        
        # Build the query with filters
        where_conditions = []
        params = {"limit": limit, "offset": offset}
        
        if error_only:
            where_conditions.append("error_occurred = true")
        
        if user_id:
            where_conditions.append("user_id = :user_id")
            params["user_id"] = user_id
            
        if session_id:
            where_conditions.append("session_id = :session_id")
            params["session_id"] = session_id
        
        where_clause = "WHERE " + " AND ".join(where_conditions) if where_conditions else ""
        
        with db_manager.engine.connect() as conn:
            # Get interaction data
            query = f"""
                SELECT 
                    id, question, bot_response, query_type, rating, comment,
                    chunks_count, relevance_scores, similarity_threshold, max_chunks_requested,
                    user_id, session_id, ip_address, user_agent,
                    request_id, processing_time_ms, embedding_time_ms, search_time_ms, llm_time_ms,
                    response_length, confidence_score, hallucination_risk,
                    model_used, temperature, max_tokens, system_prompt_version, version,
                    error_occurred, error_type, error_message,
                    low_confidence, client_meta, created_at, updated_at
                FROM "{schema_name}".qa_interactions 
                {where_clause}
                ORDER BY created_at DESC 
                LIMIT :limit OFFSET :offset
            """
            
            result = conn.execute(text(query), params)
            interactions = []
            
            for row in result.fetchall():
                interaction = {
                    "id": str(row[0]),
                    "question": row[1],
                    "bot_response": row[2],
                    "query_type": row[3],
                    "rating": row[4],
                    "comment": row[5],
                    "chunks_count": row[6],
                    "relevance_scores": row[7],
                    "similarity_threshold": float(row[8]) if row[8] else None,
                    "max_chunks_requested": row[9],
                    "user_id": row[10],
                    "session_id": row[11],
                    "ip_address": str(row[12]) if row[12] else None,
                    "user_agent": row[13],
                    "request_id": str(row[14]) if row[14] else None,
                    "processing_time_ms": row[15],
                    "embedding_time_ms": row[16],
                    "search_time_ms": row[17],
                    "llm_time_ms": row[18],
                    "response_length": row[19],
                    "confidence_score": float(row[20]) if row[20] else None,
                    "hallucination_risk": float(row[21]) if row[21] else None,
                    "model_used": row[22],
                    "temperature": float(row[23]) if row[23] else None,
                    "max_tokens": row[24],
                    "system_prompt_version": row[25],
                    "version": row[26],
                    "error_occurred": row[27],
                    "error_type": row[28],
                    "error_message": row[29],
                    "low_confidence": row[30],
                    "client_meta": row[31],
                    "created_at": row[32].isoformat() if row[32] else None,
                    "updated_at": row[33].isoformat() if row[33] else None
                }
                interactions.append(interaction)
            
            # Get summary statistics
            summary_query = f"""
                SELECT 
                    COUNT(*) as total_interactions,
                    COUNT(CASE WHEN error_occurred = true THEN 1 END) as error_count,
                    COUNT(CASE WHEN rating = 'up' THEN 1 END) as positive_feedback,
                    COUNT(CASE WHEN rating = 'down' THEN 1 END) as negative_feedback,
                    AVG(processing_time_ms) as avg_processing_time,
                    AVG(response_length) as avg_response_length,
                    AVG(confidence_score) as avg_confidence_score,
                    COUNT(DISTINCT user_id) as unique_users,
                    COUNT(DISTINCT session_id) as unique_sessions,
                    COUNT(DISTINCT ip_address) as unique_ips
                FROM "{schema_name}".qa_interactions
                {where_clause}
            """
            
            summary_result = conn.execute(text(summary_query), params)
            summary_row = summary_result.fetchone()
            
            summary = {
                "total_interactions": summary_row[0],
                "error_count": summary_row[1],
                "error_rate": (summary_row[1] / summary_row[0] * 100) if summary_row[0] > 0 else 0,
                "positive_feedback": summary_row[2],
                "negative_feedback": summary_row[3],
                "feedback_rate": ((summary_row[2] + summary_row[3]) / summary_row[0] * 100) if summary_row[0] > 0 else 0,
                "avg_processing_time_ms": float(summary_row[4]) if summary_row[4] else 0,
                "avg_response_length": float(summary_row[5]) if summary_row[5] else 0,
                "avg_confidence_score": float(summary_row[6]) if summary_row[6] else 0,
                "unique_users": summary_row[7],
                "unique_sessions": summary_row[8],
                "unique_ips": summary_row[9],
                "schema_used": schema_name
            }
            
            logger.info("MainApp", "get_interaction_analytics", f"Retrieved {len(interactions)} interactions from schema: {schema_name}")
            
            return {
                "interactions": interactions,
                "summary": summary,
                "pagination": {
                    "limit": limit,
                    "offset": offset,
                    "returned_count": len(interactions)
                }
            }
            
    except Exception as e:
        logger.error("MainApp", "get_interaction_analytics", f"Error retrieving analytics: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve analytics: {str(e)}")

@app.get("/versions", tags=["Public"], summary="List available document versions")
async def list_versions() -> Dict[str, Any]:
    """
    Return available document versions from PostgreSQL schemas.
    Used by the frontend to populate the version dropdown.
    
    Think of this like getting a list of all the different sections in our library
    so users can choose which version of documentation to search.
    
    Returns:
        Dict: List of available versions with document counts
    """
    logger.debug("MainApp", "list_versions", "Versions list requested")
    
    try:
        # Get all version schemas from PostgreSQL
        schemas = db_manager.list_version_schemas()
        
        versions_dict = {}  # Use dict to deduplicate by version name
        for schema_name in schemas:
            try:
                # Get document count for this version
                doc_count = db_manager.get_document_count(schema_name)
                
                # Convert schema name back to version format
                if schema_name.startswith("v_"):
                    version_name = schema_name.replace("v_", "").replace("_", ".")
                else:
                    # For existing schemas like '2024.3.1', use as-is
                    version_name = schema_name
                
                # If we've already seen this version name, keep the one with more documents
                if version_name in versions_dict:
                    existing = versions_dict[version_name]
                    # Keep the schema with more documents, or prefer non-v_ prefixed schema
                    if doc_count > existing["document_count"]:
                        versions_dict[version_name] = {
                            "version": version_name,
                            "schema": schema_name,
                            "document_count": doc_count,
                            "display_name": f"Version {version_name} ({doc_count} documents)"
                        }
                    elif doc_count == existing["document_count"] and not schema_name.startswith("v_"):
                        # If same count, prefer original format (non-v_ prefixed)
                        versions_dict[version_name] = {
                            "version": version_name,
                            "schema": schema_name,
                            "document_count": doc_count,
                            "display_name": f"Version {version_name} ({doc_count} documents)"
                        }
                else:
                    # First time seeing this version name
                    versions_dict[version_name] = {
                        "version": version_name,
                        "schema": schema_name,
                        "document_count": doc_count,
                        "display_name": f"Version {version_name} ({doc_count} documents)"
                    }
                
            except Exception as e:
                logger.warning("MainApp", "list_versions", f"Error getting info for schema {schema_name}: {str(e)}")
                continue
        
        # Convert dict to list and sort by version name
        versions = list(versions_dict.values())
        versions.sort(key=lambda x: x["version"])
        
        result = {
            "status": "success",
            "versions": versions,
            "total_schemas": len(versions)
        }
        
        logger.debug("MainApp", "list_versions", f"Found {len(versions)} version schemas")
        return result
        
    except Exception as e:
        logger.error("MainApp", "list_versions", f"Error listing versions: {str(e)}")
        raise HTTPException(status_code=500, detail="Error listing versions")

@app.get("/health", tags=["System"], summary="Health check endpoint")
async def health_check() -> Dict[str, Any]:
    """
    Check if the system is running properly.
    
    Think of this like a pulse check for our system - it tells us if all our
    components are working and the system is ready to serve users.
    
    Returns:
        Dict: A simple status report showing the system is healthy
    """
    logger.debug("MainApp", "health_check", "Health check requested")
    
    try:
        # Test database connection
        with db_manager.engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        
        health_status = {
            "status": "healthy",
            "message": "Synapse RAG System is running",
            "database": "connected",
            "timestamp": datetime.utcnow().isoformat()
        }
        
        logger.debug("MainApp", "health_check", "Health check completed successfully")
        return health_status
        
    except Exception as e:
        logger.error("MainApp", "health_check", f"Health check failed: {str(e)}")
        raise HTTPException(status_code=500, detail="Health check failed")

# Run the application - This starts our web server
if __name__ == "__main__":
    """
    This section only runs when someone starts this file directly.
    It's like the main power switch that turns on our entire hotel operation.
    
    When you run this file, it starts the web server and makes our system
    available to users on the internet.
    """
    logger.info("MainApp", "startup", "Starting Synapse RAG System server")
    
    try:
        # Start the web server with specific settings
        # Like opening our hotel doors and turning on all the lights
        logger.info("MainApp", "startup", "Starting uvicorn server on 127.0.0.1:8000")
        uvicorn.run(
            "main:app",  # Run the app we created above
            host="127.0.0.1",  # Listen on localhost (your computer)
            port=8000,  # Use port 8000 (like choosing which entrance to use)
            reload=True,  # Automatically restart if we change the code (helpful for development)
            log_level="info"  # Show informational messages about what's happening
        )
    except Exception as e:
        logger.critical("MainApp", "startup", f"Failed to start server: {str(e)}")
        raise
