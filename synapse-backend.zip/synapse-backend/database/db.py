"""
PostgreSQL database manager with PGVector support for Synapse RAG system.
This module handles all database operations including schema versioning,
document storage, and vector similarity search.
"""

import os
import re
from typing import List, Dict, Any, Optional
from sqlalchemy import create_engine, text, Engine
from sqlalchemy.exc import SQLAlchemyError
from dotenv import load_dotenv
from Utils.LoggingService import LoggingService

# Load environment variables
load_dotenv()

class DatabaseManager:
    """
    PostgreSQL database manager with schema versioning support.
    Each version gets its own schema with identical table structure.
    """
    
    def __init__(self):
        """Initialize database connection and setup"""
        self.logger = LoggingService()
        self.logger.info("DatabaseManager", "__init__", "Initializing PostgreSQL connection")
        
        # Get database connection parameters from environment
        self.db_host = os.getenv("POSTGRES_HOST", "localhost")
        self.db_port = os.getenv("POSTGRES_PORT", "5432")
        self.db_name = os.getenv("POSTGRES_DB", "synapse_rag")
        self.db_user = os.getenv("POSTGRES_USER", "postgres")
        self.db_password = os.getenv("POSTGRES_PASSWORD", "")
        
        if not self.db_password:
            raise ValueError("POSTGRES_PASSWORD environment variable is required")
        
        # Create SQLAlchemy engine using pg8000 (BSD-3-Clause license)
        self.connection_string = (
            f"postgresql+pg8000://{self.db_user}:{self.db_password}"
            f"@{self.db_host}:{self.db_port}/{self.db_name}"
        )
        self.engine = create_engine(
            self.connection_string,
            pool_size=10,
            max_overflow=20,
            pool_pre_ping=True,
            echo=False  # Set to True for SQL debugging
        )
        
        # Test connection and ensure pgvector extension
        self._test_connection()
        self._ensure_pgvector_extension()
        
        # Make schema bootstrapping optional - only if PRESEED_SCHEMAS is explicitly set
        # This prevents slow startup when schemas already exist
        preseed_env = os.getenv("PRESEED_SCHEMAS", "").strip()
        if preseed_env:
            self._bootstrap_required_schemas()
        else:
            self.logger.info("DatabaseManager", "__init__", "Schema bootstrapping skipped (PRESEED_SCHEMAS not set)")
        
        self.logger.info("DatabaseManager", "__init__", "PostgreSQL connection established successfully")
    
    def _test_connection(self):
        """Test database connection"""
        try:
            with self.engine.connect() as conn:
                result = conn.execute(text("SELECT version()"))
                version = result.fetchone()[0]
                self.logger.info("DatabaseManager", "_test_connection", f"Connected to PostgreSQL: {version}")
        except Exception as e:
            self.logger.error("DatabaseManager", "_test_connection", f"Database connection failed: {str(e)}")
            raise
    
    def _ensure_pgvector_extension(self):
        """Ensure pgvector extension is enabled"""
        try:
            with self.engine.connect() as conn:
                # Check if pgvector extension exists
                result = conn.execute(text("""
                    SELECT EXISTS(
                        SELECT 1 FROM pg_extension WHERE extname = 'vector'
                    )
                """))
                
                if not result.fetchone()[0]:
                    # Try to create the extension
                    conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
                    conn.commit()
                    self.logger.info("DatabaseManager", "_ensure_pgvector_extension", "PGVector extension created")
                else:
                    self.logger.info("DatabaseManager", "_ensure_pgvector_extension", "PGVector extension already exists")
                    
        except Exception as e:
            self.logger.error("DatabaseManager", "_ensure_pgvector_extension", f"Failed to ensure pgvector extension: {str(e)}")
            raise
    
    def _bootstrap_required_schemas(self):
        """Create any pre-configured schemas so deployments mirror local structure"""
        raw_versions = os.getenv("PRESEED_SCHEMAS", "")
        versions = [v.strip() for v in raw_versions.split(",") if v.strip()]
        
        if not versions:
            self.logger.info("DatabaseManager", "_bootstrap_required_schemas", "No preseeding schemas configured")
            return
        
        self.logger.info("DatabaseManager", "_bootstrap_required_schemas", f"Bootstrapping {len(versions)} schemas...")
        for version in versions:
            try:
                schema = self.ensure_version_schema(version)
                self.logger.info("DatabaseManager", "_bootstrap_required_schemas", f"Preseeded schema: {schema}")
            except Exception as e:
                self.logger.error("DatabaseManager", "_bootstrap_required_schemas", f"Failed to preseed schema {version}: {str(e)}")
    
    def sanitize_schema_name(self, version: str) -> str:
        """
        Convert version string to valid PostgreSQL schema name.
        For existing version patterns like "2024.3.1", keep as-is.
        For new versions, use "v_" prefix format.
        """
        if not version or not isinstance(version, str):
            version = "default"
        
        version = version.strip()
        
        # Check if it matches existing version pattern (e.g., "2024.3.1")
        if re.match(r'^[0-9]+\.[0-9]+\.[0-9]+$', version):
            return version  # Use existing schema name as-is
        
        # For other versions, use v_ prefix format
        # Replace dots and special characters with underscores
        sanitized = re.sub(r'[^a-zA-Z0-9_]', '_', version)
        
        # Ensure it starts with 'v_' prefix
        if not sanitized.startswith('v_'):
            sanitized = f"v_{sanitized}"
        
        # Ensure it's a valid identifier
        sanitized = re.sub(r'_+', '_', sanitized)  # Remove multiple underscores
        sanitized = sanitized.strip('_')  # Remove leading/trailing underscores
        
        if not sanitized or sanitized == 'v':
            sanitized = "v_default"
        
        return sanitized.lower()
    
    def _quote_schema(self, schema_name: str) -> str:
        """Quote schema name for SQL queries to handle numeric schemas"""
        return f'"{schema_name}"'
    
    def _drop_existing_vector_indexes(self, conn, schema_name: str):
        """Drop any existing HNSW or IVFFlat indexes on embedding columns to prevent dimension errors"""
        try:
            # Find all indexes on the chunks.embedding column
            result = conn.execute(text(f"""
                SELECT indexname, indexdef
                FROM pg_indexes
                WHERE schemaname = :schema_name
                  AND tablename = 'chunks'
                  AND indexdef ILIKE '%embedding%'
                  AND (indexdef ILIKE '%hnsw%' OR indexdef ILIKE '%ivfflat%')
            """), {"schema_name": schema_name})
            
            indexes = result.fetchall()
            
            if indexes:
                self.logger.warning("DatabaseManager", "_drop_existing_vector_indexes", 
                                  f"Found {len(indexes)} existing vector indexes on {schema_name}.chunks.embedding, dropping them to prevent dimension errors")
                
                for index_name, index_def in indexes:
                    try:
                        conn.execute(text(f'DROP INDEX IF EXISTS "{schema_name}".{index_name}'))
                        self.logger.info("DatabaseManager", "_drop_existing_vector_indexes", 
                                       f"Dropped index: {index_name}")
                    except Exception as e:
                        self.logger.warning("DatabaseManager", "_drop_existing_vector_indexes", 
                                          f"Failed to drop index {index_name}: {str(e)}")
            
        except Exception as e:
            # Log but don't fail - this is a cleanup operation
            self.logger.warning("DatabaseManager", "_drop_existing_vector_indexes", 
                              f"Error checking/dropping indexes: {str(e)}")
    
    def create_schema_tables(self, schema_name: str):
        """Create all required tables in the specified schema"""
        try:
            with self.engine.connect() as conn:
                # Create schema if it doesn't exist (quote schema name for numeric schemas)
                conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{schema_name}"'))
                
                # Create documents table
                conn.execute(text(f"""
                    CREATE TABLE IF NOT EXISTS "{schema_name}".documents (
                        id UUID PRIMARY KEY,
                        filename VARCHAR(255) NOT NULL,
                        file_hash VARCHAR(64) UNIQUE NOT NULL,
                        file_size BIGINT NOT NULL,
                        page_count INTEGER NOT NULL,
                        word_count INTEGER NOT NULL,
                        content_type VARCHAR(100) NOT NULL,
                        full_text TEXT NOT NULL,
                        status VARCHAR(50) DEFAULT 'processed',
                        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
                    )
                """))
                
                # Create chunks table with pgvector support
                # Use IF NOT EXISTS to avoid errors, but we'll alter the column type if needed
                conn.execute(text(f"""
                    CREATE TABLE IF NOT EXISTS "{schema_name}".chunks (
                        id UUID PRIMARY KEY,
                        document_id UUID NOT NULL REFERENCES "{schema_name}".documents(id) ON DELETE CASCADE,
                        chunk_index INTEGER NOT NULL,
                        text TEXT NOT NULL,
                        embedding VECTOR(1536),  -- OpenAI text-embedding-3-small dimensions
                        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
                    )
                """))
                
                # Ensure the embedding column has the correct dimension (in case table already exists)
                # This handles cases where the table was created with wrong dimensions
                try:
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".chunks 
                        ALTER COLUMN embedding TYPE VECTOR(1536)
                    """))
                except Exception as e:
                    # Column might not exist or already be correct, log and continue
                    self.logger.debug("DatabaseManager", "create_schema_tables", 
                                    f"Embedding column type check: {str(e)}")
                
                # Create document_files table for PDF binary storage
                conn.execute(text(f"""
                    CREATE TABLE IF NOT EXISTS "{schema_name}".document_files (
                        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                        document_id UUID NOT NULL REFERENCES "{schema_name}".documents(id) ON DELETE CASCADE,
                        file_content BYTEA NOT NULL,
                        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
                    )
                """))
                
                # Create QA interactions table for comprehensive user interaction tracking
                conn.execute(text(f"""
                    CREATE TABLE IF NOT EXISTS "{schema_name}".qa_interactions (
                        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                        
                        -- Core interaction data
                        question TEXT NOT NULL,
                        bot_response TEXT,
                        response JSONB NOT NULL,
                        rating VARCHAR(10) DEFAULT 'none',
                        comment TEXT DEFAULT '',
                        query_type VARCHAR(50) DEFAULT 'document_question',
                        
                        -- Document retrieval data
                        chunks_used JSONB,
                        chunks_count INTEGER DEFAULT 0,
                        sources JSONB,
                        relevance_scores JSONB,
                        similarity_threshold DECIMAL(5,4) DEFAULT 0.7,
                        max_chunks_requested INTEGER DEFAULT 5,
                        
                        -- User identification and session tracking
                        user_id VARCHAR(255),
                        session_id VARCHAR(255),
                        ip_address INET,
                        user_agent TEXT,
                        
                        -- Request metadata
                        request_id UUID DEFAULT gen_random_uuid(),
                        processing_time_ms INTEGER,
                        embedding_time_ms INTEGER,
                        search_time_ms INTEGER,
                        llm_time_ms INTEGER,
                        
                        -- Response quality metrics
                        response_length INTEGER,
                        confidence_score DECIMAL(5,4),
                        hallucination_risk DECIMAL(5,4),
                        
                        -- System configuration
                        model_used VARCHAR(100),
                        temperature DECIMAL(3,2),
                        max_tokens INTEGER,
                        system_prompt_version VARCHAR(50),
                        version VARCHAR(100),
                        
                        -- Error tracking
                        error_occurred BOOLEAN DEFAULT FALSE,
                        error_type VARCHAR(100),
                        error_message TEXT,
                        
                        -- Legacy and metadata
                        low_confidence BOOLEAN DEFAULT FALSE,
                        client_meta JSONB DEFAULT '{{}}',
                        
                        -- Timestamps
                        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
                    )
                """))
                
                # Add new columns if table already exists (for migration)
                try:
                    # Core interaction columns
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS bot_response TEXT
                    """))
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS query_type VARCHAR(50) DEFAULT 'document_question'
                    """))
                    
                    # Document retrieval columns
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS chunks_used JSONB
                    """))
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS chunks_count INTEGER DEFAULT 0
                    """))
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS sources JSONB
                    """))
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS relevance_scores JSONB
                    """))
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS similarity_threshold DECIMAL(5,4) DEFAULT 0.7
                    """))
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS max_chunks_requested INTEGER DEFAULT 5
                    """))
                    
                    # User identification columns
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS user_id VARCHAR(255)
                    """))
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS session_id VARCHAR(255)
                    """))
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS ip_address INET
                    """))
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS user_agent TEXT
                    """))
                    
                    # Request metadata columns
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS request_id UUID DEFAULT gen_random_uuid()
                    """))
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS processing_time_ms INTEGER
                    """))
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS embedding_time_ms INTEGER
                    """))
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS search_time_ms INTEGER
                    """))
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS llm_time_ms INTEGER
                    """))
                    
                    # Response quality columns
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS response_length INTEGER
                    """))
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS confidence_score DECIMAL(5,4)
                    """))
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS hallucination_risk DECIMAL(5,4)
                    """))
                    
                    # System configuration columns
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS model_used VARCHAR(100)
                    """))
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS temperature DECIMAL(3,2)
                    """))
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS max_tokens INTEGER
                    """))
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS system_prompt_version VARCHAR(50)
                    """))
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS version VARCHAR(100)
                    """))
                    
                    # Error tracking columns
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS error_occurred BOOLEAN DEFAULT FALSE
                    """))
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS error_type VARCHAR(100)
                    """))
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS error_message TEXT
                    """))
                    
                    # Legacy columns
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS low_confidence BOOLEAN DEFAULT FALSE
                    """))
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".qa_interactions 
                        ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
                    """))
                    
                except Exception as e:
                    # Columns might already exist, that's fine
                    self.logger.debug("DatabaseManager", "create_schema_tables", f"Column migration note: {str(e)}")
                
                # Skip ALL index creation to avoid any HNSW issues
                # Indexes can be added manually later if needed
                
                # Ensure no existing problematic indexes exist
                self._drop_existing_vector_indexes(conn, schema_name)
                
                conn.commit()
                self.logger.info("DatabaseManager", "create_schema_tables", f"Created tables for schema: {schema_name}")
                
        except Exception as e:
            self.logger.error("DatabaseManager", "create_schema_tables", f"Error creating tables for schema {schema_name}: {str(e)}")
            raise
    
    def ensure_version_schema(self, version: str) -> str:
        """Ensure a version schema exists and return its name"""
        schema_name = self.sanitize_schema_name(version)
        
        try:
            # Check if schema exists
            with self.engine.connect() as conn:
                result = conn.execute(text("""
                    SELECT EXISTS(
                        SELECT 1 FROM information_schema.schemata 
                        WHERE schema_name = :schema_name
                    )
                """), {"schema_name": schema_name})
                
                if not result.fetchone()[0]:
                    # Schema doesn't exist, create it
                    self.create_schema_tables(schema_name)
                    self.logger.info("DatabaseManager", "ensure_version_schema", f"Created new schema: {schema_name}")
                else:
                    # Schema exists - ensure it's properly configured (fix any issues)
                    self.logger.debug("DatabaseManager", "ensure_version_schema", f"Schema already exists: {schema_name}, ensuring it's properly configured")
                    try:
                        self.fix_schema_vector_column(schema_name)
                    except Exception as fix_error:
                        # Log but don't fail - the schema exists and may work fine
                        self.logger.warning("DatabaseManager", "ensure_version_schema", 
                                          f"Could not fix existing schema {schema_name}: {str(fix_error)}")
            
            return schema_name
            
        except Exception as e:
            self.logger.error("DatabaseManager", "ensure_version_schema", f"Error ensuring schema {schema_name}: {str(e)}")
            raise
    
    def list_version_schemas(self) -> List[str]:
        """List all version schemas (schemas starting with 'v_' or version patterns like '2024.3.1')"""
        try:
            with self.engine.connect() as conn:
                result = conn.execute(text("""
                    SELECT schema_name 
                    FROM information_schema.schemata 
                    WHERE schema_name LIKE 'v_%' 
                       OR schema_name ~ '^[0-9]+\\.[0-9]+\\.[0-9]+$'
                       OR schema_name = 'default'
                    ORDER BY schema_name
                """))
                
                schemas = [row[0] for row in result.fetchall()]
                self.logger.debug("DatabaseManager", "list_version_schemas", f"Found {len(schemas)} version schemas")
                return schemas
                
        except Exception as e:
            self.logger.error("DatabaseManager", "list_version_schemas", f"Error listing schemas: {str(e)}")
            return []
    
    def get_document_count(self, schema_name: str) -> int:
        """Get document count for a specific schema"""
        try:
            with self.engine.connect() as conn:
                result = conn.execute(text(f"""
                    SELECT COUNT(*) FROM "{schema_name}".documents
                """))
                
                count = result.fetchone()[0]
                return count
                
        except Exception as e:
            self.logger.warning("DatabaseManager", "get_document_count", f"Error getting document count for {schema_name}: {str(e)}")
            return 0
    
    def check_duplicate_document(self, schema_name: str, file_hash: str) -> Optional[Dict[str, Any]]:
        """Check if a document with the given hash already exists in the schema"""
        try:
            with self.engine.connect() as conn:
                result = conn.execute(text(f"""
                    SELECT id, filename, file_hash, file_size, page_count, word_count, 
                           content_type, status, created_at, updated_at
                    FROM "{schema_name}".documents 
                    WHERE file_hash = :file_hash
                """), {"file_hash": file_hash})
                
                row = result.fetchone()
                if row:
                    return {
                        "id": str(row[0]),
                        "filename": row[1],
                        "file_hash": row[2],
                        "file_size": row[3],
                        "page_count": row[4],
                        "word_count": row[5],
                        "content_type": row[6],
                        "status": row[7],
                        "created_at": row[8].isoformat() if row[8] else None,
                        "updated_at": row[9].isoformat() if row[9] else None
                    }
                
                return None
                
        except Exception as e:
            self.logger.error("DatabaseManager", "check_duplicate_document", f"Error checking duplicate in {schema_name}: {str(e)}")
            return None
    
    def fix_schema_vector_column(self, schema_name: str):
        """
        Fix the embedding column in an existing schema to ensure correct dimensions and drop problematic indexes.
        This is useful for fixing existing schemas that may have incorrect configurations.
        """
        try:
            with self.engine.connect() as conn:
                self.logger.info("DatabaseManager", "fix_schema_vector_column", 
                               f"Fixing vector column in schema: {schema_name}")
                
                # Drop existing problematic indexes
                self._drop_existing_vector_indexes(conn, schema_name)
                
                # Ensure the embedding column has the correct dimension
                try:
                    conn.execute(text(f"""
                        ALTER TABLE "{schema_name}".chunks 
                        ALTER COLUMN embedding TYPE VECTOR(1536)
                    """))
                    conn.commit()
                    self.logger.info("DatabaseManager", "fix_schema_vector_column", 
                                   f"Successfully fixed embedding column in schema: {schema_name}")
                except Exception as e:
                    # Column might not exist yet or already be correct
                    self.logger.warning("DatabaseManager", "fix_schema_vector_column", 
                                      f"Could not alter column (may already be correct or table doesn't exist): {str(e)}")
                    # Don't rollback - might be in autocommit mode or already committed
                    try:
                        conn.rollback()
                    except:
                        pass
                
        except Exception as e:
            self.logger.error("DatabaseManager", "fix_schema_vector_column", 
                            f"Error fixing schema {schema_name}: {str(e)}")
            raise

# Create global database manager instance
# Note: Schema bootstrapping is now optional - only runs if PRESEED_SCHEMAS is set
# This prevents slow startup when schemas already exist
db_manager = DatabaseManager()

# Legacy compatibility - create a simple 'db' object for backward compatibility
class LegacyDBWrapper:
    """Wrapper for backward compatibility with existing code"""
    
    def get_schema_name(self, version: str) -> str:
        """Legacy method - use db_manager.sanitize_schema_name instead"""
        return db_manager.sanitize_schema_name(version)
    
    def ensure_schema(self, version: str) -> str:
        """Legacy method - use db_manager.ensure_version_schema instead"""
        return db_manager.ensure_version_schema(version)

# Create legacy wrapper instance
db = LegacyDBWrapper()
