import logging
from logging.handlers import RotatingFileHandler, TimedRotatingFileHandler
import os
from datetime import datetime, timedelta
import glob
import time
import sched
import threading

FORMAT = "%(asctime)s | %(levelname)s | %(pipelineId)s | %(blockId)s | %(message)s"

class CustomRotatingFileHandler(RotatingFileHandler, TimedRotatingFileHandler):
    def __init__(self, filename, when='midnight', interval=1, backupCount=0, maxBytes=0, encoding=None, delay=False, utc=True):
        self.archive_dir = os.path.join(os.path.dirname(filename), 'archive')
        if not os.path.exists(self.archive_dir):
            os.makedirs(self.archive_dir)

        RotatingFileHandler.__init__(self, filename, mode='a', maxBytes=maxBytes, backupCount=backupCount, encoding=encoding, delay=delay)
        TimedRotatingFileHandler.__init__(self, filename, when=when, interval=interval, backupCount=backupCount, encoding=encoding, delay=delay, utc=utc)

    def doRollover(self):
        if self.stream:
            self.stream.close()
            self.stream = None

        current_time = datetime.utcnow().strftime("%Y-%m-%d_%H-%M-%S")
        base_filename, ext = os.path.splitext(self.baseFilename)
        new_base_filename = "{}_{}{}".format(base_filename, current_time, ext)

        if not os.path.exists(self.archive_dir):
            os.makedirs(self.archive_dir)

        archive_filename = os.path.join(self.archive_dir, os.path.basename(new_base_filename))
        os.rename(self.baseFilename, archive_filename)

        if not self.delay:
            self.stream = self._open()

class LoggingService:
    _instance = None
    _cleanup_interval = 2000  # seconds

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls, *args, **kwargs)
            cls._instance._logger = cls._initialize_logger()
            cls._instance._start_cleanup_thread()
        return cls._instance

    @staticmethod
    def _initialize_logger():
        logger = logging.getLogger("synapse_logger")
        logger.setLevel(logging.DEBUG)
        formatter = logging.Formatter(FORMAT)

        # Ensure logs directory exists
        log_dir = "logs"
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)

        log_file = os.path.join(log_dir, "synapse_logs.log")
        file_handler = CustomRotatingFileHandler(log_file, maxBytes=15000000, backupCount=999, encoding='utf-8')
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
        return logger

    @staticmethod
    def _cleanup_old_logs(log_dir="logs/archive", retention_minutes=2000):
        try:
            current_time = datetime.utcnow()
            cutoff_time = current_time - timedelta(minutes=retention_minutes)
            # Define the log file pattern
            log_pattern = os.path.join(log_dir, "*.log*")

            # Get a list of log files matching the pattern
            log_files = glob.glob(log_pattern)

            # Iterate through log files and remove those older than the cutoff time
            for log_file in log_files:
                file_timestamp = os.path.getmtime(log_file)
                file_datetime = datetime.utcfromtimestamp(file_timestamp)

                if file_datetime < cutoff_time:
                    os.remove(log_file)
                    print(f"Deleted old log file: {log_file}")

        except Exception as e:
            print(f"Error during log cleanup: {str(e)}")

    @staticmethod
    def _cleanup_scheduler():
        while True:
            LoggingService._cleanup_old_logs()
            time.sleep(LoggingService._cleanup_interval)

    def _start_cleanup_thread(self):
        cleanup_thread = threading.Thread(target=self._cleanup_scheduler, daemon=True)
        cleanup_thread.start()

    def info(self, pipelineId, blockId, message):
        self._logger.info(message, extra={'pipelineId': pipelineId, 'blockId': blockId})

    def warning(self, pipelineId, blockId, message):
        self._logger.warning(message, extra={'pipelineId': pipelineId, 'blockId': blockId})

    def debug(self, pipelineId, blockId, message):
        self._logger.debug(message, extra={'pipelineId': pipelineId, 'blockId': blockId})

    def error(self, pipelineId, blockId, message):
        self._logger.error(message, extra={'pipelineId': pipelineId, 'blockId': blockId})

    def critical(self, pipelineId, blockId, message):
        self._logger.critical(message, extra={'pipelineId': pipelineId, 'blockId': blockId})

