# Using Angular Workflows

This guide shows how to use the centralized Angular workflows in your repository.

## Quick Start

Create `.github/workflows/cicd.yml` in your Angular repository:

```yaml
name: CI/CD Pipeline

on:
  push:
    branches: ["**"]
  workflow_dispatch:

permissions:
  contents: read
  actions: read

jobs:
  build:
    uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/angular-build.yml@main
    with:
      node-version: '22.x'
      runner-group: 'IDWG-RG-01'
    secrets: inherit

  deploy-dev:
    needs: build
    if: github.ref == 'refs/heads/develop'
    uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/angular-deploy-iis.yml@main
    with:
      artifact-name: ${{ needs.build.outputs.artifact-name }}
      environment: DEV01
    secrets: inherit
```

## Build Workflow

### Basic Usage

```yaml
build:
  uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/angular-build.yml@main
  with:
    node-version: '22.x'
    runner-group: 'IDWG-RG-01'
  secrets: inherit
```

### All Parameters

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| `node-version` | No | `22.x` | Node.js version |
| `runner-group` | No | `IDWG-RG-01` | Runner group for build |
| `artifact-prefix` | No | (repo name) | Prefix for artifact names |
| `artifact-path` | No | `dist` | Path to build output |
| `artifact-retention-days` | No | Dynamic* | Days to retain artifacts |
| `enable-cache` | No | `true` | Enable npm caching |
| `enable-cuic-fix` | No | `false` | Apply CUIC package fix |
| `package-registry` | No | `npm.id-ware.ghe.com` | npm registry URL |
| `additional-package-branches` | No | `''` | Pipe-separated branch patterns for artifact creation |

*Dynamic retention: 7 days for develop/feature, 60 days for release/*

### Outputs

| Output | Description |
|--------|-------------|
| `artifact-name` | Name of uploaded artifact |
| `should-deploy` | Whether deployment should proceed |
| `branch-name` | Current branch name |
| `version` | Extracted version from package.json |

### Example: Custom Artifact Path

```yaml
build:
  uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/angular-build.yml@main
  with:
    artifact-path: 'dist/MyApp'  # Non-standard build output
    artifact-prefix: 'my_app'
  secrets: inherit
```

### Example: Disable npm Cache

```yaml
build:
  uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/angular-build.yml@main
  with:
    enable-cache: false  # Recommended for release branches
  secrets: inherit
```

### Example: Enable Packaging for Hotfix Branches

```yaml
build:
  uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/angular-build.yml@main
  with:
    additional-package-branches: 'release/1.2.3-rc1|hotfix/*|feature/CICD-123'
  secrets: inherit
```

**Note:** Workflow no longer auto-commits package-lock.json. Repos manage it per their commit policies.

## Deploy Workflow

### Basic Usage

```yaml
deploy-dev:
  needs: build
  uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/angular-deploy-iis.yml@main
  with:
    artifact-name: ${{ needs.build.outputs.artifact-name }}
    environment: DEV01
  secrets: inherit
```

### All Parameters

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| `artifact-name` | Yes | - | Name of artifact to deploy |
| `environment` | Yes | - | GitHub environment name |
| `runner-group` | No | `IDWG-RG-01` | Runner group for deployment |
| `app-name` | No | `vars.IISAPP` | IIS application name |
| `deploy-url` | No | `vars.DEPLOY_URL` | MSDeploy service URL |
| `health-check-url` | No | - | URL to verify after deployment |
| `health-check-timeout` | No | `60` | Health check timeout (seconds) |

### Example: Multiple Environments

```yaml
deploy-dev:
  needs: build
  if: github.ref == 'refs/heads/develop'
  uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/angular-deploy-iis.yml@main
  with:
    artifact-name: ${{ needs.build.outputs.artifact-name }}
    environment: DEV01
  secrets: inherit

deploy-test:
  needs: build
  if: startsWith(github.ref, 'refs/heads/release/')
  uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/angular-deploy-iis.yml@main
  with:
    artifact-name: ${{ needs.build.outputs.artifact-name }}
    environment: TEST01
  secrets: inherit
```

### Example: Health Check

```yaml
deploy-dev:
  needs: build
  uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/angular-deploy-iis.yml@main
  with:
    artifact-name: ${{ needs.build.outputs.artifact-name }}
    environment: DEV01
    health-check-url: 'https://dev01.example.com/health'
    health-check-timeout: 120
  secrets: inherit
```

## Required Configuration

### Environment Variables

Configure per environment in GitHub repository settings:

| Variable | Description | Example |
|----------|-------------|---------|
| `IISAPP` | IIS application name | `MyApp` |
| `DEPLOY_URL` | MSDeploy service URL | `https://server:8172/msdeploy.axd` |

### Secrets

| Secret | Description | Scope |
|--------|-------------|-------|
| `GHE_PAT_READ_PKG` | GitHub PAT for npm packages | Repository |
| `DEPLOY_USER` | MSDeploy username | Environment |
| `DEPLOY_PASSWORD` | MSDeploy password | Environment |

## Conditional Deployment

### Deploy Only on Specific Branches

```yaml
deploy-dev:
  needs: build
  if: |
    needs.build.outputs.should-deploy == 'true' &&
    github.ref == 'refs/heads/develop'
  uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/angular-deploy-iis.yml@main
  with:
    artifact-name: ${{ needs.build.outputs.artifact-name }}
    environment: DEV01
  secrets: inherit
```

### Manual Deployment Control

```yaml
on:
  workflow_dispatch:
    inputs:
      deploy:
        description: 'Deploy after build'
        required: false
        default: 'true'

jobs:
  deploy-dev:
    needs: build
    if: |
      github.event_name != 'workflow_dispatch' || 
      github.event.inputs.deploy != 'false'
    uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/angular-deploy-iis.yml@main
    # ...
```

## Concurrency Control

Prevent parallel deployments to same environment:

```yaml
concurrency:
  group: ${{ github.repository }}-${{ github.ref_name }}
  cancel-in-progress: false
```

## Troubleshooting

### Build Fails with npm Authentication Error

- Verify `GHE_PAT_READ_PKG` secret is set
- Check PAT has SSO authorization
- Confirm PAT has `read:packages` scope

### Deployment Fails with MSDeploy Error

- Verify `DEPLOY_USER` and `DEPLOY_PASSWORD` secrets
- Check `DEPLOY_URL` and `IISAPP` variables are correct
- Ensure runner has network access to target server

### Artifact Not Found

- Verify `artifact-name` output from build job
- Check artifact retention hasn't expired
- Ensure build job completed successfully

### Wrong Artifact Path

If build outputs to non-standard location, specify `artifact-path`:

```yaml
build:
  uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/angular-build.yml@main
  with:
    artifact-path: 'dist/MyCustomPath'
  secrets: inherit
```
