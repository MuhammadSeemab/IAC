# Using .NET Workflows

This guide shows how to use the centralized .NET workflows in your repository.

## Quick Start

Create `.github/workflows/cicd.yml` in your .NET repository:

```yaml
name: CI/CD Pipeline

on:
  push:
    branches: ["**"]
  workflow_dispatch:

permissions:
  contents: read
  actions: read

jobs:
  build:
    uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/dotnet-build.yml@main
    with:
      solution-path: 'MySolution.sln'
      runner-group: 'IDWG-RG-01'
    secrets: inherit

  deploy-dev:
    needs: build
    if: github.ref == 'refs/heads/develop'
    uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/dotnet-deploy-env.yml@main
    with:
      artifact-name: ${{ needs.build.outputs.artifact-name }}
      environment: DEV01
    secrets: inherit
```

## Build Workflow

### Basic Usage

```yaml
build:
  uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/dotnet-build.yml@main
  with:
    solution-path: 'MySolution.sln'
    runner-group: 'IDWG-RG-01'
  secrets: inherit
```

### All Parameters

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| `solution-path` | Yes | - | Path to .sln file |
| `runner-group` | No | `IDWG-RG-01` | Runner group for build |
| `dotnet-version` | No | `8.0.x` | .NET SDK version |
| `build-configuration` | No | `Release` | Build configuration |
| `projects-to-publish` | No | - | Comma-separated project paths |
| `artifact-prefix` | No | (repo name) | Prefix for artifact names |
| `artifact-retention-days` | No | Dynamic* | Days to retain artifacts |
| `enable-cache` | No | `true` | Enable NuGet caching |
| `working-directory` | No | `.` | Working directory for build |
| `additional-package-branches` | No | `''` | Pipe-separated branch patterns for artifact creation |

*Dynamic retention: 7 days for develop/feature, 60 days for release/*

### Outputs

| Output | Description |
|--------|-------------|
| `artifact-name` | Name of uploaded artifact |
| `should-deploy` | Whether deployment should proceed |
| `branch-name` | Current branch name |

### Example: Multiple Projects

```yaml
build:
  uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/dotnet-build.yml@main
  with:
    solution-path: 'MySolution.sln'
    projects-to-publish: |
      API/MyApp.API/MyApp.API.csproj,
      Services/MyApp.Service/MyApp.Service.csproj,
      Migrator/MyApp.Migrator/MyApp.Migrator.csproj
  secrets: inherit
```

### Example: Solution in Subdirectory

```yaml
build:
  uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/dotnet-build.yml@main
  with:
    solution-path: 'backend/MySolution.sln'
    working-directory: 'backend'
  secrets: inherit
```

## Deploy Workflow

### Basic Usage

```yaml
deploy-dev:
  needs: build
  uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/dotnet-deploy-env.yml@main
  with:
    artifact-name: ${{ needs.build.outputs.artifact-name }}
    environment: DEV01
  secrets: inherit
```

### All Parameters

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| `artifact-name` | Yes | - | Name of artifact to deploy |
| `environment` | Yes | - | GitHub environment name |
| `runner-group` | No | `IDWG-RG-01` | Runner group for deployment |

The workflow automatically handles deployment based on configuration in environment variables.

## Deployment Components

The deploy workflow supports multiple component types configured via specs.json and environment variables:

### IIS Web Applications

Deploy ASP.NET Core APIs and web applications to IIS:

```yaml
# Environment variables in GitHub
IISAPP_API: 'dev01_myapp/api'
DEV01_IP: '10.0.0.10'
DEPLOY_USERNAME: 'deployment-user'
DEPLOY_PASSWORD: 'secure-password'
```

Configure projects in `config-templates/{repo-name}/specs.json` with `iisApp` section.

### Windows Services

Deploy background services with automatic start/stop:

```yaml
# Environment variables
SERVICE_NAME_HANGFIRE: 'MyApp.Hangfire.Service'
IISAPP_HANGFIRE: 'dev01_myapp/hangfire'
```

Configure projects in `specs.json` with both `iisApp` and `windowsService` sections. The workflow:
- Stops the service before deployment
- Deploys binaries via IIS app physical path
- Starts the service after deployment
- Uses temp directory for batch files (handles spaces in paths)
- Supports concurrent deployments with unique run IDs

### Database Migrations

Run database migrations during deployment:

```yaml
# Environment variables
DEV01_AM_CONNECTION_STRING: 'Server=...;Database=...;'
IISAPP_DBMIGRATOR: 'dev01_myapp/migrator'
```

Configure migration project in `specs.json` with `migration` section. Supports:
- Command-line arguments with variable substitution
- appsettings.json-based configuration
- Product-specific connection strings (AM_, CS_, OCMS_, etc.)

### Configuration Files

Config templates from `IDware.DevOps.Common/config-templates/{repo-name}/` are automatically deployed with token replacement.

**Token Format**: `__TOKEN_NAME__`

**Variable Resolution** (smart fallback):
1. Product-specific: `{ENV}_{PRODUCT}_{VAR}` (e.g., `DEV01_AM_CONNECTION_STRING`)
2. Environment-specific: `{ENV}_{VAR}` (e.g., `DEV01_CONNECTION_STRING`)
3. Global: `{VAR}` (e.g., `CONNECTION_STRING`)

## Required Configuration

### specs.json

The primary configuration file located in `config-templates/{repo-name}/specs.json`:

```json
{
  "solution": "MyApp.sln",
  "projects": [
    {
      "path": "API/MyApp.API",
      "output": "MyApp.API",
      "iisApp": {
        "name": "API",
        "iisAppVar": "IISAPP_API"
      },
      "configTemplateSource": "api-config"
    },
    {
      "path": "Services/MyApp.Service",
      "output": "MyApp.Service",
      "iisApp": {
        "name": "Hangfire Service",
        "iisAppVar": "IISAPP_HANGFIRE"
      },
      "windowsService": {
        "serviceNameVar": "SERVICE_NAME_HANGFIRE"
      },
      "configTemplateSource": "service-config"
    },
    {
      "path": "Persistence/MyApp.Migrator",
      "output": "MyApp.Migrator",
      "migration": {
        "executable": "MyApp.Migrator.exe",
        "args": "{AM_CONNECTION_STRING}"
      }
    }
  ],
  "deployment": {
    "requiredVars": ["CONNECTION_STRING", "API_KEY"],
    "configTokens": {
      "__AM_CONNECTION_STRING__": "CONNECTION_STRING",
      "__API_KEY__": "API_KEY"
    },
    "productSpecificVars": {
      "CONNECTION_STRING": ["AM", "CS", "OCMS"]
    }
  },
  "nugetSources": []
}
```

### Environment Variables

Configure per environment in GitHub repository settings:

**Server Configuration:**
| Variable | Description | Example |
|----------|-------------|---------|
| `{ENV}_IP` | Server IP address | `DEV01_IP: '10.0.0.10'` |

**IIS Applications:**
| Variable | Description | Example |
|----------|-------------|---------|
| `IISAPP_{NAME}` | IIS app path | `IISAPP_API: 'dev01_myapp/api'` |

**Windows Services:**
| Variable | Description | Example |
|----------|-------------|---------|
| `SERVICE_NAME_{NAME}` | Service name | `SERVICE_NAME_HANGFIRE: 'MyApp.Hangfire'` |

**Database & Application Settings:**
| Variable | Description | Example |
|----------|-------------|---------|
| `{ENV}_{PRODUCT}_{VAR}` | Product-specific | `DEV01_AM_CONNECTION_STRING` |
| `{ENV}_{VAR}` | Environment-specific | `DEV01_API_KEY` |
| `{VAR}` | Global | `SHARED_SECRET` |

**Configuration Token Replacement:**
Use double-underscore format in config templates: `__TOKEN_NAME__`
Tokens are replaced using the smart variable resolution strategy.

### Secrets

| Secret | Description | Scope |
|--------|-------------|-------|
| `GHE_PAT` | GitHub PAT for packages & templates | Repository |
| `DEPLOY_USERNAME` | MSDeploy username | Organization |
| `DEPLOY_PASSWORD` | MSDeploy password | Organization |
| `{ENV}_SERVICE_USERNAME` | Windows service account | Environment |
| `{ENV}_SERVICE_PASSWORD` | Service account password | Environment |

## Example: Full Pipeline

```yaml
name: CI/CD Pipeline

on:
  push:
    branches: ["develop", "release/**", "main"]
  workflow_dispatch:
    inputs:
      deploy:
        description: 'Deploy after build'
        default: 'true'

permissions:
  contents: read
  actions: read

concurrency:
  group: ${{ github.repository }}-${{ github.ref_name }}
  cancel-in-progress: false

jobs:
  build:
    uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/dotnet-build.yml@main
    with:
      solution-path: 'MyApp.sln'
      projects-to-publish: |
        API/MyApp.API/MyApp.API.csproj,
        Services/MyApp.BackgroundService/MyApp.BackgroundService.csproj,
        Persistence/MyApp.DbMigrator/MyApp.DbMigrator.csproj
      artifact-retention-days: 30
    secrets: inherit

  deploy-dev:
    needs: build
    if: |
      needs.build.outputs.should-deploy == 'true' &&
      github.ref == 'refs/heads/develop'
    uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/dotnet-deploy-env.yml@main
    with:
      artifact-name: ${{ needs.build.outputs.artifact-name }}
      environment: DEV01
    secrets: inherit

  deploy-test:
    needs: build
    if: |
      needs.build.outputs.should-deploy == 'true' &&
      startsWith(github.ref, 'refs/heads/release/')
    uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/dotnet-deploy-env.yml@main
    with:
      artifact-name: ${{ needs.build.outputs.artifact-name }}
      environment: TEST01
    secrets: inherit
```

## Config Templates

### Creating Templates

1. Create folder: `IDware.DevOps.Common/config-templates/{YourRepoName}/`
2. Add config files with tokens: `appsettings.json`, `web.config`, etc.
3. Use token format: `#{VARIABLE_NAME}#`

Example `appsettings.json`:
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "#{DB_CONNECTION_STRING}#"
  },
  "AppSettings": {
    "ApiUrl": "#{API_BASE_URL}#"
  }
}
```

### Token Replacement

Tokens are replaced with environment variable values during deployment. Define variables in GitHub environment settings.

## Troubleshooting

### Build Fails with NuGet Authentication Error

- Verify `GHE_PAT` secret is set
- Check PAT has SSO authorization
- Confirm PAT has `read:packages` scope

### MSDeploy Deployment Fails

- Verify `DEPLOY_USER` and `DEPLOY_PASSWORD` secrets
- Check `DEPLOY_URL` and `IISAPP_*` variables
- Ensure runner has network access to target server

### Windows Service Installation Fails

- Verify `SERVICE_USERNAME` and `SERVICE_PASSWORD` secrets
- Check service account has "Log on as a service" right
- Confirm service name variables are correctly configured

**Note**: As of January 2026, Windows Service deployments use a temp directory approach (`C:\Temp`) to avoid issues with spaces in physical paths. The workflow:
1. Deploys stop/start batch files to `C:\Temp` with unique run IDs
2. Executes service control commands from temp location
3. Cleans up batch files after execution
4. Handles concurrent deployments safely with unique filenames

This resolves MSDeploy `runCommand` failures when IIS physical paths contain spaces.

### Database Migration Fails

- Verify `DB_CONNECTION_STRING` is correct
- Check migrator has network access to database server
- Review migration console output in workflow logs

### Config Templates Not Found

- Ensure templates exist in `IDware.DevOps.Common/config-templates/{repo-name}/`
- Verify `GHE_PAT` secret has access to DevOps.Common repo
- Check template folder name matches repository name exactly
