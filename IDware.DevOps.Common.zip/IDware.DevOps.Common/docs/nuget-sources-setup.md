# NuGet Sources Setup

## Registry Configuration

GitHub Enterprise NuGet registry: `https://nuget.id-ware.ghe.com/ID-Ware-Group/index.json`

## Visual Studio Setup

### Add Package Source

1. **Tools** → **Options** → **NuGet Package Manager** → **Package Sources**
2. Click **+** to add new source
3. Configure:
   - **Name**: `GitHub Enterprise`
   - **Source**: `https://nuget.id-ware.ghe.com/ID-Ware-Group/index.json`
4. Click **Update**, then **OK**

### Authenticate

1. **Tools** → **NuGet Package Manager** → **Package Manager Console**
2. Run:
   ```powershell
   dotnet nuget add source https://nuget.id-ware.ghe.com/ID-Ware-Group/index.json `
     --name GitHubEnterprise `
     --username YOUR_GITHUB_USERNAME `
     --password YOUR_PAT_TOKEN `
     --store-password-in-clear-text
   ```

Credentials are stored in `%AppData%\NuGet\NuGet.Config`.

## Command Line Setup

### Windows

```powershell
dotnet nuget add source https://nuget.id-ware.ghe.com/ID-Ware-Group/index.json `
  --name GitHubEnterprise `
  --username YOUR_GITHUB_USERNAME `
  --password YOUR_PAT_TOKEN `
  --store-password-in-clear-text
```

### Linux/Mac

```bash
dotnet nuget add source https://nuget.id-ware.ghe.com/ID-Ware-Group/index.json \
  --name GitHubEnterprise \
  --username YOUR_GITHUB_USERNAME \
  --password YOUR_PAT_TOKEN \
  --store-password-in-clear-text
```

### Verify Configuration

```bash
dotnet nuget list source
```

Should show `GitHubEnterprise` in the list.

## Installing Packages

```bash
dotnet add package PackageName
```

Or via Visual Studio Package Manager UI.

## Publishing Packages

**Publish only to IDware.DevOps.Common repository.**

### Prerequisites

- `write:packages` permission on your PAT
- Collaborator access to IDware.DevOps.Common

### Publish Command

```bash
dotnet nuget push PackageName.nupkg \
  --source https://nuget.id-ware.ghe.com/ID-Ware-Group/index.json \
  --api-key YOUR_PAT_TOKEN
```

## Troubleshooting

### Authentication Failures

**Error**: `401 Unauthorized` or `403 Forbidden`

**Solutions**:
- Verify PAT has SSO authorization for ID-Ware-Group
- Check token has `read:packages` scope
- Re-run `dotnet nuget add source` with updated credentials
- Clear NuGet cache: `dotnet nuget locals all --clear`

### Cannot Find Package

**Error**: `NU1101: Unable to find package`

**Solutions**:
- Verify package exists in registry
- Check source URL is correct
- Ensure source is enabled: `dotnet nuget enable source GitHubEnterprise`

### Token Expired

Remove old credentials and reconfigure:

```bash
dotnet nuget remove source GitHubEnterprise
# Then re-add with new token
```

## CI/CD Integration

Workflows automatically configure NuGet sources using `GHE_PAT` secret. No manual configuration needed in repositories.

## Security Note

`--store-password-in-clear-text` stores credentials unencrypted in `NuGet.Config`. This is required for non-interactive scenarios and local development. Protect your PAT accordingly.
