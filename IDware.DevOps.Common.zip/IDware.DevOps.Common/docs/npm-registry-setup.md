# npm Registry Setup

## Registry Configuration

GitHub Enterprise npm registry: `https://npm.id-ware.ghe.com`

## Local Development Setup

### 1. Configure npm Registry

Create or edit `.npmrc` in your home directory:

**Windows**: `C:\Users\<username>\.npmrc`  
**Linux/Mac**: `~/.npmrc`

```
@id-ware-group:registry=https://npm.id-ware.ghe.com
//npm.id-ware.ghe.com/:_authToken=${GHE_NPM_TOKEN}
```

### 2. Set Authentication Token

**Windows (PowerShell)**:
```powershell
[Environment]::SetEnvironmentVariable("GHE_NPM_TOKEN", "your-token-here", "User")
```

**Linux/Mac (bash)**:
```bash
echo 'export GHE_NPM_TOKEN="your-token-here"' >> ~/.bashrc
source ~/.bashrc
```

### 3. Verify Setup

```bash
npm whoami --registry=https://npm.id-ware.ghe.com
```

Should display your GitHub username.

## Installing Packages

Packages with `@id-ware-group` scope automatically use the configured registry:

```bash
npm install @id-ware-group/package-name
```

## Publishing Packages

**Publish only to IDware.DevOps.Common repository.**

### Prerequisites

- `write:packages` permission on your PAT
- Collaborator access to IDware.DevOps.Common

### Publish Command

```bash
npm publish
```

Package scope (`@id-ware-group`) determines the registry automatically.

## Troubleshooting

### Authentication Failures

**Error**: `401 Unauthorized` or `403 Forbidden`

**Solutions**:
- Verify PAT has SSO authorization for ID-Ware-Group
- Check token has `read:packages` scope
- Confirm environment variable is set correctly
- Try: `npm logout --registry=https://npm.id-ware.ghe.com` then reconfigure

### Cannot Find Package

**Error**: `404 Not Found`

**Solutions**:
- Verify package name and scope are correct
- Confirm package exists in registry
- Check `.npmrc` scope configuration matches package scope

### Token Expired

npm will fail silently with authentication errors. Generate new token and update environment variable.

## CI/CD Integration

Workflows automatically use `GHE_PAT_READ_PKG` secret from repository settings. No additional configuration needed.
