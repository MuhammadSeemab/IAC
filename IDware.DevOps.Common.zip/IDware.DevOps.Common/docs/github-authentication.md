# GitHub Authentication Setup

## Personal Access Token (PAT)

### Generate Token

1. Go to **Settings** → **Developer settings** → **Personal access tokens** → **Tokens (classic)**
2. Click **Generate new token** → **Generate new token (classic)**
3. Configure token:
   - **Note**: Descriptive name (e.g., "Dev Machine - npm/NuGet access")
   - **Expiration**: 30 days (maximum for SSO-enabled orgs)
   - **Scopes**: Select based on needs:
     - `read:packages` - Download packages
     - `write:packages` - Publish packages
     - `repo` - Access repositories (if needed for workflows)
4. Click **Generate token**
5. **Copy token immediately** (won't be shown again)

### Authorize for SSO

After generating the token:

1. Click **Configure SSO** next to the token
2. Click **Authorize** for ID-Ware-Group organization
3. Complete SSO authentication if prompted

**Important**: Tokens without SSO authorization cannot access organization resources.

### Token Expiration

- SSO-enabled organizations enforce maximum 30-day validity
- Set calendar reminders to regenerate before expiration
- Expired tokens will cause authentication failures in builds and local development

## Security Best Practices

- **Never commit tokens** to repositories
- **Store in secure locations**:
  - Local: Windows Credential Manager, environment variables
  - CI/CD: GitHub Secrets
- **Use least privilege**: Only grant required scopes
- **Rotate regularly**: Don't wait until expiration
- **Revoke compromised tokens immediately**
