# Enabling Pipelines for Hotfix Release Branches

## Context

Developer creates a hotfix release branch (e.g., `release/1.12.4.1`) from a previous release (`release/1.12.4`). **DevOps enables the pipeline on this new release branch RIGHT AT THE START** - before any bugfix branches are created.

Once pipeline is enabled on the release branch, developers create bugfix branches from it, fix bugs, and merge back. The pipeline automatically works for all bugfix branches since they inherit from the release branch.

## What to Check

### Does the branch have workflows?

```bash
git checkout release/1.12.4.1
ls .github/workflows/
```

- **No `.github/workflows/`?** → Create workflow files from scratch or copy from default branch (will require changes for backdated code compatibility)
- **Workflows exist?** → Check if they need updates (@version, inputs, etc.)

---

## Pipeline Configuration Checklist

### 1. Additional Package Branches

Non-standard branches (hotfix, feature) don't create artifacts by default. Enable packaging:

```yaml
additional-package-branches: 'release/1.12.4.1|hotfix/*|bugfix/*'
```

⚠️ Use **pipe** `|` separator, not comma `,`

### 2. Common Workflow Version

Use `@main` if your backdated version does not exist in DevOps.Common repository:

```yaml
uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/dotnet-build.yml@main
uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/angular-build.yml@main
```

### 3. Manual Deployment (Suggested for Hotfixes)

Consider adding workflow_dispatch to prevent auto-deployment:

```yaml
on:
  push:
    branches: ["**"]
  workflow_dispatch:
    inputs:
      deploy-to:
        type: choice
        options: ['', 'DEV01', 'DEV02', 'TEST01']
        default: ''

jobs:
  deploy-dev01:
    if: github.event_name == 'workflow_dispatch' && github.event.inputs.deploy-to == 'DEV01'
```

### 4. Artifact Retention

Automatic (no action needed):
- `release/*` → 60 days
- Others → 7 days

---

## .NET Projects

Check:
- `dotnet-version`: `'8.0.x'` or as required
- Standard build/deploy job structure

---

## Angular Projects

### Workflow Settings

```yaml
node-version: '22.18.0' # Use the one compatible with backdated branch
enable-cache: false  # Recommended for backdated branches
enable-cuic-fix: true  # If using CUIC package
```

### Package Dependencies (Use GitHub Packages)

Check if the project uses internal packages from GitHub Packages:

**package.json** - Scoped naming:
```json
"@id-ware-group_id-ware/cuic": "4.2.1-1"
```

**tsconfig.json** - May need path mapping:
```json
"paths": {
  "cuic": ["node_modules/@id-ware-group_id-ware/cuic"]
}
```

**.npmrc** - Registry config:
```properties
@id-ware-group:registry=https://npm.id-ware.ghe.com
//npm.id-ware.ghe.com/:_authToken=${GH_PAT}
```

**package-lock.json** - Consider deleting if:
- Switching registries
- Having dependency conflicts

---

## How to Enable

### Create Branch FROM Release/Hotfix Branch

```bash
git checkout release/1.12.4.1
git checkout -b feature/enable-pipeline-1.12.4.1
```

⚠️ **Branch from the release branch, NOT develop**

### Add/Update Files

- `.github/workflows/cicd.yml` (required)
- `package.json` (Angular, if needed)
- `tsconfig.json` (Angular, if needed)
- Delete `package-lock.json` (Angular, if registry changed)

### Commit & Push

```bash
git add .github/workflows/ package.json tsconfig.json .npmrc
git commit -S -m "CICD-XXX: Enable pipeline for release 1.12.4.1"
git push origin feature/enable-pipeline-1.12.4.1
```

### Verify Build

Check Actions tab - verify build runs and created artifacts

### Create PR & Merge

`feature/enable-pipeline-1.12.4.1` → `release/1.12.4.1`

Once merged, pipeline is available for release branch and all future bugfix branches.

---

## Common Issues

**"Artifact not found"**  
→ Check `additional-package-branches` includes branch pattern  
→ Verify separator is `|` not `,`

**npm install fails (Angular)**  
→ Check `.npmrc` registry configuration  
→ Verify `GHE_PAT_READ_PKG` secret exists  
→ Try deleting `package-lock.json`

**Deploy job doesn't run**  
→ Check workflow_dispatch input matches deploy job condition  
→ Verify environment name in dropdown

**Stale dependencies (Angular)**  
→ Set `enable-cache: false`

---

## Reference

Search for `CICD-511` commits in AM repos (Jan 2026) for recent examples of enabling pipelines on `release/1.12.4.1-RC1` branches.
