param(
    [Parameter(Mandatory=$true)]
    [string]$VarName,
    
    [Parameter(Mandatory=$true)]
    [object]$VarsContext,
    
    [Parameter(Mandatory=$true)]
    [object]$SecretsContext,
    
    [Parameter(Mandatory=$true)]
    [string]$EnvId
)

$varValue = $null

# Smart resolution matching prepare job logic:
# For product-specific variables (e.g., AM_CONNECTION_STRING):
# 1. Try {ENV}_{PREFIX}_{BASEVAR} (e.g., DEV01_AM_CONNECTION_STRING)
# 2. Try {ENV}_{BASEVAR} (e.g., DEV01_CONNECTION_STRING)
# 3. Try {BASEVAR} (e.g., CONNECTION_STRING)
# For connection strings: prioritize SECRETS over VARS to avoid encrypted values

# Check if this looks like a product-prefixed variable (e.g., AM_CONNECTION_STRING)
if ($VarName -match '^([A-Z]+)_(.+)$') {
    $prefix = $matches[1]
    $baseVar = $matches[2]
    
    # Try {ENV}_{PREFIX}_{BASEVAR}
    $envProdVar = "${EnvId}_${prefix}_${baseVar}"
    # For connection strings, check secrets first to avoid encrypted variables
    if ($baseVar -match 'CONNECTION_STRING') {
        if ($SecretsContext.PSObject.Properties[$envProdVar]) {
            $varValue = $SecretsContext.$envProdVar
            Write-Host "   Resolved {$VarName} from $envProdVar (environment + product-specific secret)"
        } elseif ($VarsContext.PSObject.Properties[$envProdVar]) {
            $varValue = $VarsContext.$envProdVar
            Write-Host "   Resolved {$VarName} from $envProdVar (environment + product-specific var)"
        }
    } else {
        if ($VarsContext.PSObject.Properties[$envProdVar]) {
            $varValue = $VarsContext.$envProdVar
            Write-Host "   Resolved {$VarName} from $envProdVar (environment + product-specific var)"
        } elseif ($SecretsContext.PSObject.Properties[$envProdVar]) {
            $varValue = $SecretsContext.$envProdVar
            Write-Host "   Resolved {$VarName} from $envProdVar (environment + product-specific secret)"
        }
    }
    
    # Try {ENV}_{BASEVAR}
    if (-not $varValue) {
        $envBaseVar = "${EnvId}_${baseVar}"
        # For connection strings, check secrets first to avoid encrypted variables
        if ($baseVar -match 'CONNECTION_STRING') {
            if ($SecretsContext.PSObject.Properties[$envBaseVar]) {
                $varValue = $SecretsContext.$envBaseVar
                Write-Host "   Resolved {$VarName} from $envBaseVar (environment-specific secret)"
            } elseif ($VarsContext.PSObject.Properties[$envBaseVar]) {
                $varValue = $VarsContext.$envBaseVar
                Write-Host "   Resolved {$VarName} from $envBaseVar (environment-specific var)"
            }
        } else {
            if ($VarsContext.PSObject.Properties[$envBaseVar]) {
                $varValue = $VarsContext.$envBaseVar
                Write-Host "   Resolved {$VarName} from $envBaseVar (environment-specific var)"
            } elseif ($SecretsContext.PSObject.Properties[$envBaseVar]) {
                $varValue = $SecretsContext.$envBaseVar
                Write-Host "   Resolved {$VarName} from $envBaseVar (environment-specific secret)"
            }
        }
    }
    
    # Try {BASEVAR}
    if (-not $varValue) {
        # For connection strings, check secrets first to avoid encrypted variables
        if ($baseVar -match 'CONNECTION_STRING') {
            if ($SecretsContext.PSObject.Properties[$baseVar]) {
                $varValue = $SecretsContext.$baseVar
                Write-Host "   Resolved {$VarName} from $baseVar (global secret)"
            } elseif ($VarsContext.PSObject.Properties[$baseVar]) {
                $varValue = $VarsContext.$baseVar
                Write-Host "   Resolved {$VarName} from $baseVar (global var)"
            }
        } else {
            if ($VarsContext.PSObject.Properties[$baseVar]) {
                $varValue = $VarsContext.$baseVar
                Write-Host "   Resolved {$VarName} from $baseVar (global var)"
            } elseif ($SecretsContext.PSObject.Properties[$baseVar]) {
                $varValue = $SecretsContext.$baseVar
                Write-Host "   Resolved {$VarName} from $baseVar (global secret)"
            }
        }
    }
}

# Try direct variable name as fallback
if (-not $varValue) {
    $envSpecificVar = "${EnvId}_${VarName}"
    # For connection strings, check secrets first to avoid encrypted variables
    if ($VarName -match 'CONNECTION_STRING') {
        if ($SecretsContext.PSObject.Properties[$envSpecificVar]) {
            $varValue = $SecretsContext.$envSpecificVar
            Write-Host "   Resolved {$VarName} from $envSpecificVar (direct environment-specific secret)"
        } elseif ($VarsContext.PSObject.Properties[$envSpecificVar]) {
            $varValue = $VarsContext.$envSpecificVar
            Write-Host "   Resolved {$VarName} from $envSpecificVar (direct environment-specific var)"
        } elseif ($SecretsContext.PSObject.Properties[$VarName]) {
            $varValue = $SecretsContext.$VarName
            Write-Host "   Resolved {$VarName} from $VarName (direct global secret)"
        } elseif ($VarsContext.PSObject.Properties[$VarName]) {
            $varValue = $VarsContext.$VarName
            Write-Host "   Resolved {$VarName} from $VarName (direct global var)"
        }
    } else {
        if ($VarsContext.PSObject.Properties[$envSpecificVar]) {
            $varValue = $VarsContext.$envSpecificVar
            Write-Host "   Resolved {$VarName} from $envSpecificVar (direct environment-specific var)"
        } elseif ($SecretsContext.PSObject.Properties[$envSpecificVar]) {
            $varValue = $SecretsContext.$envSpecificVar
            Write-Host "   Resolved {$VarName} from $envSpecificVar (direct environment-specific secret)"
        } elseif ($VarsContext.PSObject.Properties[$VarName]) {
            $varValue = $VarsContext.$VarName
            Write-Host "   Resolved {$VarName} from $VarName (direct global var)"
        } elseif ($SecretsContext.PSObject.Properties[$VarName]) {
            $varValue = $SecretsContext.$VarName
            Write-Host "   Resolved {$VarName} from $VarName (direct global secret)"
        }
    }
}

return $varValue
