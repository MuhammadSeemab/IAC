import glob
import os
import math
import requests
import time
from urllib.parse import quote
import json
import sys

# === Required Credentials ===
TENANT_ID = os.environ['TENANT_ID']
CLIENT_ID = os.environ['CLIENT_ID']
CLIENT_SECRET = os.environ['CLIENT_SECRET']
SITE_ID = os.environ['SITE_ID']
DRIVE_ID = os.environ['DRIVE_ID']
FOLDER_PATH = os.environ['FOLDER_PATH']

# === Token Endpoint and Data ===
token_url = f"https://login.microsoftonline.com/{TENANT_ID}/oauth2/v2.0/token"
token_data = {
    "grant_type": "client_credentials",
    "client_id": CLIENT_ID,
    "client_secret": CLIENT_SECRET,
    "scope": "https://graph.microsoft.com/.default"
}
token_headers = {
    "Content-Type": "application/x-www-form-urlencoded"
}

# === Request the Token ===
print("Requesting access token...")
token_response = requests.post(token_url, data=token_data, headers=token_headers)
if token_response.status_code != 200:
    print("[ERROR] Failed to obtain access token.")
    print(token_response.status_code, token_response.text)
    sys.exit(1)

ACCESS_TOKEN = token_response.json().get("access_token")
if not ACCESS_TOKEN:
    print("[ERROR] Access token not found in response.")
    sys.exit(1)
print("[SUCCESS] Access token acquired.")

# === Configuration ===
MAX_RETRIES = 5
CHUNK_SIZE = 4 * 1024 * 1024  # 4MB chunks for better reliability
RETRY_DELAY = 5  # seconds between retries
TIMEOUT = 30  # seconds for HTTP requests

# === Find ZIP files ===
matches = glob.glob("Tools/ReleaseBuilder/bin/Release/OCMS_*.zip")
if not matches:
    print("[ERROR] No OCMS zip files found")
    sys.exit(1)

print(f"[INFO] Found {len(matches)} file(s) to upload")

# === Helper Functions ===
def get_upload_session(file_name):
    """Create a new upload session"""
    encoded_path = quote(f"{FOLDER_PATH}/{file_name}")
    url = f"https://graph.microsoft.com/v1.0/sites/{SITE_ID}/drives/{DRIVE_ID}/root:/{encoded_path}:/createUploadSession"
    
    headers = {
        "Authorization": f"Bearer {ACCESS_TOKEN}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "item": {
            "@microsoft.graph.conflictBehavior": "rename",
            "name": file_name
        }
    }
    
    for attempt in range(MAX_RETRIES):
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=TIMEOUT)
            if response.status_code == 200:
                return response.json().get("uploadUrl")
            elif response.status_code == 503:
                print(f"[WARNING] Service unavailable (attempt {attempt+1}), retrying...")
                time.sleep(RETRY_DELAY * (attempt + 1))
            else:
                print(f"[ERROR] Failed to create session: HTTP {response.status_code}")
                print(f"Response: {response.text}")
                return None
        except Exception as e:
            print(f"[WARNING] Exception creating session: {str(e)}")
            time.sleep(RETRY_DELAY * (attempt + 1))
    
    return None

def get_upload_status(upload_url):
    """Check current upload status"""
    headers = {
        "Authorization": f"Bearer {ACCESS_TOKEN}",
    }
    
    try:
        response = requests.get(upload_url, headers=headers, timeout=TIMEOUT)
        if response.status_code == 200:
            return response.json()
        return None
    except Exception as e:
        print(f"[WARNING] Exception checking status: {str(e)}")
        return None

def upload_chunk(upload_url, start, end, total_size, chunk_data):
    """Upload a single chunk with retry logic"""
    headers = {
        "Authorization": f"Bearer {ACCESS_TOKEN}",
        "Content-Length": str(len(chunk_data)),
        "Content-Range": f"bytes {start}-{end}/{total_size}",
        "Content-Type": "application/octet-stream"
    }
    
    for attempt in range(MAX_RETRIES):
        try:
            response = requests.put(upload_url, headers=headers, data=chunk_data, timeout=TIMEOUT)
            
            if response.status_code in (200, 201, 202):
                return True, None  # Success
            
            elif response.status_code == 416:
                status = get_upload_status(upload_url)
                if status:
                    next_ranges = status.get('nextExpectedRanges', ['0-'])
                    next_byte = int(next_ranges[0].split('-')[0])
                    return False, next_byte  # Need to adjust range
                return False, None
            
            elif response.status_code == 503:
                print(f"[WARNING] Service unavailable (attempt {attempt+1}), retrying...")
                time.sleep(RETRY_DELAY * (attempt + 1))
                continue
                
            else:
                print(f"[WARNING] Chunk upload failed: HTTP {response.status_code}")
                print(f"Response: {response.text}")
                time.sleep(RETRY_DELAY * (attempt + 1))
                
        except Exception as e:
            print(f"[WARNING] Exception uploading chunk: {str(e)}")
            time.sleep(RETRY_DELAY * (attempt + 1))
    
    return False, None

# === Main Upload Process ===
for FILE_PATH in matches:
    file_name = os.path.basename(FILE_PATH)
    file_size = os.path.getsize(FILE_PATH)
    
    print(f"\n{'='*60}")
    print(f"Uploading: {file_name}")
    print(f"Size: {file_size:,} bytes ({file_size / (1024*1024):.2f} MB)")
    print(f"Destination: {FOLDER_PATH}")
    print(f"{'='*60}")
    
    print(f"Creating upload session...")
    upload_url = get_upload_session(file_name)
    if not upload_url:
        print(f"[ERROR] Failed to create upload session for {file_name}")
        sys.exit(1)
    
    print("Starting upload process...")
    current_byte = 0
    chunk_number = 0
    
    with open(FILE_PATH, 'rb') as f:
        while current_byte < file_size:
            # Get current status in case we need to resume
            status = get_upload_status(upload_url)
            if status:
                next_ranges = status.get('nextExpectedRanges', ['0-'])
                current_byte = int(next_ranges[0].split('-')[0])
            
            # Calculate chunk range
            chunk_end = min(current_byte + CHUNK_SIZE - 1, file_size - 1)
            chunk_size = chunk_end - current_byte + 1
            
            # Read chunk data
            f.seek(current_byte)
            chunk_data = f.read(chunk_size)
            
            # Upload chunk
            chunk_number += 1
            progress = (chunk_end + 1) / file_size * 100
            print(f"Chunk {chunk_number}: bytes {current_byte:,}-{chunk_end:,} ({progress:.1f}%)")
            
            success, next_byte = upload_chunk(upload_url, current_byte, chunk_end, file_size, chunk_data)
            
            if success:
                current_byte = chunk_end + 1
            elif next_byte is not None:
                print(f"Adjusting to server-expected byte: {next_byte}")
                current_byte = next_byte
            else:
                print(f"[ERROR] Failed to upload chunk {chunk_number} after {MAX_RETRIES} attempts")
                sys.exit(1)
    
    # Verify upload completion
    print("Verifying upload completion...")
    status = get_upload_status(upload_url)
    if status and status.get('nextExpectedRanges', None) is None:
        print(f"[SUCCESS] {file_name} uploaded successfully!")
    else:
        print(f"[WARNING] Upload may be incomplete for {file_name}")

print(f"\n{'='*60}")
print(f"[SUCCESS] All files uploaded to: {FOLDER_PATH}")
print(f"{'='*60}")
