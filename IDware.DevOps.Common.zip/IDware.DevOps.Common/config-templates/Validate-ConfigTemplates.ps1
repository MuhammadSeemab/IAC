#!/usr/bin/env pwsh
<#
.SYNOPSIS
    Validates configuration templates for consistency and correctness.

.DESCRIPTION
    This script validates config templates by:
    - Checking JSON/XML syntax
    - Validating placeholders against specs.json configTokens (single source of truth)
    - Detecting orphaned placeholders (in templates but not in specs.json)
    - Detecting missing placeholders (in specs.json but not in templates)
    - Verifying file structure integrity

.EXAMPLE
    .\Validate-ConfigTemplates.ps1
    .\Validate-ConfigTemplates.ps1 -Service CS-configurationserver
    .\Validate-ConfigTemplates.ps1 -Verbose
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory=$false)]
    [string]$Service = "",
    
    [Parameter(Mandatory=$false)]
    [switch]$FailOnWarning = $false
)

$ErrorActionPreference = "Stop"
$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$configRoot = $scriptPath

$errors = @()
$warnings = @()

function Test-JsonFile {
    param([string]$FilePath)
    
    try {
        $content = Get-Content -Path $FilePath -Raw
        $null = ConvertFrom-Json $content
        return $true
    }
    catch {
        $script:errors += "❌ Invalid JSON in '$FilePath': $($_.Exception.Message)"
        return $false
    }
}

function Test-XmlFile {
    param([string]$FilePath)
    
    try {
        $xml = [xml](Get-Content -Path $FilePath -Raw)
        return $true
    }
    catch {
        $script:errors += "❌ Invalid XML in '$FilePath': $($_.Exception.Message)"
        return $false
    }
}

function Get-PlaceholdersFromFile {
    param([string]$FilePath)
    
    $content = Get-Content -Path $FilePath -Raw
    $matches = [regex]::Matches($content, '__\w+__')
    return $matches | ForEach-Object { $_.Value } | Select-Object -Unique
}

function Test-ServiceTemplates {
    param(
        [string]$ServicePath,
        [string]$ServiceName
    )
    
    Write-Host "`n=== Validating $ServiceName ===" -ForegroundColor Cyan
    
    $serviceErrors = 0
    $serviceWarnings = 0
    $allPlaceholders = @{}
    
    # Load specs.json to get known placeholders
    $specsFile = Join-Path $ServicePath "specs.json"
    if (-not (Test-Path $specsFile)) {
        $script:errors += "❌ specs.json not found in $ServicePath"
        return @{ Errors = 1; Warnings = 0 }
    }
    
    try {
        $specs = Get-Content $specsFile -Raw | ConvertFrom-Json
    } catch {
        $script:errors += "❌ Invalid JSON in specs.json: $($_.Exception.Message)"
        return @{ Errors = 1; Warnings = 0 }
    }
    
    # Extract known placeholders from configTokens
    $knownPlaceholders = @()
    if ($specs.deployment.configTokens) {
        $knownPlaceholders = $specs.deployment.configTokens.PSObject.Properties.Name
        Write-Host "Known placeholders from specs.json: $($knownPlaceholders.Count)"
    } else {
        $script:warnings += "⚠️  No configTokens defined in specs.json for $ServiceName"
        $serviceWarnings++
    }
    
    # Get all template files
    $jsonFiles = Get-ChildItem -Path $ServicePath -Recurse -Filter "appsettings.json" -File
    $xmlFiles = Get-ChildItem -Path $ServicePath -Recurse -Filter "web.config" -File
    
    Write-Host "Found $($jsonFiles.Count) appsettings.json files and $($xmlFiles.Count) XML config files"
    
    # Validate JSON files
    foreach ($file in $jsonFiles) {
        Write-Verbose "Checking $($file.Name)..."
        if (Test-JsonFile -FilePath $file.FullName) {
            Write-Host "  ✅ $($file.Name)" -ForegroundColor Green
        }
        else {
            $serviceErrors++
        }
        
        # Extract placeholders
        $placeholders = Get-PlaceholdersFromFile -FilePath $file.FullName
        if ($placeholders) {
            # Use relative path as key to avoid duplicate filenames overwriting each other
            $relativePath = $file.FullName.Replace($ServicePath, '').TrimStart('\', '/')
            $allPlaceholders[$relativePath] = $placeholders
        }
    }
    
    # Validate XML files
    foreach ($file in $xmlFiles) {
        Write-Verbose "Checking $($file.Name)..."
        if (Test-XmlFile -FilePath $file.FullName) {
            Write-Host "  ✅ $($file.Name)" -ForegroundColor Green
        }
        else {
            $serviceErrors++
        }
        
        # Extract placeholders
        $placeholders = Get-PlaceholdersFromFile -FilePath $file.FullName
        if ($placeholders) {
            # Use relative path as key to avoid duplicate filenames overwriting each other
            $relativePath = $file.FullName.Replace($ServicePath, '').TrimStart('\', '/')
            $allPlaceholders[$relativePath] = $placeholders
        }
    }
    
    # Analyze placeholders
    $foundPlaceholders = $allPlaceholders.Values | ForEach-Object { $_ } | Select-Object -Unique
    
    # Check for unknown placeholders (in templates but not in specs.json)
    $unknownPlaceholders = @()
    foreach ($placeholder in $foundPlaceholders) {
        if ($placeholder -notin $knownPlaceholders) {
            $unknownPlaceholders += $placeholder
            $script:warnings += "⚠️  Unknown placeholder in ${ServiceName}: $placeholder (not in specs.json configTokens)"
            $serviceWarnings++
        }
    }
    
    # Check for unused placeholders (in specs.json but not in templates)
    $unusedPlaceholders = @()
    foreach ($placeholder in $knownPlaceholders) {
        if ($placeholder -notin $foundPlaceholders) {
            $unusedPlaceholders += $placeholder
            $script:warnings += "⚠️  Unused placeholder in ${ServiceName}: $placeholder (defined in specs.json but not used in templates)"
            $serviceWarnings++
        }
    }
    
    # Report placeholders usage
    if ($foundPlaceholders.Count -gt 0) {
        Write-Host "`n  Placeholders found in templates:" -ForegroundColor Yellow
        foreach ($placeholder in ($foundPlaceholders | Sort-Object)) {
            $filesUsing = $allPlaceholders.GetEnumerator() | Where-Object { $_.Value -contains $placeholder } | ForEach-Object { $_.Key }
            $status = if ($placeholder -in $knownPlaceholders) { "✅" } else { "⚠️" }
            Write-Host "    $status $placeholder" -ForegroundColor $(if ($placeholder -in $knownPlaceholders) { "Green" } else { "Yellow" })
            foreach ($file in $filesUsing) {
                Write-Host "      -> $file" -ForegroundColor DarkGray
            }
        }
    }
    
    if ($unusedPlaceholders.Count -gt 0) {
        Write-Host "`n  Unused placeholders (in specs.json only):" -ForegroundColor Yellow
        foreach ($placeholder in ($unusedPlaceholders | Sort-Object)) {
            Write-Host "    ⚠️ $placeholder" -ForegroundColor Yellow
        }
    }
    
    Write-Host "`n  Summary: $serviceErrors errors, $serviceWarnings warnings" -ForegroundColor $(if ($serviceErrors -gt 0) { "Red" } elseif ($serviceWarnings -gt 0) { "Yellow" } else { "Green" })
    
    return @{
        Errors = $serviceErrors
        Warnings = $serviceWarnings
    }
}

# Main execution
Write-Host ""
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  Config Templates Validation Script" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan

$totalErrors = 0
$totalWarnings = 0

if ($Service) {
    $servicePath = Join-Path $configRoot $Service
    if (Test-Path $servicePath) {
        $result = Test-ServiceTemplates -ServicePath $servicePath -ServiceName $Service
        $totalErrors += $result.Errors
        $totalWarnings += $result.Warnings
    }
    else {
        Write-Error "Service directory not found: $servicePath"
        exit 1
    }
}
else {
    # Validate all services
    $services = Get-ChildItem -Path $configRoot -Directory | Where-Object { $_.Name -notlike ".*" }
    
    foreach ($serviceDir in $services) {
        $result = Test-ServiceTemplates -ServicePath $serviceDir.FullName -ServiceName $serviceDir.Name
        $totalErrors += $result.Errors
        $totalWarnings += $result.Warnings
    }
}

# Print collected warnings
if ($warnings.Count -gt 0) {
    Write-Host "`n=== Warnings ===" -ForegroundColor Yellow
    foreach ($warning in $warnings) {
        Write-Host $warning -ForegroundColor Yellow
    }
}

# Print collected errors
if ($errors.Count -gt 0) {
    Write-Host "`n=== Errors ===" -ForegroundColor Red
    foreach ($error in $errors) {
        Write-Host $error -ForegroundColor Red
    }
}
# Final summary
Write-Host ""
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  Validation Summary" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "Total Errors:   $totalErrors" -ForegroundColor $(if ($totalErrors -gt 0) { "Red" } else { "Green" })
Write-Host "Total Warnings: $totalWarnings" -ForegroundColor $(if ($totalWarnings -gt 0) { "Yellow" } else { "Green" })

if ($totalErrors -gt 0) {
    Write-Host ""
    Write-Host "❌ Validation FAILED" -ForegroundColor Red
    exit 1
}
elseif ($totalWarnings -gt 0 -and $FailOnWarning) {
    Write-Host ""
    Write-Host "⚠️  Validation completed with WARNINGS (treating as failure)" -ForegroundColor Yellow
    exit 1
}
else {
    Write-Host ""
    Write-Host "✅ Validation PASSED" -ForegroundColor Green
    exit 0
}
