# IDware.DevOps.Common

Central repository for shared CI/CD workflows, actions, and DevOps resources for ID-Ware Group.

**Migration Status:** ✅ Bitbucket to GitHub migration completed (December 2025)

## 📁 Repository Structure

```
IDware.DevOps.Common/
├── .github/
│   ├── workflows/                      # Reusable workflows
│   │   ├── angular-build.yml          # Angular SPA build
│   │   ├── angular-deploy-iis.yml     # Angular IIS deployment
│   │   ├── dotnet-build.yml           # .NET build & package
│   │   └── dotnet-deploy-env.yml      # .NET service deployment
│   └── actions/                        # Composite actions
│       ├── setup-angular-build/       # Node.js + npm setup
│       ├── fix-cuic-package/          # CUIC UTF-8 BOM fix
│       ├── deploy-iis-msdeploy/       # IIS MSDeploy automation
│       ├── setup-dotnet-build/        # .NET SDK setup
│       ├── deploy-windows-service/    # Windows Service deployment
│       └── run-db-migrations/         # Database migration runner
├── docs/                               # Documentation
│   ├── github-authentication.md       # PAT generation & SSO
│   ├── npm-registry-setup.md          # npm setup
│   ├── nuget-sources-setup.md         # NuGet configuration
│   ├── dotnet-workflows.md            # .NET workflow guide
│   ├── angular-workflows.md           # Angular workflow guide
│   └── enabling-pipelines-for-hotfix-branches.md  # Hotfix pipeline setup
└── config-templates/                   # Configuration examples
```

## 🚀 Quick Start

### For Angular Projects

Create `.github/workflows/cicd.yml`:

```yaml
name: CICD Pipeline

on:
  push:
    branches: ["**"]
  workflow_dispatch:

permissions:
  actions: read
  packages: read   # For GitHub Packages npm registry

jobs:
  build:
    uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/angular-build.yml@main
    with:
      artifact-prefix: 'my_app_artifacts'
      artifact-path: 'dist'           # Or 'dist/AppName' if needed
      enable-cuic-fix: true            # If using CUIC package
    secrets:
      GHE_PAT_READ_PKG: ${{ secrets.GHE_PAT_READ_PKG }}

  deploy-dev01:
    needs: build
    if: |
      needs.build.outputs.should-deploy == 'true' &&
      (github.ref == 'refs/heads/develop' || startsWith(github.ref, 'refs/heads/release/'))
    uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/angular-deploy-iis.yml@main
    with:
      environment: DEV01
      artifact-name: ${{ needs.build.outputs.artifact-name }}
      server-ip: ${{ vars.DEV01_IP }}
      runner-group: IDWG-RG-01
    secrets: inherit
    concurrency:
      group: deploy-dev01
      cancel-in-progress: false
```

**Environment Variables (per environment):**
- `{ENV}_IP`: Server IP address (e.g., `DEV01_IP`)
- `IISAPP`: IIS application name
- `DEPLOY_USERNAME`: Deployment user
- `DEPLOY_PASSWORD`: Deployment password

### For .NET Projects

Create `.github/workflows/cicd.yml`:

```yaml
name: CICD Pipeline

on:
  push:
    branches: ["**"]
  workflow_dispatch:

permissions:
  contents: read
  actions: read
  packages: read

jobs:
  build:
    uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/dotnet-build.yml@main
    with:
      working-directory: 'backend'     # Or '.' for root
      artifact-prefix: 'my_services_artifacts'
    secrets: inherit

  deploy-dev01:
    needs: build
    if: |
      needs.build.outputs.should-package == 'true' &&
      (github.ref == 'refs/heads/develop' || startsWith(github.ref, 'refs/heads/release/'))
    uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/dotnet-deploy-env.yml@main
    with:
      artifact-name: ${{ needs.build.outputs.artifact-name }}
      artifact-run-id: ${{ github.run_id }}
      environment-name: DEV01
      runner-group: IDWG-RG-01
    secrets: inherit
    concurrency:
      group: deploy-dev01
      cancel-in-progress: false
```

## 📖 Available Workflows

### Angular Workflows

#### `angular-build.yml`
Builds Angular SPAs with npm package caching and security audits.

**Key Features:**
- GitHub Enterprise npm registry support
- npm security audit (moderate level, non-blocking)
- Dynamic artifact retention (60 days for release/*, 7 days for develop and other branches)
- CUIC package UTF-8 BOM fix
- Configurable artifact paths
- Additional package branches for artifact creation of non-release branches

**Inputs:**
- `artifact-prefix` (required): Artifact name prefix
- `artifact-path` (default: `dist`): Build output directory
- `node-version` (default: `22.18.0`): Node.js version
- `enable-cuic-fix` (default: `false`): Apply CUIC fix
- `enable-cache` (default: `true`): Enable npm caching
- `additional-package-branches` (optional): Pipe-separated branch patterns for artifact creation
- `runner-group` (default: `IDWG-RG-01`): Runner group

**Outputs:**
- `artifact-name`: Generated artifact name
- `version`: Version from package.json
- `should-deploy`: Deployment eligibility flag

#### `angular-deploy-iis.yml`
Deploys Angular SPAs to IIS via MSDeploy with connectivity testing.

**Key Features:**
- Server connectivity validation
- Artifact verification
- Health check support (optional)
- Deployment metadata tracking

**Inputs:**
- `artifact-name` (required): Artifact to deploy
- `environment` (required): GitHub environment name
- `server-ip` (required): Target server IP
- `app-name` (optional): IIS app name (falls back to `vars.IISAPP`)
- `runner-group` (default: `IDWG-RG-01`): Runner group
- `enable-health-check` (default: `false`): Post-deployment check
- `health-check-url` (optional): URL to verify

### .NET Workflows

#### `dotnet-build.yml`
Builds .NET 8 and .NET Framework projects with NuGet package support.

**Key Features:**
- Multi-project solution support
- Database migration detection and packaging
- NuGet package publishing
- Dynamic artifact retention (60 days for release/*, 7 days for develop and other branches)
- Additional package branches for artifact creation of non-release branches

**Inputs:**
- `artifact-prefix` (required): Artifact name prefix
- `working-directory` (default: `.`): Solution directory
- `additional-package-branches` (optional): Pipe-separated branch patterns for artifact creation
- `runner-group` (default: `IDWG-RG-01`): Runner group

**Outputs:**
- `artifact-name`: Generated artifact name
- `should-package`: Packaging eligibility flag

#### `dotnet-deploy-env.yml`
Deploys .NET services, runs migrations, and manages Windows Services.

**Key Features:**
- Windows Service deployment
- Database migration execution
- Multi-step deployment orchestration
- Service verification

**Inputs:**
- `artifact-name` (required): Artifact to deploy
- `artifact-run-id` (required): Build run ID
- `environment-name` (required): GitHub environment
- `runner-group` (default: `IDWG-RG-01`): Runner group

## 🔧 Available Actions

### Angular Actions

**`setup-angular-build`**
- Configures Node.js and npm
- Authenticates with GitHub Enterprise npm registry
- Installs dependencies with caching
- Applies CUIC package fix if enabled

**`deploy-iis-msdeploy`**
- Validates deployment inputs
- Locates MSDeploy executable
- Executes MSDeploy with proper error handling
- Supports verbose mode

**`fix-cuic-package`**
- Removes UTF-8 BOM from CUIC package.json
- Workaround for known Angular CLI issue

### .NET Actions

**`setup-dotnet-build`**
- Installs .NET SDK
- Configures NuGet sources (GitHub Packages)
- Restores dependencies

**`deploy-windows-service`**
- Stops Windows Service
- Backs up existing deployment
- Deploys new binaries
- Starts service with verification

**`run-db-migrations`**
- Detects migration executables
- Executes database migrations
- Validates migration success

## 📚 Documentation

### Setup Guides
- **[GitHub Authentication](./docs/github-authentication.md)** - PAT generation, SSO authorization, security best practices
- **[npm Registry Setup](./docs/npm-registry-setup.md)** - Local development setup, troubleshooting, publishing
- **[NuGet Sources Setup](./docs/nuget-sources-setup.md)** - Configuration, Visual Studio integration, CI/CD

### Workflow Guides
- **[.NET Workflows](./docs/dotnet-workflows.md)** - Build, deploy, configuration, troubleshooting
- **[Angular Workflows](./docs/angular-workflows.md)** - Build, deploy, IIS configuration

### Other Resources
- **[Versioning Strategy](./VERSIONING.md)** - Branch strategy, dynamic ref resolution
- **[Confluence Knowledge Base](https://id-ware.atlassian.net/wiki/spaces/IDWDE/folder/1390641153)** - Policies, FAQs, guides

## 🏗️ Infrastructure

### Runner Groups
- **IDWG-RG-01**: Self-hosted Windows runners for build and deployment
- Access to internal networks and Azure environments
- Consistent execution environment for all pipelines

### Environments
- **DEV01, DEV02**: Development servers (Azure)
- **TEST01-04**: QA/Testing servers (Azure)
- Environment-specific variables configured per environment
- Protection rules and approvals where needed

### Package Registries
- **npm**: `https://npm.id-ware.ghe.com` (scope: `@id-ware-group`)
- **NuGet**: `https://nuget.id-ware.ghe.com/ID-Ware-Group/index.json`
- Authentication via GitHub PAT with SSO authorization

## 🔄 Workflow Versioning

**Reference Strategy:**
- `@main`: Latest stable version with dynamic ref resolution
- `@2025.1`: Current release branch (uses API-based ref resolution)
- `@{tag}`: Future tagged releases

**Dynamic Branch Resolution:**
All workflows automatically detect which branch/tag they were called with using the GitHub Actions API. When you reference `@main`, the workflow queries the API to discover it was called with `main`. When you reference `@2025.1`, it discovers `2025.1`. No manual configuration or workflow inputs needed.

**Technical Implementation:**
Each workflow queries `github.run_id` via the GitHub API to retrieve `referenced_workflows`, which contains the exact ref (branch/tag) used in the calling workflow's `uses:` statement. This eliminates hardcoded refs and manual inputs.

**Example:**
```yaml
# This workflow will automatically detect and use 'main' branch
uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/dotnet-deploy-env.yml@main

# This workflow will automatically detect and use '2025.1' branch
uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/dotnet-deploy-env.yml@2025.1
```

See [VERSIONING.md](./VERSIONING.md) for detailed branching strategy.

## 🛠️ Maintenance & Support

### For Git Issues
- **Contact**: Git Admin - Muhammad Ajmal
- **Scope**: Repository access, branch management, policies, permissions

### For CI/CD Issues
- **Contact**: DevOps_IBD Team
- **Scope**: Pipelines, environments, deployments, package registries

### Reporting Issues
1. Check [Confluence Knowledge Base](https://id-ware.atlassian.net/wiki/spaces/IDWDE/folder/1390641153) for known issues
2. Review relevant documentation in `docs/`
3. Open issue in this repository with details
4. Contact DevOps team via Teams if urgent

## 🎯 Best Practices

### Workflow Configuration
- Always specify `permissions` explicitly
- Use `secrets: inherit` for child workflows
- Implement `concurrency` groups for deployments
- Set appropriate `runner-group` for self-hosted runners

### Security
- Store PAT in GitHub Secrets, never commit
- Use SSO-authorized tokens (30-day max validity)
- Rotate tokens before expiration
- Follow principle of least privilege for permissions

### Performance
- Enable npm caching (`enable-cache: true`) for Angular builds
- Use dynamic artifact retention to save storage
- Leverage runner groups for consistent performance

## 📝 License

Internal use only - ID-Ware Group

---

**Last Updated**: January 2026  
**Migration Status**: ✅ Completed  
**Active Repositories**: 18+ (.NET services, Angular SPAs, OCMS)  
**Latest Enhancement**: Dynamic workflow ref resolution (Jan 2026)
