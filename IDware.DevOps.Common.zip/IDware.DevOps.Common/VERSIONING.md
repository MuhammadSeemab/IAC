# IDware.DevOps.Common Versioning Strategy

## Current Release Branch
**2025.1**

Production repositories should reference `@2025.1` for stability. Test repositories can use `@main` for latest features.

## Overview

This repository uses a release branch strategy to provide stable, versioned workflows aligned with product release cycles.

- **main**: Active development branch - latest features with dynamic ref resolution
- **Release branches** (e.g., `2025.1`, `2025.2`): Tested, stable references with hardcoded refs
- Production repositories reference release branches, not `main`

## Dynamic Ref Resolution

All branches now use API-based automatic ref resolution:

**How it works:**
1. When a repository calls a workflow (e.g., `@main` or `@2025.1`), the workflow queries the GitHub Actions API
2. The API returns `referenced_workflows` containing the exact ref used in the calling workflow's `uses:` statement
3. The workflow extracts this ref and uses it for all checkouts of `IDware.DevOps.Common`
4. No manual `workflow-ref` input needed - works on all branches

**Technical Details:**
```powershell
# Each workflow runs this to discover its ref
$apiUrl = "${{ github.api_url }}/repos/${{ github.repository }}/actions/runs/${{ github.run_id }}"
$response = Invoke-RestMethod -Uri $apiUrl -Headers $headers
$ref = $response.referenced_workflows[0].ref
```

**Example:**
```yaml
# Repository workflow
jobs:
  deploy:
    uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/dotnet-deploy-env.yml@main
    # Workflow automatically discovers it was called with 'main'

  deploy-prod:
    uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/dotnet-deploy-env.yml@2025.1
    # Workflow automatically discovers it was called with '2025.1'
```

This approach works uniformly across all branches - no branch-specific configuration needed.

## Branch Lifecycle

```
main (continuous development)
  ↓ merge when tested
2025.1 (repos reference this)
  ↓ when product releases
Create new version i.e., 2025.2 from main
```

## Daily Workflow

### Making Changes
All development continues on `main` as usual:

```bash
git checkout main
# Make changes, commit, push
git push origin main
```

### Promoting Changes to Release Branch
After changes are tested on `main`, promote to release branch:

```bash
git checkout 2025.1
git merge main
git push origin 2025.1
```

Repositories using `@2025.1` will automatically get the updates on their next workflow run.

## Creating New Release Branch

When the product advances to a new version (e.g., 2025.1 → 2025.2):

```bash
# Ensure main is up to date
git checkout main
git merge 2025.1  # Should be clean if only merging main → release

# Create new release branch
git checkout -b 2025.2
git push origin 2025.2
```

Then update all repositories from `@2025.1` to `@2025.2`.

## Hotfix Process

If an old release needs a patch after moving to a new version:

```bash
# Create hotfix branch from frozen release
git checkout -b 2025.1.1 2025.1

# Make fixes
git commit -m "Hotfix: description"
git push origin 2025.1.1
```

Affected repositories can reference `@2025.1.1` temporarily. Merge hotfix back to `main` if applicable.

## Repository Configuration

Repositories should reference the current release branch in their workflows:

```yaml
# .github/workflows/cicd.yml
jobs:
  build:
    uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/dotnet-build.yml@2025.1
    # ...

  deploy:
    uses: ID-Ware-Group/IDware.DevOps.Common/.github/workflows/dotnet-deploy-env.yml@2025.1
    # ...
```

## Best Practices

1. **Test on main first**: Always test changes on `main` before merging to release branch
2. **Merge regularly**: Promote tested changes from `main` to release branch weekly or as needed
3. **Keep branches in sync**: Release branches should always be a subset of `main`
4. **Document breaking changes**: Clearly communicate when changes require repository updates
5. **Use DevOps.AccessManager as pilot**: Test major changes on test repositories like DevOps.AccessManager before promoting

## Benefits

- ✅ Controlled rollout - test on main before affecting all repos
- ✅ Easy rollback - repositories can switch branches quickly
- ✅ Hotfix capability - old releases remain available
- ✅ Clear versioning - aligned with product release cycles
- ✅ No force-push tags - branches are designed to move forward

## Version History

| Release Branch | Created | Status | Features |
|----------------|---------|--------|----------|
| main | Ongoing | Development | Dynamic ref resolution, latest features |
| 2025.1 | Jan 2026 | Active | Stable, hardcoded refs, Windows Service temp directory fix |
